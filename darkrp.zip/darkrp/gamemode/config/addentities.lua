--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/config/sh_entities.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

DarkRP.createEntity("Terminal Camera", {
	ent = "terminal_camera",
	model = "models/dav0r/camera.mdl",
	price = 2500,
	max = 1,
	cmd = "buyterminalcamera",
	category = "Other"
})

DarkRP.createEntity("Terminal", {
	ent = "terminal",
	model = "models/props_phx/rt_screen.mdl",
	price = 1000,
	max = 1,
	cmd = "buyterminal",
	category = "Other"
})

DarkRP.createEntity("Gang Credit Printer", {
	ent = "gang_credit_printer",
	model = "models/props_wasteland/kitchen_counter001c.mdl",
	price = 100000,
	max = 1,
	cmd = "buygangcreditprinter",
	customCheck = function(ply)
		return !ply:isCP() && ply:GetGang() != nil && !Gangs.Cache.HasSpawnedPrinter(ply:GetGang()) && #Gangs.OnlineMembers(ply:GetGang()) >= 2
	end,
	CustomCheckFailMsg = 'You either do not have a gang, not have 2+ online members, or your gang has spawned one.',
	category = "Other"
})


local drugsAllowed = {}

DarkRP.createEntity("Alcohol", {
	ent = "durgz_alcohol",
	model = "models/props_junk/PopCan01a.mdl",
	price = 2500,
	max = 1,
	cmd = "buyalcoholcan",
	allowed = drugsAllowed,
	category = "Drugs"
})

DarkRP.createEntity("PCP", {
	ent = "durgz_pcp",
	model = "models/props_lab/jar01a.mdl",
	price = 2500,
	max = 1,
	cmd = "buypcp",
	allowed = drugsAllowed,
	category = "Drugs"
})

DarkRP.createEntity("LSD", {
	ent = "durgz_weed",
	model = "models/props_lab/huladoll.mdl",
	price = 2500,
	max = 1,
	cmd = "buylsd",
	allowed = drugsAllowed,
	category = "Drugs"
})

/*

DarkRP.createEntity("Small Present", {
	ent = "small_gift",
	model = "models/items/cs_gift.mdl",
	price = 40000,
	max = 1,
	cmd = "buysmallpresent",
	category = "Other"
})

DarkRP.createEntity("Large Present", {
	ent = "large_gift",
	model = "models/items/cs_gift.mdl",
	price = 80000,
	max = 1,
	cmd = "buylargepresent",
	category = "Other"
})

*/

DarkRP.createEntity("Toll", {
	ent = "toll",
	model = "models/props_c17/fence01b.mdl",
	price = 5000,
	max = 1,
	cmd = "buytoll",
	allowed = {},
	category = "Other"
})

DarkRP.createEntity("Metal Detector", {
	ent = "metal_detector",
	model = "models/props_wasteland/interior_fence002e.mdl",
	price = 5000,
	max = 1,
	cmd = "buymetaldetector"
})

DarkRP.createEntity("Money Box", {
	ent = "money_box",
	model = "models/props_junk/PlasticCrate01a.mdl",
	price = 500,
	max = 1,
	cmd = "buymoneybox",
	category = "Other"
})

DarkRP.createEntity("Gang Sign", {
	ent = "gang_sign",
	model = "models/props_phx/construct/metal_plate1.mdl",
	price = 5000,
	max = 1,
	customCheck = function(ply)
		return ply:GetGang() != nil
	end,
	cmd = "buygangsign",
	category = "Other"
})

DarkRP.createEntity("Donation Box", {
	ent = "donation_box",
	model = "models/props_junk/PlasticCrate01a.mdl",
	price = 500,
	max = 1,
	cmd = "buydonationbox",
	category = "Other",
	allowed = {TEAM_HOBO}
})

DarkRP.createEntity("Charge", {
	ent = "printr_charge",
	model = "models/Items/battery.mdl",
	price = 1000,
	max = 1,
	cmd = "buyprintercharge",
	category = "Printers",
	customCheck = function(ply)
	return !ply:isCP() end
})

DarkRP.createEntity("CPU", {
	ent = "printr_cpu",
	model = "models/props_lab/reciever01d.mdl",
	price = 25000,
	max = 1,
	cmd = "buyprintercpu",
	category = "Printers",
	customCheck = function(ply)
	return !ply:isCP() end
})

DarkRP.createEntity("Printer", {
	ent = "printr",
	model = "models/props_c17/consolebox01a.mdl",
	price = 7000,
	max = 1,
	cmd = "buyprinter",
	category = "Printers",
	customCheck = function(ply)
	return !ply:isCP() end
})

DarkRP.createEntity("Crypto Miner", {
	ent = "crypto_miner",
	model = "models/props_lab/monitor01a.mdl",
	price = 10000,
	max = 1,
	cmd = "buycryptominer",
	category = "Crypto",
	allowed = {TEAM_CRYPTO}
})

DarkRP.createEntity("Blackjack Table", {
	ent = "pcasino_blackjack_table",
	model = "models/freeman/owain_blackjack_table.mdl",
	price = 10000,
	max = 1,
	category = "Casino",
	cmd = "buyblackjacktable",
	allowed = {TEAM_CASINOMANAGER}
})

DarkRP.createEntity("Roulette Table", {
	ent = "pcasino_roulette_table",
	model = "models/freeman/owain_roulette_table.mdl",
	price = 10000,
	max = 1,
	category = "Casino",
	cmd = "buyroulettetable",
	allowed = {TEAM_CASINOMANAGER}
})

local allowedMeth = {TEAM_DDEALER}

DarkRP.createEntity("Gas Canister", {
	ent = "eml_gas",
	model = "models/props_c17/canister01a.mdl",
	price = 500,
	max = 1,
	category = "Drugs",
	cmd = "buygascanister",
	allowed = allowedMeth
})

DarkRP.createEntity("Liquid Iodine", {
	ent = "eml_iodine",
	model = "models/props_lab/jar01b.mdl",
	price = 600,
	max = 1,
	category = "Drugs",
	cmd = "buyiodine",
	allowed = allowedMeth
})

DarkRP.createEntity("Jar", {
	ent = "eml_jar",
	model = "models/props_lab/jar01a.mdl",
	price = 500,
	max = 1,
	category = "Drugs",
	cmd = "buyjar",
	allowed = allowedMeth
})

DarkRP.createEntity("Muriatic Acid", {
	ent = "eml_macid",
	model = "models/props_junk/garbage_plasticbottle001a.mdl",
	price = 800,
	max = 1,
	category = "Drugs",
	cmd = "buymacid",
	allowed = allowedMeth
})

DarkRP.createEntity("Pot", {
	ent = "eml_pot",
	model = "models/props_c17/metalPot001a.mdl",
	price = 800,
	max = 2,
	category = "Drugs",
	cmd = "buypot",
	allowed = allowedMeth
})

DarkRP.createEntity("Special Pot", {
	ent = "eml_spot",
	model = "models/props_c17/metalPot001a.mdl",
	price = 1000,
	max = 1,
	category = "Drugs",
	cmd = "buyspot",
	allowed = allowedMeth
})

DarkRP.createEntity("Stove", {
	ent = "eml_stove",
	model = "models/props_c17/furnitureStove001a.mdl",
	price = 8000,
	max = 1,
	category = "Drugs",
	cmd = "buystove",
	allowed = allowedMeth
})

DarkRP.createEntity("Liquid Sulfur", {
	ent = "eml_sulfur",
	model = "models/props_lab/jar01b.mdl",
	price = 1000,
	max = 1,
	category = "Drugs",
	cmd = "buysulfur",
	allowed = allowedMeth
})

DarkRP.createEntity("Water", {
	ent = "eml_water",
	model = "models/props_junk/garbage_plasticbottle003a.mdl",
	price = 300,
	max = 1,
	category = "Drugs",
	cmd = "buywater",
	allowed = allowedMeth
})

local moonshine = {TEAM_BREWER}

DarkRP.createEntity("Dank Juice", {
	ent = "bottle2",
	model = "models/props_junk/garbage_glassbottle003a.mdl",
	price = 1000,
	max = 1,
	category = "Moonshine",
	cmd = "buydankjuice",
	allowed = moonshine
})

DarkRP.createEntity("Alcohol", {
	ent = "bottle1",
	model = "models/props_junk/garbage_plasticbottle003a.mdl",
	price = 1000,
	max = 1,
	category = "Moonshine",
	cmd = "buyalcohol",
	allowed = moonshine
})

DarkRP.createEntity("Brewer", {
	ent = "bottlemaker",
	model = "models/props_c17/FurnitureWashingmachine001a.mdl",
	price = 12000,
	max = 1,
	category = "Moonshine",
	cmd = "buybottlemaker",
	allowed = moonshine
})

local allowedDJ = {TEAM_RADIO}

DarkRP.createEntity("TV", {
	ent = "whk_tv",
	model = "models/props/cs_office/TV_plasma.mdl",
	price = 1000,
	max = 1,
	category = "Other",
	cmd = "buywhktv",
	allowed = allowedDJ
})

DarkRP.createEntity("Charger Battery", {
	ent = "recharger_charge",
	model = "models/props_lab/tpplug.mdl",
	price = 500,
	max = 1,
	cmd = "buychargerbattery",
	category = "Medic",
	allowed = {TEAM_MEDIC, TEAM_SWATM}
})

DarkRP.createEntity("Armor Charger CJ", {
	ent = "armor_charger_slow",
	model = "models/props_combine/health_charger001.mdl",
	price = 20000,
	max = 1,
	category = "Medic",
	cmd = "buyarmorchargercj",
	allowed = {TEAM_FATMAN, TEAM_SAVAGE}
})

DarkRP.createEntity("Armor Charger TKN", {
	ent = "armor_charger_slow",
	model = "models/props_combine/health_charger001.mdl",
	price = 20000,
	max = 1,
	category = "Medic",
	cmd = "buyarmorchargertkn",
	customCheck = function(ply)
		return SERVER && ply:HasItem("armour_charger")
	end
})

DarkRP.createEntity("Armor Charger", {
	ent = "armor_charger",
	model = "models/props_c17/consolebox05a.mdl",
	price = 5000,
	max = 1,
	category = "Medic",
	cmd = "buyarmorcharger",
	customCheckOnUI = true,
	customCheck = function(ply)
		if SERVER then
			local id = JobLevels.JobToID[ply:Team()]
			if id && id == "swat_medic" && JobLevels.HasUnlock(ply, "swat_medic", "passive_chargers") then
				return true
			end
			return ply:Team() == TEAM_MEDIC
		else
			return ply:isCP() || ply:Team() == TEAM_MEDIC
		end
	end
})

DarkRP.createEntity("Health Charger", {
	ent = "health_charger",
	model = "models/props_c17/consolebox05a.mdl",
	price = 3500,
	max = 1,
	category = "Medic",
	cmd = "buyhealthcharger",
	customCheck = function(ply)
		return SERVER && ((ply:Team() == TEAM_SWATM && JobLevels.HasUnlock(ply, "swat_medic", "passive_chargers")) || ply:Team() == TEAM_MEDIC)
	end,
	allowed = {TEAM_MEDIC, TEAM_SWATM}
})

DarkRP.createEntity("Gun Shelf", {
	ent = "gun_shelf",
	not_in_spawn = true,
	model = "models/props_c17/furnitureshelf001a.mdl",
	price = 8000,
	max = 1,
	category = "Other",
	cmd = "buygunshelf",
	allowed = {} 
})

DarkRP.createEntity("Gun Shelf Perma", {
	ent = "gun_shelf",
	not_in_spawn = true,
	model = "models/props_c17/furnitureshelf001a.mdl",
	price = 8000,
	max = 1,
	category = "Other",
	cmd = "buygunshelfperma",
	hide = true,
	customCheck = function(ply)
		return SERVER && ply:HasItem("gun_shelf")
	end
})

local allowedWeed = {TEAM_GANG, TEAM_INSURGENT, TEAM_FATMAN, TEAM_SAVAGE}

DarkRP.createEntity("Plant Pot", {
	ent = "weed_plant",
	model = "models/nater/weedplant_pot.mdl",
	price = 12000,
	max = 1,
	category = "Weed",
	cmd = "buyplantpot",
	allowed = allowedWeed
})

DarkRP.createEntity("Stardawg Seeds", {
	ent = "weed_seed",
	model = "models/props_junk/garbage_bag001a.mdl",
	price = 6000,
	max = 1,
	category = "Weed",
	cmd = "buyseeds",
	allowed = allowedWeed
})

DarkRP.createEntity("Grow Formula", {
	ent = "weed_grow",
	model = "models/props_junk/garbage_plasticbottle001a.mdl",
	price = 25000,
	max = 1,
	cmd = "buygrowformula",
	category = "Weed",
	allowed = allowedWeed
})

DarkRP.createEntity("Weed Box", {
	ent = "weed_box",
	model = "models/props_junk/PlasticCrate01a.mdl",
	price = 10000,
	max = 1,
	category = "Weed",
	cmd = "buyweedbox",
	allowed = allowedWeed
})

DarkRP.createEntity("Drug Lab", {
	ent = "drug_lab",
	model = "models/props_lab/crematorcase.mdl",
	price = 35000,
	max = 1,
	category = "Drugs",
	cmd = "buydruglab",
	allowed = {}
})

DarkRP.createEntity("Shelf", {
	ent = "store_shelf",
	model = "models/props_c17/furnitureshelf001a.mdl",
	price = 1500,
	max = 1,
	category = "Store",
	cmd = "buystoreshelf",
	allowed = {TEAM_STOREOWNER}
})