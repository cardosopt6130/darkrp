--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/config/sh_ammo.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

/*---------------------------------------------------------------------------
/*---------------------------------------------------------------------------
Ammo types
---------------------------------------------------------------------------
Ammo boxes that can be purchased in the F4 menu.

Add your custom ammo types in this file. Here's the syntax:
DarkRP.createAmmoType("ammoType", {
    name = "Ammo name",
    model = "Model",
    price = 1234,
    amountGiven = 5678,
    customCheck = function(ply) return ply:IsAdmin()
})

ammoType: The name of the ammo that Garry's mod recognizes
	If you open your SWEP's shared.lua, you can find the ammo name next to
	SWEP.Primary.Ammo = "AMMO NAME HERE"
	or
	SWEP.Secondary.Ammo = "AMMO NAME HERE"

name: The name you want to give to the ammo. This can be anything.

model: The model you want the ammo to have in the F4 menu

price: the price of your ammo in dollars

amountGiven: How much bullets of this ammo is given every time the player buys it

customCheck: (Optional! Advanced!) a Lua function that describes who can buy the ammo.
	Similar to the custom check function for jobs and shipments
	Parameters:
		ply: the player who is trying to buy the ammo

Examples are below!


Add new ammo types under the next line!
---------------------------------------------------------------------------*/

DarkRP.createAmmoType("RPG_Round", {
	name = "RPG Rocket",
	model = "models/items/ammocrates/craterockets.mdl",
	price = 40000,
	amountGiven = 2,
	category = "Ammo"
})

DarkRP.createAmmoType("pistol", {
	name = "Pistol Ammo",
	model = "models/Items/BoxSRounds.mdl",
	price = 300,
	amountGiven = 60,
	category = "Ammo"
})

DarkRP.createAmmoType("smg1", {
	name = "SMG Ammo",
	model = "models/Items/BoxMRounds.mdl",
	price = 600,
	max = 1,
	amountGiven = 90,
	category = "Ammo"
})

DarkRP.createAmmoType("357", {
	name = "357 Ammo",
	model = "models/items/357ammo.mdl",
	price = 400,
	max = 1,
	amountGiven = 20,
	category = "Ammo"
})

DarkRP.createAmmoType("ar2", {
	name = "Rifle Ammo",
	model = "models/Items/BoxMRounds.mdl",
	price = 1000,
	amountGiven = 90,
	category = "Ammo"
})

DarkRP.createAmmoType("buckshot", {
	name = "Shotgun Ammo",
	model = "models/Items/BoxSRounds.mdl",
	price = 1200,
	max = 1,
	amountGiven = 16,
	category = "Ammo"
})

DarkRP.createAmmoType("SniperPenetratedRound", {
	name = "Sniper Ammo",
	model = "models/Items/BoxSRounds.mdl",
	price = 1500,
	max = 1,
	amountGiven = 30,
	category = "Ammo"
})

DarkRP.createAmmoType("XBowBolt", {
	name = "Bolts",
	model = "models/Items/BoxSRounds.mdl",
	price = 1000,
	max = 1,
	amountGiven = 20,
	category = "Ammo"
})