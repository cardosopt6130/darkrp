--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/cl_inventory.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Inventory.Cache = Inventory.Cache || {}
local ui_slots = {}
local bank_ui_slots = {}

function Inventory.UpdateCache(slot, value)
	Inventory.Cache[slot] = value
end

function Inventory.GetCache()
	return Inventory.Cache
end

function Inventory.DecreaseAmount(slot)
	Inventory.Cache[slot]:DecreaseAmount()
end

local itemW, itemH = 60, 60
local perRow = 5

local grey = Color(45, 45, 45)

function Inventory.AddItems(fr, items_tbl, admin, limit, bank, item_w, item_h, options, ammo)
	local items = vgui.Create("DIconLayout", fr)
	items:SetSize(fr:GetWide() - 4, fr:GetTall() + 1)
	items:SetPos(2, 32)
	items:SetSpaceY(1)
	items:SetSpaceX(1)
	fr.slots = {}
	for i=1, limit or 25 do
		local v = items_tbl[i]
		local mdl = items:Add("InventorySlot")
		mdl:SetSlot(i)
		mdl.AdminMode = admin
		mdl.Bank = bank
		if options then
			mdl:Droppable('')
			mdl:Receiver('InventorySlot', function() end)
			mdl.Options = options
		end
		mdl.Ammo = ammo
		mdl:SetSize(item_w || itemW, item_h || itemH)
		if bank then
			bank_ui_slots[i] = mdl
		else
			ui_slots[i] = mdl
		end
		if istable(v) then
			mdl:SetItem(v)
			mdl:Refresh()
		end
		fr.slots[i] = mdl
	end
	fr:Refresh()
	fr.items = items
	return items
end

local function RemoveSlot(slot)
	if Inventory.Cache[slot].Tag == "drug" then
		Cloud.Waypoint.Remove("Drug Dealer")
	end
	Inventory.Cache[slot] = nil
	if ui_slots[slot] && IsValid(ui_slots[slot]) then
		ui_slots[slot]:SetItem(nil)
		ui_slots[slot]:Refresh()
	end
end

net.Receive("Inventory.ItemRemoved", function()
	if net.ReadBit() == 0 then
    	RemoveSlot(net.ReadUInt(6))
	else
		for i=1, net.ReadUInt(6) do
    		RemoveSlot(net.ReadUInt(6))
		end
	end
end)

net.Receive("Inventory.ItemAmounts", function()
	for i=1, net.ReadUInt(6) do
		local slot = net.ReadUInt(6)
		local amount_to_take = net.ReadUInt(5)
		if Inventory.Cache[slot].Amount > amount_to_take then
			Inventory.Cache[slot].Amount = Inventory.Cache[slot].Amount - amount_to_take 
			if IsValid(ui_slots[slot]) then
				ui_slots[slot]:Refresh()
			end
		else
			RemoveSlot(slot)
		end
	end
end)

net.Receive("Inventory.ItemAmount", function()
	local slot = net.ReadUInt(6)
	local new_amount = net.ReadUInt(5)
	Inventory.Cache[slot].Amount = new_amount
	if IsValid(ui_slots[slot]) then
		ui_slots[slot]:Refresh()
	end
end)

local fr
function Inventory.OpenMenu()
	if IsValid(fr) then return end
	local limit = Inventory.GetLimit(LocalPlayer()) 
	local rows = (limit / perRow) 
	fr = Cloud.CreateFrame((itemW * perRow) + (perRow + 3), (rows * itemH) + (33 + rows), "Inventory")
	Inventory.AddItems(fr, Inventory.Cache, false, limit)
	return fr
end

net.Receive("Inventory", function()
	Inventory.Cache = net.ReadInventory()
end)

local buttons_created = false

local function CreateContextInv()
	if IsValid(inv) then inv:Remove() end
	local limit = Inventory.GetLimit(LocalPlayer()) 
	inv = vgui.Create( "dank_ui.frame", g_ContextMenu )
	inv.NoPopUp = true
	inv:SetDraggable(false)
	inv:SetTitle("Inventory")
	inv:ShowCloseButton(false)
	inv:SetMouseInputEnabled(true)
	inv:InvalidateLayout(true)
	local rows = (limit / perRow) 
	inv:SetSize((itemW * perRow) + (perRow + 3), (rows * itemH) + (33 + rows))
	inv:SetPos(ScrW() / 2 - inv:GetWide() / 2, ScrH() - inv:GetTall())
	Inventory.AddItems(inv, Inventory.Cache, false, limit)
	
	if !buttons_created then
		local create_ship = vgui.Create("DButton", g_ContextMenu)
		create_ship:SetSkin("material_dark")
		create_ship:SetSize(inv:GetWide() / 2, 30)
		create_ship:SetPos(inv.x, inv.y - create_ship:GetTall())
		create_ship:SetText("Create Shipment")
		create_ship.DoClick = function()
			RunConsoleCommand("say" , "/createshipment")
		end

		local split_shit = vgui.Create("DButton", g_ContextMenu)
		split_shit:SetSkin("material_dark")
		split_shit:SetSize(create_ship:GetWide(), create_ship:GetTall())
		split_shit:SetPos(create_ship.x + create_ship:GetWide(), create_ship.y)
		split_shit:SetText("Split Shipment")
		split_shit.DoClick = function()
			RunConsoleCommand("say" , "/splitshipment")
		end
		buttons_created = true
	end
end

hook.Add("ContextMenuOpen", "Inventory.AddItems", function()
	if IsValid(inv) then
		Inventory.AddItems(inv, Inventory.Cache, false, Inventory.GetLimit(LocalPlayer()))
	else
		CreateContextInv()
	end
end)

hook.Add("OnContextMenuClose", "Inventory.RemoveUI", function()
	if IsValid(inv) and inv.items then
		inv.items:Remove()
	end
end)

local function HandleItem()
	local slot = net.ReadUInt(6)
	local item_data = net.ReadInventoryItem()
	local item = table.Copy(Inventory.GetItem(item_data.entity))
	item:ParseData(item_data)
	Inventory.Cache[slot] = item
	if IsValid(fr) || IsValid(inv) then
		if IsValid(ui_slots[slot]) then
			ui_slots[slot]:SetItem(item)
			ui_slots[slot]:Refresh()
		end
	end
end

net.Receive("Inventory.Item", function()
	if net.ReadBit() == 0 then
		HandleItem()
	else
		for i=1, net.ReadUInt(5) do
			HandleItem()
		end
	end
end)

function Inventory.DuelMenu(ent, items, bank_items, admin, title, options, options2, ammo, limit)
	if IsValid(inv) then
		inv:Remove()
	end
	if !limit then 
		limit = Inventory.GetLimit(LocalPlayer()) 
	end
	local rows = (limit / perRow) 
	local item_w, item_h = 100, 100
	local width_inv = (itemW * perRow) + (perRow + 3)
	local width_bank = (item_w * perRow) + (perRow + 3)
	local height_bank = (rows * item_h) + (33 + rows)
	local frame = Cloud.CreateFrame(width_bank, height_bank, title)
	frame:SetPos(ScrW() / 2 - ((width_bank + width_inv) / 2), ScrH() / 2 - height_bank /2)
	Inventory.AddItems(frame, bank_items, admin, limit, ent, item_w, item_h, options2, ammo)

	if IsValid(fr) then return end
	local limit = Inventory.GetLimit(LocalPlayer()) 
	local rows = (limit / perRow) 
	fr = Cloud.CreateFrame(width_inv, (rows * itemH) + (33 + rows), "Inventory")
	Inventory.AddItems(fr, items, admin, limit, nil, itemW, itemH, options)
	fr:SetPos(frame.x + frame:GetWide(), frame.y)

	frame.OnClose = function()
		fr:Remove()
	end
	fr.OnClose = function()
		frame:Remove()
	end
	return frame, fr
end

function Inventory.BankMenu(ent, items, bank_items, admin)
	local frame, bank = Inventory.DuelMenu(ent, items, bank_items, admin, 'Bank')

	local withdraw_all = vgui.Create("DButton", frame)
	withdraw_all:SetSize(100, 30)
	withdraw_all:SetPos(frame.btnClose.x - withdraw_all:GetWide(), 0)
	withdraw_all:SetText("Withdraw All")
	withdraw_all.DoClick = function()
		if Inventory.next_move >= CurTime() then return end
		Inventory.next_move = CurTime() + 1
		net.Start("Inventory.BankTransfer")
			net.WriteEntity(ent)
			net.WriteBool(true)
			net.WriteBool(false)
		net.SendToServer()
		local space = 0
		for k, v in pairs(ui_slots) do
			if !v:GetItem() then
				space = space + 1
			end
		end
		if space < 1 then return end
		local count = 0
		for k, v in pairs(bank_ui_slots) do
			v:SetItem(nil)
			v:Refresh()
			count = count + 1
			if count >= space then break end
		end
	end

	local deposit_all = vgui.Create("DButton", bank)
	deposit_all:SetSize(100, 30)
	deposit_all:SetPos(bank.btnClose.x - deposit_all:GetWide(), 0)
	deposit_all:SetText("Deposit All")
	deposit_all.DoClick = function()
		if Inventory.next_move >= CurTime() then return end
		Inventory.next_move = CurTime() + 1
		net.Start("Inventory.BankTransfer")
			net.WriteEntity(ent)
			net.WriteBool(true)
			net.WriteBool(true)
		net.SendToServer()
		local items = {}
		for k, v in pairs(ui_slots) do
			if v:GetItem() && v:GetItem().ShouldSave then
				table.insert(items, v:GetItem())
			end
		end
		if #items < 1 then return end
		for k, v in pairs(bank_ui_slots) do
			if !v:GetItem() then
				v:SetItem(items[1])
				v:Refresh()
				table.remove(items, 1)
			end
			if #items < 1 then break end
		end
	end
end

net.Receive("Inventory.Bank", function()
	local ent = net.ReadEntity()
	local items = net.ReadInventory()
	Inventory.BankMenu(ent, Inventory.Cache, items)
end)