--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/load_items.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Inventory.Registered = Inventory.Registered || {}

function Inventory.GetItem(entity)
	return Inventory.Registered[entity]
end

function Inventory.ClassToName(class)
	for entity, item in pairs(Inventory.Registered) do
		if item.Variations && item.Variations[class] then
			return item.Variations[class].name
		end
		if class == item:GetClass() then
			return item.Name
		end
	end
	local wep = weapons.GetStored(class)
	if wep && wep.PrintName then return wep.PrintName end
	return class
end

function Inventory.GetItemByClass(class)
	for entity, item in pairs(Inventory.Registered) do
		if item.Variations && item.Variations[class] then
			return item
		end
		if class == item:GetClass() then
			return item
		end
	end
	local wep = weapons.GetStored(class)
	if wep then 
		return Inventory.GetItem("spawned_weapon")
	end
end

for _, filename in ipairs(file.Find( GM.FolderName.."/gamemode/base/inventory/items/*.lua", "LUA")) do
	ITEM = {}	
	Cloud.IncludeSH(GM.FolderName.."/gamemode/base/inventory/items/" .. filename)
	local wrapped_item = Inventory.Wrap(ITEM)
	Inventory.Registered[wrapped_item:GetEntity()] = ITEM
	if ITEM.Base then
		local base = Inventory.Registered[ITEM.Base]
		if base then
			setmetatable(ITEM, { __index = base } )
		else
			ErrorNoHalt( "Inventory | No base found "..ITEM.Base.."!" )
		end
	end
	print("Inventory | Loaded item " .. wrapped_item:GetEntity())
	ITEM = nil
end

function Inventory.RegisterItem(tbl)
	ITEM = table.Copy(tbl)
	local wrapped_item = Inventory.Wrap(ITEM)
	Inventory.Registered[wrapped_item:GetEntity()] = ITEM
	if ITEM.Base then
		local base = Inventory.Registered[ITEM.Base]
		if base then
			setmetatable(ITEM, { __index = base } )
		else
			ErrorNoHalt( "Inventory | No base found "..ITEM.Base.."!" )
		end
	end
	print("Inventory | Loaded item " .. wrapped_item:GetEntity())
	ITEM = nil
end