--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/cl_slot.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local PANEL = {}

AccessorFunc( PANEL, "Item", "Item" )
AccessorFunc( PANEL, "Slot", "Slot", FORCE_NUMBER )

Inventory.next_move = 0
local tip

local function SendMove(ent, is_deposit, slot1, slot2)
	net.Start("Inventory.BankTransfer")
		net.WriteEntity(ent)
		net.WriteBool(false)
		net.WriteBool(is_deposit)
		net.WriteUInt(slot1, 6)
		net.WriteUInt(slot2, 6)
	net.SendToServer()
end

function PANEL:Init()
	if !IsValid(tip) then
		tip = vgui.Create("DPanel")
		tip:SetSize(180, 180)
		tip:SetSkin("material_dark")
		tip:SetVisible(false)
		tip:SetDrawOnTop(true)
		local txt = "Drag to move\nMiddle click to drop\nRight click for options\nDouble click for use"
		tip.tutorial = DankUI.CreateLabel(tip, txt, "DermaDefault")
		tip.tutorial:SetPos(5, tip:GetTall() - tip.tutorial:GetTall() - 5)
	end
	self:SetSkin("material_dark")
	self.BaseClass.Init( self )
	self:Droppable("InventorySlot")
	self:Receiver("InventorySlot", function(receiver, pnls, dropped)
		if !dropped then return end
		if Inventory.next_move >= CurTime() then return end
		Inventory.next_move = CurTime() + 1
		if self.AdminMode then return end
		local location = pnls[1]
		if receiver == location then return end //location is the item you drag

		local item = location:GetItem()
		if !item then return end
		local target_item = receiver:GetItem() || nil
		if !receiver.Bank && location.Bank then
			if !item.ShouldSave then return end
			if target_item && !target_item.ShouldSave then return end
			Inventory.UpdateCache(receiver:GetSlot(), item) 
			//RunConsoleCommand("inv_bank_transfer", location:GetSlot(), receiver:GetSlot(), 0) // withdraw
			SendMove(location.Bank, false, location:GetSlot(), receiver:GetSlot())
		elseif !location.Bank && receiver.Bank then
			if !item.ShouldSave then return end
			if target_item && !target_item.ShouldSave then return end
			Inventory.UpdateCache(location:GetSlot(), target_item) 
			//RunConsoleCommand("inv_bank_transfer", location:GetSlot(), receiver:GetSlot(), 1) // deposit
			SendMove(receiver.Bank, true, location:GetSlot(), receiver:GetSlot())
		elseif !location.Bank && !receiver.Bank then
			if target_item && item.Stackable && item:GetClass() == target_item:GetClass() && item:GetEntity() != "spawned_weapon" && item:GetEntity() != "spawned_shipment" && target_item:GetAmount() < item.MaxStack then
				if target_item:GetAmount() + item:GetAmount() > item.MaxStack then
					local amount_to_take = item.MaxStack - target_item:GetAmount()
					local new_amount = item:GetAmount() - amount_to_take
					Inventory.Cache[location:GetSlot()].Amount = new_amount
					Inventory.Cache[receiver:GetSlot()].Amount = item.MaxStack
				else
					location:SetItem(nil)
					location:Refresh()
					Inventory.Cache[receiver:GetSlot()].Amount = item:GetAmount() + target_item:GetAmount()
					Inventory.UpdateCache(location:GetSlot(), nil) 
					receiver:Refresh()
				end
				RunConsoleCommand("inv_move", 0, location:GetSlot(), receiver:GetSlot())
				return
			else
				Inventory.UpdateCache(receiver:GetSlot(), item)
				Inventory.UpdateCache(location:GetSlot(), target_item) 
				RunConsoleCommand("inv_move", 0, location:GetSlot(), receiver:GetSlot())
			end
		elseif location.Bank && receiver.Bank then
			RunConsoleCommand("inv_move", 1, location:GetSlot(), receiver:GetSlot())
		end
		location:SetItem(target_item)
		receiver:SetItem(item)
		receiver:Refresh()
		location:Refresh()
	end)
end

local grey2 = Color(55, 55, 55, 110)
function PANEL:Paint( w, h )
	draw.RoundedBox(0, 0, 0, w, h, self.Hovered and grey2 or DankUI.Panel)
	surface.SetDrawColor(DankUI.Outline)
	surface.DrawOutlinedRect(0, 0, w, h)
	if self:GetItem() then
		local color = Inventory.RarityColors[self:GetItem():GetRarity()]
		draw.BottomGradient(self, self, w, h, color)
	end
	self.BaseClass.Paint( self, w, h )
	if self:GetItem() and self:GetItem():GetAmount() > 1 then
		draw.SimpleTextOutlined("x"..self:GetItem():GetAmount(), "DermaDefault", w, h, DankUI.TextColor, TEXT_ALIGN_RIGHT, TEXT_ALIGN_BOTTOM, 0.5, DankUI.Outline)
	end
end

local function FormatAmmo(ammo)
	local str = ""
	for k, v in pairs(ammo) do
		str = str .. k .. ": " .. v .. "\n"
	end
	return str
end

function PANEL:OnCursorEntered()
	if self:GetItem() then
		if !IsValid(tip) then return end
		tip:SetVisible(true)
		if IsValid(tip.title) then tip.title:Remove() end
		tip.title = DankUI.CreateLabel(tip, "Type: " .. self:GetItem().Name, "dank_ui.small")

		if IsValid(tip.class) then tip.class:Remove() end
		tip.class = DankUI.CreateLabel(tip, (Inventory.GetWeaponName(self:GetItem():GetClass()) || self:GetItem().Name), "dank_ui.20")

		if IsValid(tip.amount) then tip.amount:Remove() end
		tip.amount = DankUI.CreateLabel(tip, "Amount: " .. self:GetItem():GetAmount(), "dank_ui.small")

		if IsValid(tip.save) then tip.save:Remove() end
		tip.save = DankUI.CreateLabel(tip, "Saves: " .. (self:GetItem().ShouldSave && "Yes" || "No"), "dank_ui.small")

		if IsValid(tip.ammo) then tip.ammo:Remove() end
		if self.Ammo && self.Ammo[self:GetSlot()] then
			tip.ammo= DankUI.CreateLabel(tip, FormatAmmo(self.Ammo[self:GetSlot()]), "DermaDefault")
		end

		local x, y = gui.MousePos()
		local w1, w2 = tip.title:GetWide() + 10, tip.class:GetWide() + 10
		tip:SetWide(w1 > w2 && w1 || w2, tip.tutorial:GetWide(), 9999)
		tip:SetPos(x, y - tip:GetTall())
		tip.class:SetPos(5, 5)
		tip.title:SetPos(5, tip.class:GetTall() + tip.class.y)
		tip.amount:SetPos(5, tip.title:GetTall() + tip.title.y)
		tip.save:SetPos(5, tip.amount:GetTall() + tip.amount.y)
		if IsValid(tip.ammo) then
			tip.ammo:SetPos(5, tip:GetTall() - tip.ammo:GetTall() + 5)
			tip.tutorial:SetVisible(false)
		else
			tip.tutorial:SetVisible(true)
		end
	end
end

function PANEL:OnCursorExited()
	if IsValid(tip) then
		tip:SetVisible(false)
	end
end

function PANEL:OnCursorMoved()
	local x, y = gui.MousePos()
	if IsValid(tip) then
		tip:SetPos( x, y - tip:GetTall() )
	end
end

function PANEL:Refresh()
	local item = self:GetItem()

	if item then
		self:SetModel( item:GetModel() )
		if item.Color then
			//self.Entity:SetRenderMode(RENDERMODE_TRANSCOLOR)
			self:SetColor(item.Color)
		end

		if item.Material then
			self.Entity:SetMaterial(item.Material)
		end

		if item.Variations && item.Variations[item:GetClass()] then
			if item.Variations[item:GetClass()].color && item.Entity != 'plant' then
				self:SetColor(item.Variations[item:GetClass()].color)
			end
		end

		local min, max = self.Entity:GetRenderBounds()
		self:SetCamPos( Vector( 0.55, 0.55, 0.55 ) * min:Distance( max ) )
		self:SetLookAt( ( min + max ) / 2 )
	else
		if IsValid(self.Entity) then
			self.Entity:Remove()
		end
		self.Entity = nil
		self:SetTooltip(nil)
	end
end

function PANEL:DoDoubleClick()
	if self.AdminMode then return end
	if !self:GetItem() then return end
	if LocalPlayer():Team() == TEAM_MUTANT then return end
	if Inventory.next_move >= CurTime() then return end
	if !self:GetItem().CanUse then return end
	if isfunction(self:GetItem().CanUse) && !self:GetItem():CanUse(LocalPlayer()) then return end
	if self.Bank then return end
	Inventory.next_move = CurTime() + 1
	RunConsoleCommand("inv_use", self.Bank && 1 || 0, self:GetSlot())
	if self:GetItem():GetAmount() > 1 then
		Inventory.DecreaseAmount(self:GetSlot())
		return
	end
	Inventory.UpdateCache(self:GetSlot(), nil)
	self:SetItem(nil)
	self:Refresh()
end

local last_drop = {}
net.Receive("Inventory.FailDrop", function()
	local undo = last_drop[#last_drop]
	Inventory.UpdateCache(undo.slot, undo.item)
end)

function PANEL:DoMiddleClick()
	if self.AdminMode then return end
	if !self:GetItem() || self:GetItem().BlockDrop then return end
	if self:GetItem().CanDrop && !self:GetItem():CanDrop(LocalPlayer()) then return end
	if Inventory.next_move >= CurTime() then return end
	if self.Bank then return end
	Inventory.next_move = CurTime() + 1
	RunConsoleCommand("inv_drop", self.Bank && 1 || 0, self:GetSlot())
	table.insert(last_drop, {item=table.Copy(self:GetItem()), slot=self:GetSlot()})
	Inventory.UpdateCache(self:GetSlot(), nil)
	self:SetItem(nil)
	self:Refresh()
end

function PANEL:OnRemove()
	if ( IsValid( self.Entity ) ) then
		self.Entity:Remove()
	end
	if IsValid(tip) then
		tip:Remove()
		tip = nil
	end
end

function PANEL:DoRightClick()
	local menu = DermaMenu()
	if self:GetItem() then
		if self.Options then
			for k, v in pairs(self.Options) do
				menu:AddOption(k, function()
					v.func(self)
				end)
			end
		else
			if !self.AdminMode then
				menu:AddOption("Use", function() 
					self:DoDoubleClick()
				end):SetIcon( "icon16/wrench.png" )
				menu:AddSpacer()
				menu:AddOption("Drop", function() 
					self:DoMiddleClick()
				end):SetIcon( "icon16/arrow_out.png" )
				menu:AddSpacer()
				menu:AddOption("Split", function() 
					if table.Count(Inventory.Cache) >= Inventory.GetLimit(LocalPlayer()) then
						return
					end
					local entry = vgui.Create("dank_ui.entry")
					entry:SetNumeric(true)
					entry:SetQuestion('How many would you like to split off? (' .. self:GetItem().Amount .. ')')
					entry.Entry:SetValue(math.floor(self:GetItem().Amount / 2))
					local slot, item, bank = self:GetSlot(), self:GetItem(), self.Bank
					entry.OnYes = function(s, val)
						local value = tonumber(val)
						value = math.floor(value)
						if !value || !Inventory.Cache[slot] || value >= Inventory.Cache[slot].Amount || value < 0 || Inventory.Cache[slot].Amount < 2 then return end
						RunConsoleCommand('inv_split', bank && 1 || 0, slot, value)
						Inventory.Cache[slot].Amount = Inventory.Cache[slot].Amount - value
					end
				end):SetIcon( "icon16/arrow_divide.png" )
				menu:AddSpacer()
			end
			menu:AddOption("Destroy", function() 
				if Inventory.next_move >= CurTime() then return end
				Inventory.next_move = CurTime() + 1
				if self.AdminMode then
					RunConsoleCommand("inv_admin_destroy", self.Bank && 1 || 0, self:GetSlot())
				else
					RunConsoleCommand("inv_destroy", self.Bank && 1 || 0, self:GetSlot())
					if !self.Bank then
						Inventory.UpdateCache(self:GetSlot(), nil)
					end
				end
				self:SetItem(nil)
				self:Refresh()
			end):SetIcon( "icon16/delete.png" )
		end
		menu:Open()
	end
end
vgui.Register("InventorySlot", PANEL, "DModelPanel" )
