--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/items/_meth.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

ITEM.Name = "Meth"
ITEM.Description = "Meth"
ITEM.Model = "models/props_junk/rock001a.mdl"
ITEM.Color = Color(1, 241, 249, 255)
ITEM.Material = "models/shiny"
ITEM.Stackable = true
ITEM.Entity = "eml_meth"
ITEM.Class = "meth"
ITEM.CanUse = false
ITEM.Tag = "drug"
ITEM.MaxStack = 20
ITEM.Base = "base_commodity"
ITEM.ShouldSave = false
ITEM.Rarity = Loot.UNCOMMON

function ITEM:PostSpawn(ent)
	ent:SetAmount(self:GetAmount())
end

function ITEM:ParseEntAmount(ent)
	return ent:GetAmount()
end

function ITEM:SetEntAmount(ent, num)
	return ent:SetAmount(num)
end