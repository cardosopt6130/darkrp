--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/items/_junk.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

ITEM.Name = "Junk"
ITEM.Description = "Ones man's junk is another man's treasure..."
ITEM.Model = "models/props_vehicles/carparts_axel01a.mdl"
ITEM.Stackable = true 
ITEM.Entity = "junk"
ITEM.Class = "junk"
ITEM.CanUse = false
ITEM.Tag = "junk"
ITEM.Base = "base_commodity"
ITEM.Rarity = Loot.COMMON
ITEM.ShouldSave = true 

function ITEM:ParseEntAmount(ent)
	return 1
end