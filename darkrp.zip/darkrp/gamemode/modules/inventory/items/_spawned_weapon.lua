--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/items/_spawned_weapon.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

ITEM.Name = "Weapon"
ITEM.Description = "Weapon"
ITEM.Model = "models/weapons/w_winchester_1873.mdl"
ITEM.Stackable = true
ITEM.Entity = "spawned_weapon"
ITEM.CanUse = true
ITEM.BlockAutoStack = true

function ITEM:Spawn(ply)
	local wep = ents.Create("spawned_weapon")
	local trace = {}
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 85
	trace.filter = ply
	local tr = util.TraceLine(trace)
	wep:SetPos(tr.HitPos + Vector(0, 0, 10))
	wep:SetWeaponClass(self.Class)
	wep:SetModel(self.Model)
	wep.nodupe = true
	wep.clip1 = self.Data.clip1
	wep.clip2 = self.Data.clip2
	wep.ammoadd = self.Data.extra_ammo or 0
	wep:Setamount(self:GetAmount() or 1)
	wep:Spawn()
	return wep
end

function ITEM:ParseEntAmount(ent)
	return ent:Getamount()
end

function ITEM:CanUse(ply)
	return !ply:isArrested()
end

function ITEM:CanDrop(ply)
	return !ply:isArrested()
end

function ITEM:Use(ply)
	local given_wep = ply:Give(self.Class, true)
	local new = true
	if !IsValid(given_wep) then
		new = false
		given_wep = ply:GetWeapon(self.Class)
	end
	if IsValid(given_wep) then
		if new then
			given_wep:SetClip1(self.Data.clip1 or 0)
			given_wep:SetClip2(self.Data.clip2 or -1)
		end
		ply:GiveAmmo(self.Data.extra_ammo or 0, given_wep:GetPrimaryAmmoType())
	end
end

function ITEM:Save(ply, slot, count, clip1, clip2, class, entity, model, extra_ammo)
	if !clip1 then clip1=0 end
	if !clip2 then clip2=0 end
	if !class then class=self.Class end
	if !entity then entity=self.Entity end
	if !model then model=self.Model end
	if !extra_ammo then extra_ammo=0 end
	Cloud.MySQL.Q("INSERT INTO inventory (steamid, entity, class, clip1, clip2, model, amount, extra_ammo, slot) VALUES (?, ?, ?, '"..clip1.."', '"..clip2.."', ?, '"..count.."', '"..extra_ammo.."', '"..slot.."')", ply:SteamID64(), entity, class, model, false)
    self:ParseData({clip1=clip1, clip2=clip2, class=class, entity=entity, model=model, amount=count, extra_ammo=extra_ammo})
	return self
end

function ITEM:SaveEnt(ply, ent, slot)
    local clip1, clip2 = math.Round(ent.clip1 or 0), math.Round(ent.clip2 or -1)
    local count = ent:Getamount()
    local entity, model, class = ent:GetClass(), ent:GetModel(), ent:GetWeaponClass()
    local extra_ammo = ent.ammoadd or -1
	ent:Remove()
    return self:Save(ply, slot, count, clip1, clip2, class, entity, model, extra_ammo)
end