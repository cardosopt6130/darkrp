--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/items/_base_commodity.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

ITEM.CanUse = false
ITEM.Entity = "base_commodity"
ITEM.CountClass = "base_commodity"

function ITEM:Spawn(ply)
	local wep = ents.Create(self.Entity)
	local trace = {}
	trace.start = ply:EyePos()
	trace.endpos = trace.start + ply:GetAimVector() * 85
	trace.filter = ply
	local tr = util.TraceLine(trace)
	wep:SetPos(tr.HitPos + Vector(0, 0, 10))
	if self.Variations && self.Variations[self.Class] then
		if self.Variations[self.Class].model then
			wep.Model = self.Variations[self.Class].model
		end
		if self.Variations[self.Class].scale then
			wep:SetModelScale(self.Variations[self.Class].scale)
		end
		if self.Variations[self.Class].color then
			wep:SetColor(self.Variations[self.Class].color)
		end
		if self.Variations[self.Class].material then
			wep:SetMaterial(self.Variations[self.Class].material)
		end
	end
	wep:Spawn()
	if self.Stackable then
		wep:SetAmount(self:GetAmount())
	end
	wep.ItemClass = self.Class
	wep.CountClass = self.CountClass
	return wep
end

function ITEM:Save(ply, slot, amount, class, model)
    self:ParseData({entity=self.Entity, model= model || self.Model, amount=amount, class=class || self.Class})
	if self.ShouldSave then
		Cloud.MySQL.Q("INSERT INTO inventory (steamid, entity, model, amount, slot, class) VALUES (?, ?, ?, '"..amount.."', '"..slot.."', ?)", ply:SteamID64(), self.Entity, model || self.Model, class || self.Class, false)
	end
	return self
end

function ITEM:SaveEnt(ply, ent, slot)
	local amount_taken = 1
	local model = ent:GetModel() || self.Model
	local class = ent.ItemClass || self.Class
	if self.Stackable then
		if ent:GetAmount() > self.MaxStack then
			ent:SetAmount(ent:GetAmount() - self.MaxStack)
			amount_taken = self.MaxStack
		else
			amount_taken = ent:GetAmount()
			ent:Remove()
		end
	else
		ent:Remove()
	end
	if self.ShouldSave then
		return self:Save(ply, slot, amount_taken, class, model)
	else
    	self:ParseData({entity=self.Entity, model=model, amount=amount_taken, class=class})
		return self
	end
end