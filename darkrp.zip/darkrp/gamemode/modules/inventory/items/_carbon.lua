--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/items/_carbon.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

ITEM.Name = "Carbon"
ITEM.Description = "A strong material."
ITEM.Model = "models/props_wasteland/rockgranite03a.mdl"
ITEM.Material = "phoenix_storms/metalset_1-2"
ITEM.Stackable = false
ITEM.Entity = "carbon"
ITEM.Class = "carbon"
ITEM.CanUse = false
ITEM.Tag = "resource"
ITEM.Base = "base_commodity"
ITEM.BlockDrop = true
ITEM.ShouldSave = true 
ITEM.Rarity = Loot.UNCOMMON

function ITEM:ParseEntAmount(ent)
	return 1
end