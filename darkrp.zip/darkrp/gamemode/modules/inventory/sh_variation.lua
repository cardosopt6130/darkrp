--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/sh_variation.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function Inventory.ApplyVariationToModel(item, self)
	local class = item:GetClass()
	if item.Variations && item.Variations[class] then
		self:SetModel(item.Variations[class].model)
		if item.Variations[class].scale then
			self:SetModelScale(item.Variations[class].scale)
		end
		if item.Variations[class].color then
			self:SetColor(item.Variations[class].color)
		end
		item.Rarity = item.Variations[class].rarity
	elseif item:GetEntity() == "spawned_weapon" then
		local wep = weapons.GetStored(item:GetClass())
		if wep && wep.WorldModel then
			self:SetModel(wep.WorldModel)
			self:PhysicsInit(SOLID_VPHYSICS)
			item.Model = wep.WorldModel
			local phys = self:GetPhysicsObject()
			if (phys:IsValid()) then
				phys:Wake()
			end
		end
	end
end