--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/sh_cfg.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Inventory = Inventory or {}
Loot = Loot || {COMMON=1, UNCOMMON=2, RARE=3, EPIC=4}

local string_to_id = {
	["error"] = 0,
	["common"] = 1,
	["uncommon"] = 2,
	["rare"] = 3,
	["epic"] = 4,
}
Loot.StringToID = string_to_id

Loot.IDToString = {
	[0] = "Error",
	[1] = "Common",
	[2] = "Uncommon",
	[3] = "Rare",
	[4] = "Epic"
}

Loot.Table = {
	[Loot.COMMON] = {
		{entity="junk"}
	},
	[Loot.UNCOMMON] = {
		{entity="spawned_weapon", class="m9k_m92beretta"}
	},
	[Loot.RARE] = {
		{entity="eml_meth"}
	},
	[Loot.EPIC] = {
		{entity="weed"},
		{entity="spawned_weapon", class="m9k_nitro"},
		{entity="cocaine_pack"}
	},
}

Loot.EmptyTable = {
	[Loot.COMMON] = {},
	[Loot.UNCOMMON] = {},
	[Loot.RARE] = {},
	[Loot.EPIC] = {},
}

local groupInvSize = {
    ["user"] = 10,
    ["vip"] = 15,
    ["mod"] = 20,
    ["admin"] = 20,
    ["admin+"] = 20,
    ["headadmin"] = 20,
    ["manager"] = 20,
    ["nino"] = 20,
    ["owner"] = 20,
    ["superadmin"] = 20,
    ["ultimatevip"] = 20
}

function Inventory.GetLimit(ply)
    return groupInvSize[ply:GetUserGroup()] or 10
end

Inventory.RarityColors = {
    [Loot.EPIC] = Color(100, 50, 50, 100),
    [Loot.RARE] = Color(148,0,211, 100),
    [Loot.UNCOMMON] = Color(50, 50, 100, 100),
    [0] = Color(50, 255, 50, 100),
    [Loot.COMMON] = Color(90, 90, 90, 100)
}

local ITEM = {}

ITEM.__index = ITEM

ITEM.Name = "Inventory Item Base"
ITEM.Model = "models/error.mdl"
ITEM.Stackable = false
ITEM.Amount = 1 
ITEM.MaxStack = 10 
ITEM.DropStack = false
ITEM.ShouldSave = true

function ITEM:GetClass()
	return self.Class 
end

function ITEM:GetEntity()
	return self.Entity
end

function ITEM:GetModel()
	return self.Model
end

function ITEM:GetName()
	return self.Name
end

function ITEM:IsValid()
	return true
end

function ITEM:GetAmount()
	return self.Amount
end

function ITEM:ParseEntAmount()
	return 1
end

function ITEM:DecreaseAmount()
	self.Amount = self.Amount - 1
end 

function ITEM:Spawn()
	print("SPAWN: NOT IMPLEMENTED")
end

function ITEM:Use()
	print("Use: NOT IMPLEMENTED")
end

function ITEM:Save()
	print("SAVE DATA: NOT IMPLEMENTED")
end

function ITEM:SaveEnt()
	print("SAVE ENT: NOT IMPLEMENTED")
end 

function ITEM:GetRarity()
	return self.Rarity or Loot.COMMON
end

function ITEM:ParseData(data) 
    self.Data = data
    if data.amount then
        self.Amount = data.amount
    end
	if data.class then
		self.Class = data.class 
	end
	if self.Variations && self.Variations[data.class] then
		self.Model = self.Variations[data.class].model
		self.Name = self.Variations[data.class].name
		self.Rarity = self.Variations[data.class].rarity
	elseif data.model then
		self.Model = data.model
	end
	if Inventory.Rarities[data.class] then
		self.Rarity = string_to_id[Inventory.Rarities[data.class]]
	end
end 
function ITEM:LoadData()
	print("LOAD DATA: NOT IMPLEMENTED") 
end

function Inventory.Wrap(tbl)
	return setmetatable(tbl, ITEM)
end 