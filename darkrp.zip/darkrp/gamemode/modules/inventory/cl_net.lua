--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/inventory/cl_net.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function net.ReadInventoryItem()
	return {amount=net.ReadUInt(5), entity=net.ReadString(), class=net.ReadString(), model=net.ReadString()}
end

function net.ReadInventory()
	local count = net.ReadUInt(5)
	local items = {}
	for i=1, count do
		local slot = net.ReadUInt(6)
		local item_data = net.ReadInventoryItem()
		local base_item = Inventory.GetItem(item_data.entity) || Inventory.GetItemByClass(item_data.class)
		local item = table.Copy(base_item)
		item:ParseData(item_data)
		items[slot] = item 
	end
	return items
end