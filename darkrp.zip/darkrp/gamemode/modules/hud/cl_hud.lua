--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/hud/cl_hud.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local Color = Color
local CurTime = CurTime
local DarkRP = DarkRP
local draw = draw
local hook = hook
local IsValid = IsValid
local localplayer
local math = math
local ScrW, ScrH = ScrW, ScrH
local SortedPairs = SortedPairs
local surface = surface
local table = table
local timer = timer

local table_Empty = table.Empty
local input_IsMouseDown = input.IsMouseDown
local gui_EnableScreenClicker = gui.EnableScreenClicker
local gui_MousePos = gui.MousePos
local math_Round = math.Round
local SortedPairsByMemberValue = SortedPairsByMemberValue
local pairs = pairs
local team_GetColor = team.GetColor
local is_color = IsColor
local math_Clamp = math.Clamp
local chat_GetChatBoxPos = chat.GetChatBoxPos
local math_sin = math.sin
local table_Copy = table.Copy
local Gangs_GetColor
local IsLineOfSightClear = ENTITY.IsLineOfSightClear
local DistToSqr = VECTOR.DistToSqr
local EyePos = ENTITY.EyePos
local util_TraceLine = util.TraceLine

local draw_SimpleText 				= draw.SimpleText
local draw_SimpleTextOutlined 		= draw.SimpleTextOutlined
local draw_RoundedBox               = draw.RoundedBox

local surface_DrawTexturedRectRotated = surface.DrawTexturedRectRotated
local surface_SetTexture            = surface.SetTexture
local surface_SetDrawColor 			= surface.SetDrawColor
local surface_DrawTexturedRect 		= surface.DrawTexturedRect
local surface_GetTextSize 			= surface.GetTextSize
local surface_SetFont 				= surface.SetFont
local surface_SetMaterial 			= surface.SetMaterial
local surface_DrawOutlinedRect 		= surface.DrawOutlinedRect
local surface_SetTextPos			= surface.SetTextPos
local surface_SetTextColor 			= surface.SetTextColor
local surface_DrawText 				= surface.DrawText

local textCol = Color(215,215,215)
local navyBlue = Color(44, 61, 74,200)
local red2 = Color(255, 0, 0, 255)
local color_black = Color(0, 0, 0, 200)
local color_white = Color(255, 255, 255)
local gold = Color(212,175,55)
local hud_white = Color(240, 240, 240)
local darkNavy = Color( 38, 42, 46)
local lightNavy = Color( 47, 52, 57)
local red = Color(160, 50, 50)
local lightBlue = Color(20, 80, 207)
local grey_bg = Color(20, 20, 20, 200)

local Scrw, Scrh, RelativeX, RelativeY
local salary = "45"
local rpname = "Unknown"

surface.CreateFont("cg.font.20", {
	font = "roboto",
	size = 20,
	weight = 400
})

surface.CreateFont("cg.font.18", {
	font = "roboto",
	size = 18,
	weight = 400
})

surface.CreateFont("cg.font.24", {
	font = "roboto",
	size = 24,
	weight = 400
})

surface.CreateFont("cg.font.14", {
	font = "roboto",
	size = 14,
	weight = 400
})

surface.CreateFont("cg.font.12", {
	font = "roboto",
	size = 12,
	weight = 400
})
--[[---------------------------------------------------------------------------
HUD separate Elements
---------------------------------------------------------------------------]]

local strs = {
	[0] = "Waiting for other terrorists to join...",
	[1] = "Find the air drop and gather the supplies needed.",
}

local cache_id
local desc_cache = ""
local radio_red = Color( 255, 0, 0 )
local input_LookupBinding = input.LookupBinding

local function Agenda()
    if shouldDraw == false then return end

	if LocalPlayer():GetNetVar("mission") && LocalPlayer():isTerrorist() then
		local mission = Terrorist.Missions[LocalPlayer():GetNetVar("mission")]
		if !mission then return end
		draw_RoundedBox(0, 12, 12, 456, 100, grey_bg)
		draw_RoundedBox(0, 12, 12, 456, 23, grey_bg)
		surface_SetDrawColor(color_black)
		surface_DrawOutlinedRect(12, 12, 456, 100)
		surface_DrawOutlinedRect(12, 12, 456, 23)
		draw.DrawNonParsedText("[Mission] " .. mission.name, "cg.font.20", 20, 12, textCol, 0)
		if strs[LocalPlayer():GetNetVar("missionStage")] then
			draw.DrawNonParsedText(strs[LocalPlayer():GetNetVar("missionStage")], "cg.font.18", 20, 38, textCol, 0)
		else
			if !cache_id || cache_id != LocalPlayer():GetNetVar("mission") then
				local wrap = D3A.WordWrap("cg.font.20", mission.desc, 456)
				desc_cache = table.concat(wrap, "\n")
				cache_id = LocalPlayer():GetNetVar("mission")
			end
			draw.DrawNonParsedText(desc_cache, "cg.font.18", 20, 38, textCol, 0)
		end
	else
		local agenda = localplayer:getAgendaTable()
		if !agenda && localplayer:isCP() then
			agenda = DarkRP.GetAgenda(TEAM_POLICE)
		end
		if not agenda then return end
		local agendaText = DarkRP.textWrap((localplayer:getDarkRPVar("agenda") or ""):gsub("//", "\n"):gsub("\\n", "\n"), "DarkRPHUD1", 440)

		draw_RoundedBox(0, 12, 12, 456, 100, grey_bg)
		draw_RoundedBox(0, 12, 12, 456, 23, navyBlue)

		surface_SetDrawColor(color_black)
		surface_DrawOutlinedRect(12, 12, 456, 100)
		surface_DrawOutlinedRect(12, 12, 456, 23)

		draw.DrawNonParsedText(agenda.Title, "cg.font.20", 20, 12, textCol, 0)
		draw.DrawNonParsedText(agendaText, "cg.font.18", 20, 38, textCol, 0)
	end
	if LocalPlayer():isCP() then
		draw_SimpleText("Radio: "..(LocalPlayer().Radio && "Enabled" || "Disabled") .. " [ALT + E]", "ChatFont", 10, 115, radio_red, nil, false)
	end
end

local VoiceChatTexture = surface.GetTextureID("voice/icntlk_pl")
local function DrawVoiceChat()
    if localplayer.DRPIsTalking then
        local _, chboxY = chat_GetChatBoxPos()

        local Rotating = math_sin(CurTime() * 3)
        local backwards = 0

        if Rotating < 0 then
            Rotating = 1 - (1 + Rotating)
            backwards = 180
        end

        surface_SetTexture(VoiceChatTexture)
        surface_SetDrawColor(255,255,255)
        surface_DrawTexturedRectRotated(Scrw - 100, chboxY, Rotating * 96, 96, backwards)
    end
end

local lockdown = false

net.Receive("DarkRP.EndLockdown", function()
    lockdown = false
    if timer.Exists("Lockdown") then
        timer.Remove("Lockdown")
    end
end)

net.Receive("DarkRP.Lockdown", function()
    lockdown = true
    surface.PlaySound(GAMEMODE.Config.lockdownsound)
    timer.Create("Lockdown", 180, 1, function()
        lockdown = false
    end)
end)

local function LockDown()
    if lockdown then
        if shouldDraw == false then return end
        draw.DrawNonParsedText(DarkRP.getPhrase("lockdown_started"), "ScoreboardSubtitle", Scrw - 5, 5, red, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
    end
end

local Arrested = function() end

local arrested_white = Color(255, 255, 255)

net.Receive("GotArrested", function()
    local StartArrested = CurTime()
    local ArrestedUntil = net.ReadFloat()

    Arrested = function()
        if shouldDraw == false then return end

        if CurTime() - StartArrested <= ArrestedUntil and localplayer:getDarkRPVar("arrested") then
            draw.DrawNonParsedText(DarkRP.getPhrase("youre_arrested", math.ceil((ArrestedUntil - (CurTime() - StartArrested)) * 1 / game.GetTimeScale())), "DarkRPHUD1", Scrw / 2, Scrh - Scrh / 12, arrested_white, 1)
        elseif not localplayer:getDarkRPVar("Arrested") then
            Arrested = function() end
        end
    end
end)

local AdminTell = function() end

net.Receive("AdminTell", function()
    timer.Remove("DarkRP_AdminTell")
    local Message = net.ReadString()

    AdminTell = function()
        draw_RoundedBox(0, 10, 10, Scrw - 20, 110, grey_bg)
		surface_SetDrawColor(color_black)
		surface_DrawOutlinedRect(10, 10, Scrw - 20, 110)
        draw.DrawNonParsedText("Notice", "GModToolName", Scrw / 2 + 10, 8, textCol, 1)
        draw.DrawNonParsedText(Message, "cg.font.20", Scrw / 2 + 10, 85, textCol, 1)
    end

    timer.Create("DarkRP_AdminTell", 10, 1, function()
        AdminTell = function() end
    end)
end)

--[[---------------------------------------------------------------------------
Drawing the HUD elements such as Health etc.
---------------------------------------------------------------------------]]
local w, h = 332, 120

DarkRP.Avatar = DarkRP.Avatar || false
local color_white2 = Color(255, 255, 255)
local function DrawAvatar()
	if DarkRP.Avatar then return end
	DarkRP.Avatar = vgui.Create( "AvatarImage", Panel )
	DarkRP.Avatar:SetSize( 64, 64 )
	DarkRP.Avatar:SetPos( RelativeX + 10, RelativeY + 5)
	DarkRP.Avatar:SetPlayer( LocalPlayer(), 64 )
	local pnl = vgui.Create("DPanel", DarkRP.Avatar)
	pnl:SetSize(DarkRP.Avatar:GetSize())
	pnl.Paint = function(s, w, h)
		if LocalPlayer():GetNetVar("wanted") then
			draw_RoundedBox(0, 0, 0, w, h, grey_bg)
			draw_SimpleTextOutlined("!", "GModToolName", w/2, h/2, red, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_white2)
		end
	end
end

concommand.Add("_remove_avatar", function()
    DarkRP.Avatar:Remove()
	DarkRP.Avatar = nil
end)

local name_th_cache = 20
local bar_h = 10
local Page = Material("icon16/page_white_text.png")
local function DrawHUD()
	if Scrw != ScrW() && DarkRP.Avatar then
		DarkRP.Avatar:Remove()
		DarkRP.Avatar = nil
	end
	if Scrh <= 600 then 
		h = 100
	end
	w = math_Clamp(Scrw * 0.2, 250, 332)
    RelativeX, RelativeY = 5, Scrh - h - 5

    money = DarkRP.formatMoney(localplayer:GetNetVar("money")) or money
    rpname = localplayer:GetNetVar("rpname") or rpname
    salary = DarkRP.formatMoney(localplayer:GetNetVar("salary")) or salary

	--Background
	draw_RoundedBox( 6, RelativeX, RelativeY, w, h, darkNavy)
	draw_RoundedBox( 6, RelativeX, RelativeY, w, name_th_cache - 2.5, lightNavy)
	draw_RoundedBox( 0, RelativeX, RelativeY + name_th_cache / 2, w, name_th_cache / 2, lightNavy) // name bg
	draw_RoundedBox( 6, RelativeX + 5, RelativeY, 64 + 10, 64 + 10, lightNavy) // avatar bocx
	local bars_y = RelativeY + 64 + 10 + 15
	if Scrh <= 600 then
		bars_y = RelativeY + 64 + 5
	end
	draw_RoundedBox( 6, RelativeX, bars_y, w, Scrh - bars_y - 5, lightNavy)
	-- Info
    local x, y = RelativeX + 10 + 64 + 10, RelativeY + 1
	local tw, th = draw_SimpleText( rpname, "cg.font.20", x, y, hud_white, TEXT_ALIGN_BOTTOM, TEXT_ALIGN_LEFT )
	name_th_cache = th + 2.5
	y = y + th + 2.5
	tw, th = draw_SimpleText( LocalPlayer():GetJobName(), "cg.font.20", x, y, hud_white, TEXT_ALIGN_BOTTOM, TEXT_ALIGN_LEFT )
	y = y + th - 1
	tw, th = draw_SimpleText( money, "cg.font.24", x, y, hud_white, TEXT_ALIGN_BOTTOM, TEXT_ALIGN_LEFT )
	y = y + th - 1
	if Scrh > 600 then
		draw_SimpleText( "Salary: " .. salary, "cg.font.18", x, y, hud_white, TEXT_ALIGN_BOTTOM, TEXT_ALIGN_LEFT )
	end

    local health = math_Round(LocalPlayer():Health())
    local armor = math_Round(LocalPlayer():Armor())
	local hbar_y = bars_y + 2.5
	local abar_y = hbar_y + bar_h + 5
    -- out line
    draw_RoundedBox(6, RelativeX + 5, hbar_y, w - 10, bar_h, darkNavy)
    draw_RoundedBox(6, RelativeX + 5, abar_y, w - 10, bar_h, darkNavy)
    -- bars
    draw_RoundedBox(6, RelativeX + 5, hbar_y, math_Clamp((health * (w / 100) - 10), 0, w - 10), bar_h, red)
    draw_RoundedBox(6, RelativeX + 5, abar_y, math_Clamp((armor * (w / 100) - 10), 0, w - 10), bar_h, lightBlue)
    -- text
	draw_SimpleText(health, "cg.font.12", (RelativeX + w) / 2, hbar_y + 6, hud_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	draw_SimpleText(armor, "cg.font.12", (RelativeX + w) / 2, abar_y + 6, hud_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

	DrawAvatar()
	if localplayer:getDarkRPVar("HasGunlicense") then
		surface_SetMaterial(Page)
		surface_SetDrawColor(255, 255, 255, 255)
		surface_DrawTexturedRect(RelativeX + w - (32 + 5), RelativeY + 30, 32, 32)
	end

    Agenda()
    DrawVoiceChat()
    LockDown()

    Arrested()
    AdminTell()
end

local function DrawCenteredText(text, font, x, y, colour, xalign)
	surface_SetFont(font)
	local w, h = surface_GetTextSize(text)

	x = x - w * 0.5
	y = y + (h * (xalign - 1))
	
	surface_SetTextPos(x, y)
	surface_SetTextColor(colour)
	surface_DrawText(text)
	
	return w, h
end

local function DrawCenteredTextOutlined(text, font, x, y, colour, xalign, outlinewidth, outlinecolour)
	local steps = (outlinewidth * .75)
	if (steps < 1)  then steps = 1 end
	
	for _x=-outlinewidth, outlinewidth, steps do
		for _y=-outlinewidth, outlinewidth, steps do
			DrawCenteredText(text, font, x + (_x), y + (_y), outlinecolour, xalign)
		end
	end
	
	return DrawCenteredText(text, font, x, y, colour, xalign)
end

surface.CreateFont( "lol", {
	font = "CloseCaption_Normal",
	size = 22,
	weight = 1000
})

local function IsOnDuty(ply)
    return ply:Team() == TEAM_MOD || ply:Team() == TEAM_ADMIN
end

local div = 0
local ply_focus = nil
local pos_focus
local warn_cooldown
local gang_invite_cooldown
local options = {
    ["money"] = {text = "Give Money", sort = 1, func = function(ply) 
        local entry = vgui.Create("dank_ui.entry")
        entry:SetQuestion("How much?")
        entry:SetNumeric(true)
        entry.OnYes = function(s, amount)
            LocalPlayer():ConCommand("say /sendmoney "..ply:SteamID().." " .. amount) 
        end
    end},
    ["warn"] = {text = "Warn Player", sort = 2, func = function(ply) 
	    if warn_cooldown and warn_cooldown > CurTime() then 
	        Cloud.Message.Show(DarkRP.AlertMessageID, "You must wait before doing this again.")
            return 
        end
        warn_cooldown = CurTime() + 5
	    Cloud.Message.Show(DarkRP.AlertMessageID, "You warned " .. ply:Nick() .. "!")
         net.Start("Action")
            net.WritePlayer(ply)
            net.WriteUInt(1, 3)
        net.SendToServer()   
    end},
    ["mute"] = {text = "Toggle Mute", sort = 3, func = function(ply) LocalPlayer():ChatPrint((ply:IsMuted() && "Unmuted " || "Muted ") .. ply:Nick()) ply:SetMuted(!ply:IsMuted()) end},
    ["gang_invite"] = {text = "Invite To Gang", sort = 4, func = function(ply) 
        if !Gangs.Permissions.HasPermission("i") then
	        Gangs.Notify("You cannot invite members to your gang.")
            return
        end
	    if gang_invite_cooldown and gang_invite_cooldown > CurTime() then 
	        Gangs.Notify("You must wait before sending gang invites again.")
            return 
        end
        gang_invite_cooldown = CurTime() + 5
        net.Start("Gangs.Invite")
            net.WritePlayer(ply)
        net.SendToServer()
        Gangs.Notify("You invited " .. ply:Nick() .. " to your gang.")
    end},
    ["props"] = {text = "Un/Share Props", sort = 5, func = function(ply) RunConsoleCommand("r_share_props", ply:SteamID()) end},
    ["steamid"] = {text = "Copy SteamID", sort = 6, func = function(ply) LocalPlayer():ChatPrint("Copied") SetClipboardText(ply:SteamID()) end},
    ["want"] = {text = "Want Player", sort = 7, func = function(ply) LocalPlayer():ConCommand("say /want " .. ply:SteamID() .. " illegal activity") end, check = function(lp, targ) return lp:isCP() end},
    ["warrant"] = {text = "Warrant Player", sort = 8, func = function(ply) LocalPlayer():ConCommand("say /warrant " .. ply:SteamID() .. " illegal activity") end, check = function(lp, targ) return lp:isCP() end},
    ["hit"] = {text = "Place A Hit", sort = 9, func = function(ply) DarkRP.openHitMenu(ply) end, check = function(lp, targ) return targ:isHitman() && !lp:isCP() end},
    ["kidnap"] = {
        text = "Kidnap Player", 
        sort = 10,
        func = function(ply) 
            if warn_cooldown and warn_cooldown > CurTime() then 
                Cloud.Message.Show(DarkRP.AlertMessageID, "Please wait before doing this again.")
                return 
            end
            warn_cooldown = CurTime() + 5
            net.Start("Action")
                net.WritePlayer(ply)
                net.WriteUInt(2, 3)
            net.SendToServer()   
        end,
        check = function(lp, targ, can_mug, can_kidnap)
            return can_kidnap[lp:Team()] && !IsOnDuty(targ)
        end
    },
    ["mug"] = {
        text = "Mug Player", 
        sort = 11,
        func = function(ply) 
            if warn_cooldown and warn_cooldown > CurTime() then 
                Cloud.Message.Show(DarkRP.AlertMessageID, "Please wait before doing this again.")
                return 
            end
            warn_cooldown = CurTime() + 5
            net.Start("Action")
                net.WritePlayer(ply)
                net.WriteUInt(3, 3)
            net.SendToServer()   
        end,
        check = function(lp, targ, can_mug, can_kidnap)
            return can_mug[lp:Team()] && !IsOnDuty(targ)
        end
    } 
}

local max_dist = 60000
local option_dist = 25000
local option_y_increment = 40
local option_highlighted
local toggled = false
local next_key_press

local function DrawPlayerInfo(ply, pos, dist, block_modify_alpha)	
	div = 0	
	pos = pos + Vector(0, 0, 18)
	pos = pos:ToScreen()
	pos.y = pos.y - 10

	local gang = ply:getGang()
	if !Gangs_GetColor then
		Gangs_GetColor = Gangs.GetColor
		return
	end
	local gang_col = gang != "" && table_Copy(Gangs_GetColor(gang))
    local teamname = ply:GetJobName()
    local nick, team_color = ply:Nick(), table_Copy(ply:GetJobColor())
	local license = ply:getDarkRPVar("HasGunlicense") and " (LICENSED)" or ""

    local alpha 
	if block_modify_alpha || ply_focus then
		alpha = 255
	else
		alpha = math_Clamp((max_dist - dist) / 100, 0, 255)
	end

	color_white.a = alpha
	color_black.a = alpha
	team_color.a = alpha
	red2.a = alpha
	if gang_col then
		gang_col.a = alpha
	end

    if ply:getDarkRPVar("wanted") then
        DrawCenteredTextOutlined("Wanted by the police!", "lol", pos.x, pos.y, color_white, div, 1, red2)
        div = div + 1
    end
    DrawCenteredTextOutlined(nick, "lol", pos.x, pos.y, color_white, div, 1, color_black)
    div = div + 1
    if gang != "" then
        DrawCenteredTextOutlined(gang, "lol", pos.x, pos.y, gang_col, div, 1, color_black)
        div = div + 1
    end
    DrawCenteredTextOutlined(teamname .. license, "lol", pos.x, pos.y, team_color, div, 1, color_black)
	if ply:IsHandcuffed() then return end
	if ply_focus || dist < option_dist then
		local poz = EyePos(ply) - EyePos(localplayer) 
		local unitPos = poz:GetNormalized()
		if !ply_focus && unitPos:Dot(localplayer:GetAimVector()) < 0.95 then
			return	
		end
		if !ply_focus then
			local body_pos_world = ply:GetPos() + Vector(0, 0, 55)
			local body_pos = body_pos_world:ToScreen()
			pos_focus = body_pos
		end
        draw_RoundedBox(8, pos_focus.x - 15, pos_focus.y, 30, 30, grey_bg)
        surface_SetFont("lol")
        local tw, th = surface_GetTextSize("E")
        DrawCenteredTextOutlined("E", "lol", pos_focus.x + 1, pos_focus.y + 3.5, color_white, 1, 1, color_black)
		if ply:GetNetVar("surrendered") then
        	DrawCenteredTextOutlined("(Surrendered)", "lol", pos_focus.x + 1, pos_focus.y + 35, red, 1, 1, color_black)
		end
        if (LocalPlayer():KeyDown(IN_USE) && (!ply_focus || ply_focus == ply)) && LocalPlayer():Alive() && !LocalPlayer():KeyDown(IN_ATTACK) then
            if !toggled then
                gui_EnableScreenClicker(true)
                toggled = true
				ply_focus = ply
            end

			local can_kidnap, can_mug = {}, {}
			for k, v in pairs(RPExtraTeams) do
				if v.permissions then
					if v.permissions["Can mug"] then
						can_mug[k] = true
					end
					if v.permissions["Can kidnap"] then
						can_kidnap[k] = true
					end
				end
			end

            local interact_options = {}
            local tbl_count = 0
            for k, v in pairs(options) do
                if v.check && !v.check(LocalPlayer(), ply, can_mug, can_kidnap) then
                    continue
                end
                interact_options[k] = v
                tbl_count = tbl_count + 1
            end

            local total_h = (tbl_count * option_y_increment) - option_y_increment
            local top_y = pos_focus.y - (total_h / 2)
            local top_x = pos_focus.x + 10
            local middle = math_Round(tbl_count / 2)
            local is_even = tbl_count % 2 == 0
            local count = 1
            for k, v in SortedPairsByMemberValue(interact_options, "sort") do
                if (is_even && (count <= middle + 1)) || count <= middle then
                    if !(is_even && count == middle + 1) then
                        top_x = top_x + 15
                    end
                else
                    top_x = top_x - 15
                end
                count = count + 1

                local highlighted = false
                local center_x, center_y = Scrw / 2, Scrh / 2
                center_x, center_y = gui_MousePos()
                if (center_x > top_x - 50) && (center_y > top_y && center_y < top_y + option_y_increment) then
                    highlighted = true
                    option_highlighted = k
                end
                draw_SimpleTextOutlined(v.text, "lol", top_x, top_y, highlighted && team_color || color_white, nil, nil, 1, color_black) 
                top_y = top_y + option_y_increment
            end
        end
        if input_IsMouseDown(MOUSE_FIRST) && option_highlighted && ply_focus then
            if (!next_key_press || next_key_press && next_key_press < CurTime()) then
                next_key_press = CurTime() + 1
                options[option_highlighted].func(ply_focus)
            end
        end
	end
end
DarkRP.DrawPlayerInfo = DrawPlayerInfo

local trace = {
	mask 	= -1,
	filter 	= {},
}

local function InTrace(ply)
	trace.start 	= EyePos(localplayer)
	trace.endpos 	= EyePos(ply)
	trace.filter[1] = localplayer
	trace.filter[2] = ply

	return !util_TraceLine(trace).Hit
end

local plys = {}
hook.Add("PostPlayerDraw", "DarkRP.HUD", function(ply)
	if !plys[ply] then
		plys[ply] = true
	end
end)

local function DrawEntityDisplay()
    option_highlighted = nil
	if shouldDraw == false then return end

	for ply, dist in pairs(localplayer.PlayersInView) do
		if ply == LocalPlayer() then continue end
		if !IsValid(ply) then continue end 
        if ply_focus && ply_focus == ply then
			if dist < 150000 then
				DrawPlayerInfo(ply_focus, ply_focus:EyePos(), dist)
			else
				gui_EnableScreenClicker(false)
				ply_focus = nil
				pos_focus = nil
				toggled = false
			end
		end

		if dist > max_dist then continue end
		local eye_pos, eye_pos2 = EyePos(ply), EyePos(localplayer)
		local real_dist = DistToSqr(eye_pos, eye_pos2)
		DrawPlayerInfo(ply, eye_pos, real_dist)
	end
    if !LocalPlayer():KeyDown(IN_USE) && toggled then
        gui_EnableScreenClicker(false)
		ply_focus = nil
		pos_focus = nil
        toggled = false
    end
end

local function Notify(txt, type)
    GAMEMODE:AddNotify(txt, type, 8)
    surface.PlaySound("buttons/lightswitch2.wav")
    MsgC(red, "[Alert] ", textCol, txt, "\n")
end
DarkRP.Notify = Notify

net.Receive("_Notify", function()
    Notify(net.ReadString(), net.ReadUInt(3))
end)

local has_moved = false
hook.Add("KeyPress", "HUD.HasMoved", function()
	has_moved = true
	hook.Remove("KeyPress", "HUD.HasMoved")
end)

hook.Add("Cloud.PlayerDataLoaded", "NotifyNewJobHook", function()
	hook.Add("nw.PlayerNewJob", "NotifyNewJob", function(ply, newJob, oldJob)
		if !newJob || !ply || !isentity(ply) || !IsValid(ply) then return end
		if ply == LocalPlayer() then
			hook.Call("teamChanged", GAMEMODE, oldJob, newJob) -- backwards compatibility
			hook.Call("OnPlayerChangedTeam", GAMEMODE, LocalPlayer(), oldJob, newJob)
		end
		local name
		if (isnumber(newJob)) then
			name = RPExtraTeams[newJob] && RPExtraTeams[newJob].name || team.GetName(newJob)
		elseif (isstring(newJob)) then
			name = newJob
		end
		if ply:GetNetVar("jobName") && ply:GetNetVar("jobName") != newJob then
			nw.NilVar(ply:EntIndex(), nw.Vars["jobName"].ID)
		end
		if has_moved then
			Notify(ply:Nick() .. " has become " .. name .. "!", 0)
		end
	end)
end)

function GM:HUDShouldDraw(name)
    if name == "CHudHealth" or
        name == "CHudBattery" or
		name == "CHudDamageIndicator" && !LocalPlayer():Alive() or
        name == "CHudSuitPower" or
        (HelpToggled and name == "CHudChat") then
            return false
    else
        return self.Sandbox.HUDShouldDraw(self, name)
    end
end

function GM:HUDDrawTargetID()
    return false
end

local function AddTimer()
	timer.Create("PlayersVisible", 0.25, 0, function()
		table_Empty(localplayer.PlayersInView)
		for ply, _ in pairs(plys) do 
			if IsValid(ply) && !ply:IsCloaked() && !Camo.IsEnabled(ply) && ply:Alive() then
				local dist = DistToSqr(EyePos(ply), EyePos(localplayer))
				if dist < 350000 && IsLineOfSightClear(localplayer, ply) && InTrace(ply) then
					localplayer.PlayersInView[ply] = dist
				end
			end
		end
		table_Empty(plys)
	end)
end

local last_death
local black = Color(20, 20,20, 240)
local black2 = Color(20, 20, 20, 200)
local white = Color(240, 240, 240, 250)
local white_trans = Color(235, 235, 235, 100)
local default_card_url = "http://cloud-gaming.co.uk/darkrp/calling_cards/default.png"
local health_cache
local attacker_cache
local function DrawDeathScreen()
	if !KillFeed.LastDeathInfo then return end	
	local inflictor, attacker = unpack(KillFeed.LastDeathInfo)
	if !IsValid(attacker) || !attacker.Nick then return end
	if !health_cache || attacker != attacker_cache then
		health_cache = attacker:Health()
		attacker_cache = attacker
	end
	local card_url = attacker:GetNetVar("card") && CallingCards.ByInt[attacker:GetNetVar("card")] || default_card_url
	local card_w, card_h = 512, 128
	local font = "GModToolName"
	local spacing, spacing2 = 35, 5
	local num = 2
	if Scrh < 900 && Scrh > 600 then
		card_w, card_h = 512 * 0.75, 128 *0.75
		spacing = 17.5
		spacing2 = 2.5
	elseif Scrh <= 600 then
		card_w, card_h = 256, 64
		font = "cg.font.24"
		spacing = 15
		num = 1
	end
	local text_y = Scrh - card_h - 35
	draw_SimpleTextOutlined("You were killed", "cg.font.20", Scrw / 2, text_y, white, TEXT_ALIGN_CENTER, nil, 1, black)
	local x, y =  Scrw / 2 - card_w / 2, Scrh - card_h - 10
	draw_RoundedBox(6, x - 4, y - 4, card_w + 8, card_h + 8, black)
	draw.WebImage(card_url, x, y, card_w, card_h, white_trans)
	surface.SetFont(font)
	local tw, th = surface.GetTextSize(attacker:Nick())
	text_y = spacing + text_y + th / num
	tw, th = draw_SimpleTextOutlined(attacker:Nick(), font, x + card_w / 2, text_y, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
	draw_SimpleTextOutlined(inflictor, "cg.font.24", x + card_w / 2, text_y + th / num - 2.5, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, black)
    draw_RoundedBox(6, x + 10, y + card_h - bar_h - spacing2, card_w - 20, bar_h, darkNavy)
    draw_RoundedBox(6, x + 10, y + card_h - bar_h - spacing2, math_Clamp((health_cache * (card_w / 100) - 10), 0, card_w - 20), bar_h, red)
	draw_SimpleText(health_cache, "cg.font.12", (x + 10) + (card_w - 20) / 2, (y + card_h - bar_h - spacing2) + bar_h /2, hud_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local tab = {
	["$pp_colour_addr"] = 0,
	["$pp_colour_addg"] = 0,
	["$pp_colour_addb"] = 0,
	["$pp_colour_brightness"] = 0,
	["$pp_colour_contrast"] = 1,
	["$pp_colour_colour"] = 1,
	["$pp_colour_mulr"] = 0,
	["$pp_colour_mulg"] = 0,
	["$pp_colour_mulb"] = 0
}
local start_time
local fade_time = 1.5
hook.Add("RenderScreenspaceEffects", "DarkRP.DeathScreen", function()
	if !LocalPlayer():Alive() then
		if !start_time then
			start_time = CurTime()
		end
		if (CurTime() - start_time) < fade_time then
			local brightness = (.1/fade_time) * FrameTime()
			local colour = (.9/fade_time) * FrameTime()
			tab["$pp_colour_brightness"] = tab["$pp_colour_brightness"] - brightness
			tab["$pp_colour_colour"] = tab["$pp_colour_colour"] - colour
		end
		DrawColorModify( tab )
	end
end )

function GM:HUDPaint()
	if !localplayer || !IsValid(localplayer) then
		localplayer = LocalPlayer()
		if !localplayer.PlayersInView then
			localplayer.PlayersInView = {}
		end
		AddTimer()
	end
    if !IsValid(localplayer) then return end
    Scrw, Scrh = ScrW(), ScrH()
	if localplayer:Alive() then
		DrawHUD()
		if start_time then
			KillFeed.LastDeathInfo = nil
			start_time = nil
			tab["$pp_colour_brightness"] = 0
			tab["$pp_colour_colour"] = 1
		end
	else
		if DarkRP.Avatar then	
			DarkRP.Avatar:Remove()
			DarkRP.Avatar = nil
		end
		DrawDeathScreen()
	end
	DrawEntityDisplay()

    self.Sandbox.HUDPaint(self)
end
