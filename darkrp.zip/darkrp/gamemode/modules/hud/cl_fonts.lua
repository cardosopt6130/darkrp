--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/hud/cl_fonts.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

-----------------------------------------------------------------------------[[
/*---------------------------------------------------------------------------
The fonts that DarkRP uses
---------------------------------------------------------------------------*/
-----------------------------------------------------------------------------]]
local function loadFonts()
    local tahoma = system.IsLinux() and "DejaVu Sans" or "Tahoma"
    local tahomaSize = system.IsLinux() and fp{fn.Flip(fn.Add), 1} or fn.Id

    surface.CreateFont("DarkRPHUD1", {
        size = tahomaSize(16),
        weight = 600,
        antialias = true,
        shadow = true,
        font = tahoma})

    surface.CreateFont("Trebuchet24", {
        size = 24,
        weight = 500,
        antialias = true,
        shadow = false,
        font = "Trebuchet MS"})

    surface.CreateFont("TabLarge", {
        size = tahomaSize(15),
        weight = 700,
        antialias = true,
        shadow = false,
        font = tahoma})

    surface.CreateFont("UiBold", {
        size = 16,
        weight = 800,
        antialias = true,
        shadow = false,
        font = "Default"})

    surface.CreateFont("HUDNumber5", {
        size = 30,
        weight = 800,
        antialias = true,
        shadow = false,
        font = "Default"})

    surface.CreateFont("ScoreboardHeader", {
        size = 32,
        weight = 500,
        antialias = true,
        shadow = false,
        font = "Coolvetica"})

    surface.CreateFont("ScoreboardSubtitle", {
        size = 22,
        weight = 500,
        antialias = true,
        shadow = false,
        font = "Coolvetica"})
end
loadFonts()
-- Load twice because apparently once is not enough
hook.Add("InitPostEntity", "DarkRP_LoadFonts", loadFonts)
