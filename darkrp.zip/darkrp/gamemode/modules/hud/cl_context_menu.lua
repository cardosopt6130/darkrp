--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/hud/cl_context_menu.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

if IsValid(DarkRP.ContextMenu) then
	DarkRP.ContextMenu:Remove()
end

local convar = GetConVar("cg_thirdperson")

local options = {
	["Share Props"] = function() RunConsoleCommand("share_props") end,
	["Third Person"] = function() RunConsoleCommand("cg_thirdperson", convar:GetBool() && 0 || 1) end,
	["Suicide"] = function() RunConsoleCommand("kill") end,
	["Surrender"] = function() RunConsoleCommand("surrender") end,
}
local options_count = table.Count(options)

hook.Add("OnContextMenuOpen", "DarkRP.Menu", function()
	if !IsValid(menu) then
		menu = vgui.Create("DPanel", g_ContextMenu)
		menu:SetSize(ScrW() * 0.1, ScrH() * 0.1)
		menu:SetPos(0, ScrH() / 2 - menu:GetTall() / 2)
		menu:SetSkin("material_dark")
		menu:SetMouseInputEnabled(true)

		local count = 0
		for k, v in pairs(options) do
			local btn = vgui.Create("DButton", menu)
			btn:SetSize(menu:GetWide(), menu:GetTall() / options_count)
			btn:SetPos(0, count * btn:GetTall())
			btn:SetText(k)
			btn.DoClick = v
			count = count + 1
		end
		DarkRP.ContextMenu = menu
	end
end)