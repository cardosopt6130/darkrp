--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/hud/cl_hud_hints.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Hints = Hints || {Registered={}}

function Hints.Register(class, message, func, bind, check)
	Hints.Registered[class] = {message=message, func=func, bind=bind, check=check} 
end

function Hints.AddEnt(ent)
	if !LocalPlayer().EntsInView then
		LocalPlayer().EntsInView = {}
	end
	if !LocalPlayer().EntsInView[ent] then
		LocalPlayer().EntsInView[ent] = true
	end
end

local EyePos = ENTITY.EyePos
local util_TraceLine = util.TraceLine

local trace = {
	mask 	= -1,
	filter 	= {},
}

local function InTrace(ply)
	trace.start 	= EyePos(LocalPlayer())
	trace.filter[1] = LocalPlayer()
	trace.endpos 	= trace.start + (LocalPlayer():GetAimVector() * 80)

	return util_TraceLine(trace).Entity == ply
end

hook.Add("HUDPaint", "HUD.EntsInView", function()
	if LocalPlayer().EntsInView then
		for k, v in pairs(LocalPlayer().EntsInView) do
			if InTrace(k) then
				local hint = Hints.Registered[k:GetClass():lower()]
				if !hint then return end
				if hint.check && !hint.check(k) then continue end
				if hint.func then
					local displayed = hint.func(k)
					if displayed then break end
				else
					if hint.bind then
						local key = input.LookupBinding(hint.bind) || hint.bind
						draw.SimpleTextOutlined("["..key:upper().."] " .. hint.message, "Trebuchet24", ScrW() / 2, ScrH() / 1.9, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
					else
						draw.SimpleTextOutlined(hint.message, "Trebuchet24", ScrW() / 2, ScrH() / 1.9, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
					end
				end
			end
		end
		table.Empty(LocalPlayer().EntsInView)
	end
end)