--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/hud/cl_notification.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local NoticeColor = {}
NoticeColor[NOTIFY_GENERIC]		= Color(138, 43, 226)
NoticeColor[NOTIFY_ERROR]		= Color(200, 60, 60)
NoticeColor[NOTIFY_UNDO]		= Color(70, 120, 230)
NoticeColor[NOTIFY_HINT]		= Color(85, 190, 74)
NoticeColor[NOTIFY_CLEANUP]		= Color(70, 120, 220)

local PANEL = {}

function PANEL:Init()
	self:DockPadding(6, 5, 6, 2)
	self.Label = vgui.Create("DLabel", self)
	self.Label:Dock(LEFT)
	self.Label:SetFont("cg.font.20")
	self.Label:SetTextColor(Color(255, 255, 255))
	self.Col = Color(66, 139, 202)
end

function PANEL:SetText(txt)
	self.Label:SetText(txt)
	self:SizeToContents()
end

function PANEL:SizeToContents()
	self.Label:SizeToContents()
	local width = self.Label:GetWide()
	width = width + 14
	self:SetWidth(math.max(width, 160))
	self:SetHeight(32)
	self:InvalidateLayout()
end

function PANEL:SetLegacyType(t)
	self.Type = t
	self.Col = NoticeColor[self.Type]
	self:SizeToContents()
end

function PANEL:SetProgress()
	self.Paint = function(s, w, h)
		self.BaseClass.Paint(self, w, h)
	end
end

function PANEL:Paint(w, h)
	local time = self.StartTime + self.Length
	local timeleft = math.Round(time - SysTime(), 4)
	draw.RoundedBox(0, 0, 0, w, h, Color(self.Col.r, self.Col.g, self.Col.b, 200))
	draw.RoundedBox(0, 0, 0, w*(timeleft/self.Length), h * 0.15, Color(self.Col.r - 50, self.Col.g - 50, self.Col.b - 50, 255))
	surface.SetDrawColor(Color(0, 0, 0, 170))
	surface.DrawOutlinedRect(0, 0, w, h)
end

function PANEL:KillSelf()
	if (self.StartTime + self.Length < SysTime()) then
		self:Remove()
		return true
	end
	return false
end
vgui.Register("NoticePanel", PANEL, "DPanel")