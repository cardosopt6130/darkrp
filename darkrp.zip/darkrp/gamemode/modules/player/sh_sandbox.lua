--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/player/sh_sandbox.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local PLAYER = FindMetaTable("Player")

function PLAYER:GetCount(str, minus)
	if (self._Counts and self._Counts[str]) then
		return self._Counts[str] - (minus or 0)
	end
	return 0
end

function PLAYER:AddCount(str, ent)
	if (SERVER) then
		if not self._Counts then
			self._Counts = {}
		end

		self._Counts[str] = (self._Counts[str] or 0) + 1
		
		ent.OnRemoveCount = function() --CallOnRemove is broke
			if IsValid(self) then 
				self._Counts[str] = self._Counts[str] - 1 
			end 
		end
	end
end

function PLAYER:LimitHit(str)
    self:SendLua( 'hook.Run("LimitHit","' .. str .. '")' )
end

function PLAYER:AddCleanup(type, ent)
	cleanup.Add(self, type, ent)
end

function PLAYER:GetTool( mode )
	local wep = self:GetWeapon( 'gmod_tool' )
	if (!wep || !wep:IsValid()) then return nil end
	
	local tool = wep:GetToolObject( mode )
	if (!tool) then return nil end
	
	return tool
end

hook.Add('EntityRemoved', "DarkRP.RemoveEntCount", function(ent)
	if ent.OnRemoveCount then ent.OnRemoveCount() end
end)