--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/player/sh_entityvars.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

nw.Register "money"
	:Write(net.WriteDouble)
	:Read(net.ReadDouble)
	:SetHook("nw.Money")
	:SetLocalPlayer()
nw.Register "salary"
	:Write(net.WriteUInt, 32)
	:Read(net.ReadUInt, 32)
	:SetLocalPlayer()
nw.Register "rpname"
	:Write(net.WriteString)
	:Read(net.ReadString)
	:SetPlayer()
nw.Register "job"
	:Write(net.WriteUInt, 10)
	:Read(net.ReadUInt, 10)
	:SetHook("nw.PlayerNewJob")
	:SetPlayer()
nw.Register "jobName"
	:Write(net.WriteString)
	:Read(net.ReadString)
	:SetHook("nw.PlayerNewJob")
	:SetPlayer()
nw.Register "HasGunlicense"
	:Write(net.WriteBool)
	:Read(net.ReadBool)
	:SetPlayer()
nw.Register "wanted"
	:Write(net.WriteBool)
	:Read(net.ReadBool)
	:SetHook("nw.PlayerWanted")
	:SetPlayer()
nw.Register "agenda"
	:Write(net.WriteString)
	:Read(net.ReadString)
	:SetLocalPlayer()

/*---------------------------------------------------------------------------
RP name override
---------------------------------------------------------------------------*/
local pmeta = FindMetaTable("Player")
pmeta.SteamName = pmeta.SteamName or pmeta.Name
function pmeta:Name()
    if not self:IsValid() then DarkRP.error("Attempt to call Name/Nick/GetName on a non-existing player!", SERVER and 1 or 2) end
    return GAMEMODE.Config.allowrpnames and self:getDarkRPVar("rpname")
        or self:SteamName()
end
pmeta.GetName = pmeta.Name
pmeta.Nick = pmeta.Name

local team_GetName = team.GetName
function pmeta:GetJobName()
    local jobName = self:GetNetVar("jobName")
	if jobName then
		return jobName
	end
	local job = RPExtraTeams[self:GetNetVar("job")] || RPExtraTeams[self:Team()]
	return (job && job.name) || team_GetName(self:Team())
end

local is_color, team_getcolor = IsColor, team.GetColor
function pmeta:GetJobColor()
	return team_getcolor(self:GetNetVar("job")) || team_getcolor(self:Team())
end