--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/player/sh_playerclass.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

player_manager.RegisterClass('player_darkrp', {
	DisplayName = 'DarkRP Player Class',
	
	GetHandsModel = function(self)
		local name = player_manager.TranslateToPlayerModelName(self.Player:GetModel())
		return player_manager.TranslatePlayerHands(name)
	end,
	
	Spawn = function(self)
		local col = self.Player:GetInfo('cl_playercolor')
		self.Player:SetPlayerColor(Vector(col))

		local col = self.Player:GetInfo('cl_weaponcolor')
		self.Player:SetWeaponColor(Vector(col))
	end,
	
	SetModel = function(self) 
		local cl_playermodel = self.Player:GetInfo('cl_playermodel')
		local modelname = player_manager.TranslatePlayerModel(cl_playermodel)
		self.Player:SetModel(Model(modelname))
	
		local skin = self.Player:GetInfoNum('cl_playerskin', 0)
		self.Player:SetSkin(skin)

		local groups = self.Player:GetInfo('cl_playerbodygroups')
		if (groups == nil) then groups = '' end
		local groups = string.Explode(' ', groups)
		for k = 0, self.Player:GetNumBodyGroups() - 1 do
			self.Player:SetBodygroup(k, tonumber(groups[k + 1]) or 0)
		end
	end,

	TauntCam = TauntCamera(),

	CalcView = function(self, view)
		if (self.TauntCam:CalcView(view, self.Player, self.Player:IsPlayingTaunt())) then 
			return true 
		end
	end,
	
	CreateMove = function(self, cmd)
		if (self.TauntCam:CreateMove(cmd, self.Player, self.Player:IsPlayingTaunt())) then 
			return true 
		end
	end,
	
	ShouldDrawLocal = function(self)
		if (self.TauntCam:ShouldDrawLocalPlayer(self.Player, self.Player:IsPlayingTaunt())) then 
			return true 
		end
	end,
	
	JumpPower = 300,
	DuckSpeed = 0.5,
	WalkSpeed = 200,
	RunSpeed = 350
}, 'player_default')
