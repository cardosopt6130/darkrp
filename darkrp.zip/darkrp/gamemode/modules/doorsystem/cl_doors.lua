--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/doors/cl_doors.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local IsValid 		= IsValid
local ipairs 		= ipairs
local LocalPlayer 	= LocalPlayer
local Angle 		= Angle
local Vector 		= Vector

local ents_FindInSphere 		= ents.FindInSphere
local util_TraceLine 			= util.TraceLine
local draw_SimpleTextOutlined 	= draw.SimpleTextOutlined
local team_GetColor 			= team.GetColor
local team_GetName 				= team.GetName
local cam_Start3D2D 			= cam.Start3D2D
local cam_End3D2D 				= cam.End3D2D

local color_white 	= Color(245,245,245)
local color_black 	= Color(0,0,0)
local color_green 	= Color(50, 220, 50)

local off_vec 		= Vector(0,0,17.5)
local off_ang 		= Angle(0,90,90)

local count
local DoorText 		= {}
local DoorCache 	= {}

local function AddText(tbl)
	DoorText[count + 1] = tbl
	count = count + 1
end

timer.Create("DoorCache", 1, 0, function()
	if IsValid(LocalPlayer()) then 
		local count = 0
		DoorCache 	= {}
		for k, ent in ipairs(ents_FindInSphere(LocalPlayer():GetPos(), 250)) do
			if ent:IsDoor() then
				count = count + 1
				DoorCache[count] = ent
			end
		end
	end
end)

hook.Add('PostDrawTranslucentRenderables', "DarkRP.Doors", function()
	for _, ent in ipairs(DoorCache) do
		if IsValid(ent) then 
			count 		= 0
			DoorText 	= {}
			local dist 	= ent:GetPos():DistToSqr(LocalPlayer():GetPos())

			if ent:DoorIsOwnable() then
				AddText({color_white, "Press F2 to own"})
				AddText({color_green, "£100"})
			elseif not ent:DoorIsOwnable() then
				if (ent:DoorGetGroup() ~= nil) then
					local name = DarkRP.DoorGroupIDToName[ent:DoorGetGroup()]
					AddText({color_white, name})
				end
				if (ent:DoorGetTeam() ~= nil) then
					AddText({team_GetColor(ent:DoorGetTeam()), team_GetName(ent:DoorGetTeam())})
				end
				local owner = ent:DoorGetOwner()
				if ent:DoorGangOwned() and IsValid(owner) then
					AddText({Gangs.GetColor(owner:GetGang()), owner:GetGang()})
				end
				if IsValid(owner) then
					AddText({owner:GetJobColor(), owner:Name()})
				end
				if (ent:DoorGetCoOwners() ~= nil) then
					for k, co in ipairs(ent:DoorGetCoOwners()) do
						if IsValid(co) then
							AddText({co:GetJobColor(), co:Name()})
						end
						if (k >= 4) then
							AddText({color_white,  'and ' .. (#ent:DoorGetCoOwners() - 4) .. ' co-owners.'})
							break
						end
					end
				end
			end

			if table.Count(DoorText) < 1 && !ent:DoorIsBlocked() then
				AddText({color_white, "Press F2 to own"})
				AddText({color_green, "£100"})
			end

			local lw = ent:LocalToWorld(ent:OBBCenter()) + off_vec
			local tr = util_TraceLine({
				start = LocalPlayer():GetPos() + LocalPlayer():OBBCenter(),
				endpos = lw,
				filter = LocalPlayer()
			})
			
			if (tr.Entity == ent) and (lw:DistToSqr(tr.HitPos) < 65) then
				cam_Start3D2D(tr.HitPos + tr.HitNormal, tr.HitNormal:Angle() + off_ang, .04)
					local h = 0
					for k, v in ipairs(DoorText) do
						local a = (62500 - dist) / 250
						v[1].a 			= a
						color_black.a 	= a
						local _, th = draw_SimpleTextOutlined(v[2], 'GModToolName', 0, h, v[1], 1, 1, 3, color_black)
						h = h + th
					end
				cam_End3D2D()
			end
		end
	end
end)

net.Receive("DarkRP.UnownAllDoors", function()
	local ply = net.ReadPlayer()
	for k, v in ipairs(ents.GetAll()) do
		if IsValid(v) and v:IsDoor() then 
			if v:DoorOwnedBy(ply) then
				nw.NilVar(v:EntIndex(), nw.Vars["DoorData"].ID)
			elseif v:DoorCoOwnedBy(ply) then
				local data = v:GetNetVar('DoorData') or {}
				table.RemoveByValue(data.CoOwners or {}, self)
				nw.EditData(v:EntIndex(), "DoorData", data)
			end
		end
	end
end)