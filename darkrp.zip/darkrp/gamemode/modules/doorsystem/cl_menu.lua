--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/doors/cl_menu.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local AdminMenu
local fr
local ent
local doorOptions = {
	{
		Name 	= 'Sell',
		DoClick = function()
			RunConsoleCommand("say", "/selldoor")
			fr:Close()
		end,
	},
	{
		Name 	= 'Add Co-Owner',
		Check 	= function()
			return (player.GetCount() > 1)
		end,
		DoClick = function()
			local entry = vgui.Create("dank_ui.entry")
			entry:PlayerAutoComplete()
			entry:SetQuestion("Add a player to your door.")
			entry.OnClose = function()
				fr:SetVisible(true)
			end
			entry.OnYes = function(s, v)
				fr:SetVisible(true)
				if isstring(v) then
					DarkRP.Notify("Please select a player from the drop down list.", NOTIFY_ERROR)
					return
				end
				RunConsoleCommand("say", "/addowner " .. v:SteamID())
			end
			fr:SetVisible(false)
		end,
	},
	{
		Name 	= 'Remove Co-Owner',
		Check 	= function()
			return (ent:DoorGetCoOwners() ~= nil) and (#ent:DoorGetCoOwners() > 0)
		end,
		DoClick = function()
			local entry = vgui.Create("dank_ui.entry")
			entry:PlayerAutoComplete(ent:DoorGetCoOwners())
			entry:SetQuestion("Remove a player from your door.")
			entry.OnClose = function()
				fr:SetVisible(true)
			end
			entry.OnYes = function(s, v)
				if isstring(v) then
					DarkRP.Notify("Please select a player from the drop down list.", NOTIFY_ERROR)
					return
				end
				RunConsoleCommand("say", "/removeowner " .. v:SteamID())
				fr:SetVisible(true)
			end
			fr:SetVisible(false)
		end,
	},
	{
		Name 	= 'Toggle gang door',
		Check 	= function()
			return (player.GetCount() > 1) and (LocalPlayer():GetGang() ~= nil)
		end,
		DoClick = function()
			RunConsoleCommand("say", "/setgangdoor")
		end,
	},
	{
		Name 	= 'Admin options',
		Check 	= function()
			return LocalPlayer():IsSuperAdmin()
		end,
		DoClick = function(self)
			fr:Close()
			AdminMenu()
		end,
	},
}

local function DoorMenu()
	if IsValid(fr) then fr:Close() end
	ent = LocalPlayer():GetEyeTrace().Entity
	if IsValid(ent) and ent:IsDoor() and ent:DoorOwnedBy(LocalPlayer()) and (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 13225) then
		fr = vgui.Create("dank_ui.frame")
		fr:SetTitle("Door Options")
		fr:Center()
		fr.Think = function(self)
			ent = LocalPlayer():GetEyeTrace().Entity
			if not IsValid(ent) or (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) > 13225) then
				fr:Close()
			end
		end

		local count = -1
		local x, y = 0, 29
		for k, v in ipairs(doorOptions) do
			if (v.Check == nil) or (v.Check(ent) == true) then
				count = count + 1
				fr:SetSize(ScrW() * .125, ((count + 1) * 49) + (y + 1))
				fr:Center()
				local btn = vgui.Create("DButton", fr)
				btn:SetPos(x, (count * 49) + y)
				btn:SetSize(fr:GetWide(), 50)
				btn:SetText(v.Name)
				btn.DoClick = v.DoClick
			end
		end
	elseif IsValid(ent) and ent:IsDoor() and (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 13225) and ent:DoorIsOwnable() then
		RunConsoleCommand("say", "/buydoor")
	end

	if LocalPlayer():IsSuperAdmin() and IsValid(ent) and ent:IsDoor() and (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 13225) and !ent:DoorOwnedBy(LocalPlayer()) then
		AdminMenu()
	end
end
net.Receive("DarkRP.KeysMenu", DoorMenu)
GM.ShowTeam = DoorMenu

local adminOptions = {
	{
		Name 	= 'Toggle Ownable',
		DoClick = function()
			RunConsoleCommand("say", "/toggleownable")
		end,
	},
	{
		Name 	= 'Set Team Own',
		DoClick = function()
			local m = DermaMenu()
			for k, v in pairs(RPExtraTeams) do
				m:AddOption(v.name, function()
					RunConsoleCommand("say", "/setdoorteam " .. k)
				end)
			end
			m:Open()
		end,
	},
	{
		Name 	= 'Set Group Own',
		DoClick = function()
			local m = DermaMenu()
			for k, v in pairs(DarkRP.DoorGroups) do
				m:AddOption(DarkRP.DoorGroupIDToName[k], function()
					RunConsoleCommand("say", "/setdoorgroup " .. k)
				end)
			end
			m:Open()
		end,
	},
}

AdminMenu = function()
	if IsValid(fr) then fr:Close() end
	if !LocalPlayer():IsSuperAdmin() then return end
	ent = LocalPlayer():GetEyeTrace().Entity
	if IsValid(ent) and ent:IsDoor() and (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) < 13225) then
		fr = vgui.Create("dank_ui.frame")
		fr:SetTitle("Admin Door Options")
		fr:Center()
		fr.Think = function(self)
			ent = LocalPlayer():GetEyeTrace().Entity
			if not IsValid(ent) or (ent:GetPos():DistToSqr(LocalPlayer():GetPos()) > 13225) then
				fr:Close()
			end
		end

		local count = -1
		local x, y = 0, 29
		for k, v in ipairs(adminOptions) do
			if (v.Check == nil) or (v.Check(ent) == true) then
				count = count + 1
				fr:SetSize(ScrW() * .125, ((count + 1) * 49) + (y + 1))
				fr:Center()
				local btn = vgui.Create("DButton", fr)
				btn:SetPos(x, (count * 49) + y)
				btn:SetSize(fr:GetWide(), 50)
				btn:SetText(v.Name)
				btn.DoClick = v.DoClick
			end
		end
	end
end
concommand.Add("darkrp_dooradminmenu", AdminMenu)