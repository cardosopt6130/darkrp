--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/doors/sh_doors.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local istable = istable

local doorClasses = {
	['func_door'] = true,
	['func_door_rotating'] = true,
	['prop_door_rotating'] = true
	--['prop_dynamic'] = true,
}

function ENTITY:IsDoor()
	return doorClasses[self:GetClass()]
end
ENTITY.isDoor = ENTITY.IsDoor

function ENTITY:DoorIsOwnable()
	return (self:GetNetVar('DoorData') == nil) and (self:GetNetVar('DoorData') ~= false)
end

function ENTITY:DoorIsBlocked()
	return self:GetNetVar('DoorData') == false
end

function ENTITY:DoorOwnedBy(pl)
	return (istable(self:GetNetVar('DoorData')) and (self:GetNetVar('DoorData').Owner == pl) or false)
end

function ENTITY:DoorGangOwned()
	return (istable(self:GetNetVar('DoorData')) and self:GetNetVar('DoorData').GangOwn or false)
end

function ENTITY:DoorCoOwnedBy(pl)
	return (istable(self:GetNetVar('DoorData')) and table.HasValue(self:GetNetVar('DoorData').CoOwners or {}, pl) or false)
end

function ENTITY:DoorGetOwner()
	return (istable(self:GetNetVar('DoorData')) and (self:GetNetVar('DoorData').Owner) or nil)
end

function ENTITY:DoorGetCoOwners()
	return (istable(self:GetNetVar('DoorData')) and (self:GetNetVar('DoorData').CoOwners) or nil)
end

function ENTITY:DoorGetTeam()
	return (istable(self:GetNetVar('DoorData')) and (self:GetNetVar('DoorData').Team) or nil)
end

function ENTITY:DoorGetGroup()
	return (istable(self:GetNetVar('DoorData')) and (self:GetNetVar('DoorData').Group) or nil)
end

function net.ReadDoor()
	local data = {}
	if net.ReadBit() == 1 then
		if net.ReadBit() == 1 then
			data.Owner = net.ReadPlayer()
		end
		if net.ReadBit() == 1 then
			data.CoOwners = net.ReadPlayerTable()
		end
		if net.ReadBit() == 1 then
			data.Team = net.ReadUInt(7)
		end
		if net.ReadBit() == 1 then
			data.Group = net.ReadUInt(3)
		end
		if net.ReadBit() == 1 then
			data.GangOwn = true
		end
	else
		data = false
	end
	return data
end

function net.WriteDoor(door_data)
	if istable(door_data) then
		net.WriteBit(1)
		if IsValid(door_data.Owner) then
			net.WriteBit(1)
			net.WritePlayer(door_data.Owner)
		else
			net.WriteBit(0)
		end
		if door_data.CoOwners && istable(door_data.CoOwners) && #door_data.CoOwners > 0 then
			net.WriteBit(1)
			net.WritePlayerTable(door_data.CoOwners)
		else
			net.WriteBit(0)
		end
		if door_data.Team then
			net.WriteBit(1)
			net.WriteUInt(door_data.Team, 7)
		else
			net.WriteBit(0)
		end
		if door_data.Group then
			net.WriteBit(1)
			net.WriteUInt(door_data.Group, 3)
		else
			net.WriteBit(0)
		end
		if door_data.GangOwn then
			net.WriteBit(1)
		else
			net.WriteBit(0)
		end
	else
		net.WriteBit(0)
	end
end

nw.Register('DoorData'):Write(net.WriteDoor):Read(net.ReadDoor)