--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/turfs/sh_cfg.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Turfs = Turfs || {Registered={}}

Turfs.Spots = {
    ["residential"] = {
    	{
			circle =  Vector(-4288.466309, -6350.865723, -180),
			enclosed = {
				x1      =       -5129,
				x2      =       -3020,
				y1      =       -7470,
				y2      =       -4347.0141601563,
				z1      =       -235,
				z2      =       500
	   }
	}
    },
    ["farm"] = {
		{
			circle = Vector(5405.789063, 941.672913, -200)
		}
    },
    ["beach"] = {
		{
        	circle = Vector(4481.266113, -6204.304688, -305),
			enclosed = {
				x1      =       3800,
				x2      =       5352,
				y1      =       -7500,
				y2      =       -4580,
				z1      =       -350,
				z2      =       500,
			}
		}
    },
    ["industrial"] = {
    	{
			circle = Vector(-3645, 2825, -200)
		}
    },
	["meth buyer"] = {
		{circle = Vector(3426, 1708, -200)},
	},
	["hoboville"] = {
		{circle=Vector(3195.239258, 3396.408936, -190)}
	}
}

function Turfs.Register(id, get_team_func, get_color_func, on_start, on_end, required_teams, color)
	Turfs.Registered[id] = {get_team = get_team_func, get_color = get_color_func, on_start = on_start, on_end=on_end, required_teams=required_teams, color=color}
end