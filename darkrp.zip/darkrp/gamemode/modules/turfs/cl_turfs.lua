--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/turfs/cl_turfs.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local scores, contested
local id
local zone // area name 
local red = table.Copy(DankUI.Red)
local blue = Color(50, 50, 149)
local get_team, get_color
local nlr_enabled = true

function Turfs.HasActive() 
	return zone
end

local function FindLeadingGang(gang_scores)
    local highest = 0
    local top_gang
    for k, v in pairs(gang_scores) do
        if v >= highest then
            top_gang = k
            highest = v
        end
    end
    return top_gang, highest
end

local function FindGangThatsSecond(leader)
    local scores2 = table.Copy(scores)
    scores2[leader] = nil
    return FindLeadingGang(scores2)
end

local function AddHUDHook()
    hook.Add("HUDPaint", "Turf.Scores", function()
        if contested then
            draw.RoundedBox(0, ScrW() * 0.25, 0, ScrW() * 0.5, 25, red)
            draw.SimpleTextOutlined("CONTESTED", "dank_ui.small", ScrW() * 0.25 + ScrW() * 0.25, 2.5, color_white, TEXT_ALIGN_CENTER, nil, 1, color_black)           
        else 
            local gang, score = FindLeadingGang(scores)
			if !gang then return end
            draw.RoundedBox(0, ScrW() * 0.25, 0, ScrW() * 0.5, 25, get_color(gang))
            draw.SimpleTextOutlined(gang .. ": " .. score, "dank_ui.small", ScrW() * 0.25 + ScrW() * 0.25, 2.5, color_white, TEXT_ALIGN_CENTER, nil, 1, color_black)

            if table.Count(scores) < 2 then return end

			local t = get_team(LocalPlayer())
            if gang != t and scores[t] then
                local your_score = scores[t]
                draw.RoundedBox(0, ScrW() * 0.3, 25, ScrW() * 0.4, 25, get_color(t))
                draw.SimpleTextOutlined(t .. ": " .. your_score, "dank_ui.small", ScrW() * 0.25 + ScrW() * 0.25, 27.5, color_white, TEXT_ALIGN_CENTER, nil, 1, color_black)
            end
            
            if gang == t then
                local gang_2nd, score_2nd = FindGangThatsSecond(gang)
                draw.RoundedBox(0, ScrW() * 0.3, 25, ScrW() * 0.4, 25, get_color(gang_2nd))
                draw.SimpleTextOutlined(gang_2nd .. ": " .. score_2nd, "dank_ui.small", ScrW() * 0.25 + ScrW() * 0.25, 27.5, color_white, TEXT_ALIGN_CENTER, nil, 1, color_black)
            end
        end

		if !nlr_enabled || (NLR.Time - CurTime()) <= 0 then return end
        draw.SimpleTextOutlined("NLR: " .. math.Round(NLR.Time - CurTime()), "dank_ui.small", ScrW() / 2, ScrH(), color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM, 1, Color(200, 50, 50))
    end)
end
hook.Remove("HUDPaint", "Turf.Scores")

local function Notify(msg)
    local pnl = vgui.Create("DPanel")
    pnl:SetSize(650, 75)
    pnl:SetSkin("material_dark")
    local lbl = DankUI.CreateLabel(pnl, msg, "dank_ui.medium")
    lbl:Center()
    pnl:SetAlpha(245)

    pnl:MoveTo(ScrW() / 2 - 300, 0, 0.25, 0, -1, function()
        pnl:MoveTo(ScrW() + 600, 0, 0.25, 6, -1, function()
            pnl:Remove()
        end)   
    end)
end

net.Receive("Turf.End", function()
	local winner = net.ReadString()
	if winner != "" then
		Notify(winner .. " have won the turf war!")
	else
		Notify("There is no winner due to not enough participation!")
	end
    hook.Remove("HUDPaint", "Turf.Scores")
    timer.Remove("Camo.Remove")
    scores = nil
	id = nil
	zone = nil
end)

net.Receive("Turf.Scores", function()
	local new_id = net.ReadString()
    if !scores then
        AddHUDHook()
        timer.Create("Camo.Remove", 2, 0, function()
            if Camo.IsEnabled(LocalPlayer()) then
                RunConsoleCommand("_disable_camo")
            end
        end)
    end
	if new_id != id then
		get_team = Turfs.Registered[new_id].get_team
		get_color = Turfs.Registered[new_id].get_color
		id = new_id
	end
    scores = net.ReadTable()
    contested = net.ReadBool()
    if Cloud.DevMode then
        scores["fake gang"] = 29
    end
end)

net.Receive("Turf.Notify", function()
    local msg = net.ReadString()
    Notify(msg)
end)

net.Receive("Turf.Start", function()
	zone = net.ReadString()
	if net.ReadBit() == 1 then
		if LocalPlayer():isTerrorist() || LocalPlayer():isCP() then
			Notify("Terrorists are taking over " .. zone .. "!")
		end
	else
		nlr_enabled = net.ReadBool()
		if nlr_enabled then
			Notify("Gang turf battle started at " .. zone .. "!")
		else
			Notify("[No NLR] Gang turf battle started at " .. zone .. "!")
		end
	end
end)

local red = Color(255, 0, 0, 50) 
local cache = {}
local dist_cache = {}
hook.Add( "PostDrawTranslucentRenderables", "Turf.Zone", function( bDepth, bSkybox )
	if ( bSkybox ) then return end

	if !zone then return end
	local zone_pos = Turfs.Spots[zone][1].enclosed || Cloud.Zone.MapAreas[zone]
	if !dist_cache[zone] then
		dist_cache[zone] = Vector(zone_pos.x1 + (zone_pos.x2 - zone_pos.x1) / 2, zone_pos.y1 + (zone_pos.y2 - zone_pos.y1) / 2, zone_pos.z1 + 50)
	end
	//render.DrawSphere(dist_cache[zone], 500, 30, 30, red)
	if LocalPlayer():GetPos():DistToSqr(dist_cache[zone]) > 15000000 then return end
	if !cache[zone] then
		cache[zone] = {}
		local vector1 = Vector(zone_pos.x1, zone_pos.y1, zone_pos.z1 + 50)
		local vector2 = Vector(zone_pos.x2, zone_pos.y1, vector1.z)
		table.insert(cache[zone], {vector1, vector2})

		vector1 = Vector(zone_pos.x1, zone_pos.y1, zone_pos.z1 + 50)
		vector2 = Vector(zone_pos.x1, zone_pos.y2, vector1.z)
		table.insert(cache[zone], {vector1, vector2})

		vector1 = Vector(zone_pos.x2, zone_pos.y1, zone_pos.z1 + 50)
		vector2 = Vector(zone_pos.x1 + (zone_pos.x2 - zone_pos.x1), zone_pos.y2, vector1.z)
		table.insert(cache[zone], {vector1, vector2})

		vector1 = Vector(zone_pos.x1, zone_pos.y2, zone_pos.z1 + 50)
		vector2 = Vector(zone_pos.x2, zone_pos.y1 + (zone_pos.y2 - zone_pos.y1), vector1.z)
		table.insert(cache[zone], {vector1, vector2})
	end
	local positions = cache[zone]
	render.SetColorMaterial()
	for k, v in ipairs(positions) do
		local vector1, vector2 = unpack(v)
		render.DrawBeam(vector1, vector2, 10,0, 0, red)
	end
end )