--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/items/sh_prices.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Prices = Prices || {Registered={}, NumCPs=1, NextCheck=CurTime() + 60}

function Prices.Register(id, min, max, player_bonus, cp_bonus)
	Prices.Registered[id] = {min=min, max=max, player_bonus=player_bonus || 30, cp_bonus=cp_bonus || 800}
end

function Prices.CPEffectedPrice(id)
	if CurTime() > Prices.NextCheck then
		Prices.NumCPs = #Cloud.GetCPs()
		Prices.NextCheck = CurTime() + 120
	end
	local info = Prices.Registered[id]
	local num = math.Round((player.GetCount() * info.player_bonus) + Prices.NumCPs * info.cp_bonus)
	return math.Clamp(num, info.min, info.max)
end

function Prices.GetAllCurrent()
	local tbl = {}
	for k, v in pairs(Prices.Registered) do
		tbl[k] = Prices.CPEffectedPrice(k)
	end
	return tbl
end

if Cloud.DevMode then
	local variations = {
		["peak"] = {100, 8},
		["alot_cp"] = {90, 12},
		["empty"] = {20, 2},
		["medium"] = {50, 5},
	}
	concommand.Add("_test_price", function(ply, cmd, args)
		local pc, cp_count = unpack(variations[args[2]])
		local info = Prices.Registered[args[1]]
		local num = math.Round((pc * info.player_bonus) + cp_count * info.cp_bonus)
		print(math.Clamp(num, info.min, info.max))
	end)
end