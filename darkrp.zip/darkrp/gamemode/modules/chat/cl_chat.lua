--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/chat/cl_chat.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function GM:OnPlayerChat()
end

local ME = 0
local RANGE = 1
local OOC = 2
local ADVERT = 3
local ROLL = 4
local YELL = 5
local WHISPER = 6
local REQUEST = 7
local BROADCAST = 8
local GROUP = 9

local function GetJobColor()
    return function(ply) 
		return ply:GetJobColor()
    end
end

local function GetPlayerName()
    return function(ply) return ply:Nick() .. ": " end
end

local function GetPlayerNameForRP()
    return function(ply) return ply:Nick() .. " " end
end

local types = {
    [RANGE] = {GetJobColor(), "", GetPlayerName(), Color(255, 255, 255)},
    [YELL] = {GetJobColor(), "[Yell] ", GetPlayerName(), Color(255, 255, 255)},
    [ROLL] = {Color(255, 0, 0), "[Roll] ", GetJobColor(), GetPlayerName(), Color(255, 255, 255)},
    [OOC] = {GetJobColor(), "[OOC] ", GetPlayerName(), Color(255, 255, 255)},
    [WHISPER] = {GetJobColor(), "[Whisper] ", GetPlayerName(), Color(255, 255, 255)},
    [REQUEST] = {Color(255, 0, 0), "[Request] ", GetJobColor(), GetPlayerName(), Color(255, 255, 255)},
    [ADVERT] = {GetJobColor(), "[Advert] ", GetPlayerName(), Color(240, 240, 20)},
    [ME] = {GetJobColor(), GetPlayerNameForRP()},
    [GROUP] = {GetJobColor(), "[Group] ", GetPlayerName(), Color(255, 255, 255)},
    [BROADCAST] = {Color(255, 0, 0), "[Broadcast] ", GetPlayerName()}
}

local string_match = string.match
local string_lower = string.lower
local red = Color(200, 0, 0)
local ipairs = ipairs
local chat_AddText = chat.AddText
local chat_PlaySound = chat.PlaySound
local table_insert = table.insert
local language_GetPhrase = language.GetPhrase
local unpack = unpack
local isfunction = isfunction

local type_to_cvar = {
	[OOC] = CreateClientConVar("cg_chat_ooc", 1)
}

local convar = CreateClientConVar("cg_chat_steam_filter", 1)

net.Receive("DarkRP.Chat", function()
    local talker = net.ReadPlayer()
    if !IsValid(talker) then return end
    local index = net.ReadUInt(4)
    local msg = net.ReadString()
	if convar:GetBool() then
		msg = util.FilterText(msg, TEXT_FILTER_CHAT)
	end
	local channel = types[index]
	if Cloud.ContainsBadWord(msg) then
		if LocalPlayer():IsStaff() then
			chat_AddText(red, "Bad Word | ", color_white, channel[2] .. talker:NameID() .. ": " .. msg)
		end
		return
	end
	if type_to_cvar[index] && !type_to_cvar[index]:GetBool() then
		return
	end
	local lang = language_GetPhrase(msg)
	if lang && lang != msg then return end
    local builtMessage = {}
    for k, v in ipairs(channel) do
        table_insert(builtMessage, isfunction(v) and v(talker) or v)
    end
    table_insert(builtMessage, #builtMessage + 1, msg)
    chat_AddText(unpack(builtMessage))
    chat_PlaySound()
end)

hook.Add("ChatText", "Block.SteamNameNotify", function(id, name, text, type)
	if type == "namechange" then return true end
end)