--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_menu.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local columns = {"Weapons", "SWEPs", "Abilities", "Entities", "Slots"}

local function FilterByCategory(weps, swep)
	local swepz = {}
	for k, v in pairs(weps) do
		local attr = Jobs.Attributes[v]
		if attr.category == "SWEP" && swep then
			table.insert(swepz, v)
		elseif attr.category != "SWEP" && !swep then
			table.insert(swepz, v)
		end
	end
	return swepz
end

local function GetJobs()
	local jobs = {}
	for k, v in pairs(RPExtraTeams) do
		if v.category == "Custom" && v.slots && v.slots[LocalPlayer():SteamID()] then
			if !DarkRP.CustomJobAttributes[v.id] then
				continue
			end
			local weps, abilities, entities, shipments = Jobs.SortAttributes(DarkRP.CustomJobAttributes[v.id])
			table.insert(jobs, {
				["Name"] = v.name,
				["Color"] = v.color,
				["Model"] = v.model,
				["Skin"] = v.skin_id,
				["Bodygroups"] = v.bodygroups,
				["Slots"] = v.slots,
				["Weapons"] = FilterByCategory(weps, false),
				["SWEPs"] = FilterByCategory(weps, true),
				["Abilities"] = abilities,
				["Entities"] = table.Add(entities, shipments),
				["OwnerSteamID"] = v.owner_steamid,
				["Verified"] = v.verified,
				["ID"] = v.id,
				["TeamID"] = k,
			})
		end
	end
	return jobs
end

local function GetServerJobs()
	local jobs = {}
	for k, v in pairs(RPExtraTeams) do
		if v.category == "Custom" && v.owner_steamid == "STEAM_0:1:5261809" && Jobs.ServerJobs[v.name] then
			local weps, abilities, entities, shipments = Jobs.SortAttributes(DarkRP.CustomJobAttributes[v.id])	
			table.insert(jobs, {
				["Name"] = v.name,
				["Color"] = v.color,
				["Model"] = v.model,
				["Skin"] = v.skin_id,
				["Bodygroups"] = v.bodygroups,
				["Slots"] = v.slots,
				["Weapons"] = FilterByCategory(weps, false),
				["SWEPs"] = FilterByCategory(weps, true),
				["Abilities"] = abilities,
				["Entities"] = table.Add(entities, shipments),
				["OwnerSteamID"] = v.owner_steamid,
				["Verified"] = v.verified,
				["ID"] = v.id,
				["TeamID"] = k,
			})
		end
	end
	return jobs
end

local possible_updates = {
	[1] = {change="Model", write=net.WriteString},
	[2] = {change="Name", write=net.WriteString},
	[3] = {change="Color", write=function(color) net.WriteRGB(color.r, color.g, color.b) end},
	[4] = {change="Command", write=net.WriteString},
	[5] = {change="Skin", write=function(value) net.WriteUInt(value, 5) end},
	[6] = {change="BodyGroups", write=net.WriteTable},
}

local function SendEditJob(job_id, changes)
	net.Start("Jobs.Edit")
		net.WriteUInt(job_id, 11)
		for k, v in ipairs(possible_updates) do
			if changes[v.change] then
				net.WriteBool(true)
				v.write(changes[v.change])
			else
				net.WriteBool(false)
			end
		end
	net.SendToServer()
end

local function ConfirmEditJob(job_id, old_data, new_data)
	local changes = {}
	local total_cost = 0
	for k, v in ipairs(possible_updates) do
		if new_data[v.change] && (new_data[v.change] != old_data[v.change]) then
			changes[v.change] = new_data[v.change]
			total_cost = total_cost + Jobs.CosmeticCost
		end
	end
	if Jobs.CanAfford(LocalPlayer(), total_cost) then
		local confirm = vgui.Create("dank_ui.confirm")
		confirm:SetQuestion("Are you sure you want to buy " .. string.lower(table.concat(table.GetKeys(changes), ", ")).. "\non job " .. old_data.Name .. " for "..total_cost.." credits?")
		confirm.OnYes = function()
			SendEditJob(job_id, changes)
			confirm:Remove()
		end
	else
		Cloud.Notify("You do not have enough credits for this.")
	end
end

local function SendBuyAttribute(job_id, attribute_id)
	net.Start("Jobs.Add")
		net.WriteUInt(job_id, 11)
		net.WriteString(attribute_id)
		net.WriteBit(0)
	net.SendToServer()
end

local function BuyAttributeUI(job_id, attribute_id, item_name, attr, job_name, cback)
	local confirm = vgui.Create("dank_ui.confirm")
	confirm:SetQuestion("Are you sure you want to buy " .. item_name .. "\non job " .. job_name .. " for "..attr.price.." credits?")
	confirm.OnYes = function()
		SendBuyAttribute(job_id, attribute_id)
		confirm:Remove()
		cback()
	end
end

local function SwapAttributeUI(job_id, new_attribute_id, item_name, cost, old_attribute_id, job_name, cback)
	local confirm = vgui.Create("dank_ui.confirm")
	confirm:SetQuestion("Are you sure you want to swap " .. old_attribute_id .. "\nfor "..new_attribute_id.." on job " .. job_name .. " for "..cost.." credits?")
	confirm.OnYes = function()
		net.Start("Jobs.Swap")
			net.WriteUInt(job_id, 11)
			net.WriteString(old_attribute_id)
			net.WriteString(new_attribute_id)
		net.SendToServer()
		confirm:Remove()
		cback()
	end
end

local function SendBuySlot(job_id, steamid)
	net.Start("Jobs.Add")
		net.WriteUInt(job_id, 11)
		net.WriteString(steamid)
		net.WriteBit(1)
	net.SendToServer()
end

local function SlotMenu(is_transfer, is_owner, only_owner_slot, cback)
	local entry = vgui.Create("dank_ui.entry")
	entry:SetSize(200, 50)
	entry:Center()
	entry:SetQuestion("Enter a steamid/online player below to continue...")
	entry:PlayerAutoComplete(player.GetAll())
	entry:SetManageClose(true)
	entry.OnYes = function(s, v)
		if v then
			entry:Close()
			local id = isentity(v) and v:SteamID() or v
			gui.OpenURL("https://steamid.xyz/".. id)
			local fr = vgui.Create("dank_ui.frame")
			fr:SetSize(500, 500)
			fr:SetTitle("Confirmation")
			fr:Center()
			local txt = is_transfer && "Transfer slot to " .. id || "Buy new slot for " .. id
			local lbl = DankUI.CreateLabel(fr, txt, "dank_ui.medium")
			lbl:SetPos(fr:GetWide() / 2 - lbl:GetWide() / 2, 35)
			local check_box = vgui.Create("DCheckBoxLabel", fr)	
			check_box:SetText("Is Ownership Slot")
			check_box:SizeToContents()
			check_box:SetPos(fr:GetWide() / 2 - check_box:GetWide() / 2, lbl:GetTall() + lbl.y)
			if !is_transfer || !is_owner then
				check_box:SetEnabled(false)
			end
			if is_owner && only_owner_slot then
				check_box:SetChecked(true)
				check_box:SetEnabled(false)
			end
			local check = vgui.Create("DButton", fr)
			check:SetSize((fr:GetWide() - 15) * 0.5, 50)
			check:SetPos(5, check_box:GetTall() + check_box.y + 5)
			check:SetText("Verify Owner")
			check.DoClick = function()
				gui.OpenURL("https://steamid.xyz/".. id)
			end
			local buy = vgui.Create("DButton", fr)
			buy:SetSize(check:GetSize())
			buy:SetPos(check.x + check:GetWide() + 5, check.y)
			local txt2 = is_transfer && "Transfer | " .. 5 .. " credits" || "Buy | " .. Jobs.SlotCost .. " credits"
			buy:SetText(txt2)
			buy.DoClick = function()
				local confirm = vgui.Create("dank_ui.confirm")
				if !is_transfer then
					confirm:SetQuestion("Are you sure you want to buy this user a slot for\n" .. Jobs.SlotCost .. "C?")
				else
					confirm:SetQuestion("Are you sure you want to transfer your " .. (check_box:GetChecked() && "ownership" || "slot") .. "\nto this user for 5C?")
				end
				confirm.OnYes = function()
					cback(id, check_box:GetChecked())
					confirm:Remove()
					fr:Close()
				end
			end
			fr:SetHeight(buy.y + buy:GetTall() + 5)
			fr:Center()
		end
	end
end

local function JobSelect(job_id, attribute_id, cback)
	Jobs.SelectMenu(function(k, v, fr, pnl, scroll)
		pnl:SetParent(fr)
		pnl:SetPos(0, 30)
		fr:SetTitle("Transfer")
		scroll:Remove()
		pnl.OnMousePressed = function() end
		local owner = DankUI.CreateLabel(fr, "Owner: " .. v.owner_steamid, "dank_ui.medium")
		owner:SetPos(fr:GetWide() / 2 - owner:GetWide() / 2, pnl:GetTall() + 30)
		local attribute = DankUI.CreateLabel(fr, attribute_id, "dank_ui.medium")
		attribute:SetPos(fr:GetWide() / 2 - attribute:GetWide() / 2, owner.y + owner:GetTall())
		local attr = Jobs.Attributes[attribute_id]
		local check = vgui.Create("DButton", fr)
		check:SetSize((fr:GetWide() - 15) * 0.5, 50)
		check:SetPos(5, attribute:GetTall() + attribute.y + 5)
		check:SetText("Verify Owner")
		check.DoClick = function()
			gui.OpenURL("https://steamid.xyz/".. v.owner_steamid)
		end
		local buy = vgui.Create("DButton", fr)
		buy:SetSize(check:GetSize())
		buy:SetPos(check.x + check:GetWide() + 5, check.y)
		local cost = Jobs.CalculateTransferCost(attr.price)
		buy:SetText("Transfer | " .. cost .. " credits")
		buy.DoClick = function()
			if Jobs.CanAfford(LocalPlayer(), cost) then
				fr:Remove()
				net.Start("Jobs.TransferAttribute")
					net.WriteUInt(job_id, 11)
					net.WriteUInt(v.id, 11)
					net.WriteString(attribute_id)
				net.SendToServer()
				cback(cost)
			else
				Cloud.Notify("You do not have enough credits for this.")
			end
		end
		fr:SetHeight(buy.y + buy:GetTall() + 5)
		fr:Center()
	end)
end

local function HasAccess(data)
	return LocalPlayer():IsOwner() || data["OwnerSteamID"] == LocalPlayer():SteamID()
end

local function CreateButton(v, val, data, thing, fr)
	local btn = vgui.Create("DButton", thing)
	btn:SetText(val)
	btn:SetHeight(30)
	if (v == "Slots") then
		btn:SetEnabled(val == LocalPlayer():SteamID() || LocalPlayer():IsOwner())
		btn.DoClick = function()
			local menu = DermaMenu()
			menu:AddOption("Transfer", function() 
				fr:Close()
				SlotMenu(true, val == data.OwnerSteamID, data.Slots[val] <= 1, function(id, is_ownership)
					if (!string.StartWith(id, "STEAM_") or string.find(id, ";")) then
						Cloud.Notify("Not a valid steamid.")
						return
					end
					if Jobs.CanAfford(LocalPlayer(), Jobs.SlotTransferCost) then
						if LocalPlayer():IsOwner() && LocalPlayer():SteamID() != val then
							net.Start("Jobs.AdminTransferSlot")
								net.WriteUInt(data["ID"], 11)
								net.WriteString(id)
								net.WriteBool(is_ownership)
								net.WriteString(val)
							net.SendToServer()
						else
							local index = Jobs.FindIndex(data["ID"])
							if data.Slots[LocalPlayer():SteamID()] <= 1 then
								RPExtraTeams[index].slots[LocalPlayer():SteamID()] = nil
							else
								RPExtraTeams[index].slots[LocalPlayer():SteamID()] = data.Slots[LocalPlayer():SteamID()] - 1
							end
							if data.Slots[id] then
								RPExtraTeams[index].slots[id] = data.Slots[id] + 1
							else
								RPExtraTeams[index].slots[id] = 1
							end
							net.Start("Jobs.TransferSlot")
								net.WriteUInt(data["ID"], 11)
								net.WriteString(id)
								net.WriteBool(is_ownership)
							net.SendToServer()
						end
					else
						Cloud.Notify("You do not have enough credits for this.")
					end
				end)
			end)
			menu:Open()
		end
	else
		btn:SetEnabled(HasAccess(data))
		btn.DoClick = function() 
			local menu = DermaMenu()
			if !data.Verified then
				menu:AddOption("Sell", function()
					local confirm = vgui.Create("dank_ui.confirm")
					local price = Jobs.Attributes[val].price
					local sell_price = math.Round(price * Jobs.SellPercent)
					confirm:SetQuestion("Are you sure you want to sell " .. val .. "\nfor " .. sell_price .. " credits?")
					confirm.OnYes = function()
						net.Start("Jobs.SellAttribute")
							net.WriteUInt(data["ID"], 11)
							net.WriteString(val)
						net.SendToServer()
						confirm:Remove()
						btn:Remove()
						fr:UpdateCredits(sell_price)
					end
				end)
				menu:AddOption("Transfer", function() 
					JobSelect(data["ID"], val, function(cost)
						fr:UpdateCredits(-cost)
						btn:Remove()
					end) 
				end)
			end
			local func = function(job_id, new_attribute_id, item_name, new_attr) 
				local old_attr = Jobs.Attributes[val]
				local cost = math.Round(math.Clamp(new_attr.price - old_attr.price, 0, 1000) + 5)
				if Jobs.CanAfford(LocalPlayer(), cost) then
					SwapAttributeUI(job_id, new_attribute_id, item_name, cost, val, data.Name, function()
						fr:UpdateCredits(-cost)
						btn:SetText(new_attribute_id)
					end) 
				else
					Cloud.Notify("You do not have enough credits for this.")
				end
			end
			menu:AddOption("Swap", function() 
				Jobs.ShopMenu(v, data, "Swap", func) 
			end)
			menu:Open()
		end 
	end
	thing:AddItem(btn)
	return btn
end

local function AddUpTable(tbl)
	local count = 0
	for k, v in pairs(tbl) do
		count = count + v
	end
	return count
end

function Jobs.CreateJobPage(pnl, data, fr, server_job)
	local func = function(job_id, model, name, color, command, skin_id, body_groups) 
		local new_data = {
			["Model"] = model,
			["Name"] = name, 
			["Color"] = color,
			["Command"] = command,
			["Skin"] = skin_id,
			["BodyGroups"] = body_groups
		}
		ConfirmEditJob(job_id, data, new_data) 
	end
	local model = Jobs.AddCosmeticUI(pnl, data, "Buy", func, HasAccess(data))	

	local space = pnl:GetWide() - model:GetWide()
	local size_per_thing = (space / #columns) + 2
	local x = (model:GetWide() + model.x) - 1

	local verify = vgui.Create("DButton", pnl)
	verify:SetSize(space / (server_job && 2 || 3), 40)
	verify:SetPos(model.x + model:GetWide(), 0)
	verify:SetText(data.Verified and "Verified" or "Verify")
	if HasAccess(data) then
		verify:SetEnabled(!data.Verified)
	else
		verify:SetEnabled(false)
	end
	verify.DoClick = function()
		local confirm = vgui.Create("dank_ui.confirm")
		confirm:SetQuestion("Are you sure you want to verify this job for\n" .. Jobs.VerifyCost .. " credits?")
		confirm.OnYes = function()
			net.Start("Jobs.Verify")
				net.WriteUInt(data.ID, 11)
			net.SendToServer()
			confirm:Remove()
			verify:SetText("Verified")
			verify:SetEnabled(false)
		end
	end

	local owner = vgui.Create("DButton", pnl)
	owner:SetSize(verify:GetSize())
	owner:SetPos(verify.x + verify:GetWide(), 0)
	if server_job then
		owner:SetText("Buy | 30C")
		owner.DoClick = function()
			local confirm = vgui.Create("dank_ui.confirm")
			confirm:SetQuestion("Are you sure you want to buy this job for\n" .. 30 .. " credits?")
			confirm.OnYes = function()
				net.Start("Jobs.Buy")
					net.WriteUInt(data.ID, 11)
				net.SendToServer()
				confirm:Remove()
			end
		end
	else
		owner:SetText("View Owner")
		owner.DoClick = function()
			gui.OpenURL("https://steamid.xyz/".. data.OwnerSteamID)
		end
	end

	if !server_job then
		local restrictions = vgui.Create("DButton", pnl)
		restrictions:SetSize(owner:GetSize())
		restrictions:SetPos(owner.x + owner:GetWide(), 0)
		restrictions:SetText("View Restrictions")
		restrictions.DoClick = function()
			Jobs.RestrictionsMenu(data, model.OpenEditModel)
		end
	end

	local things_bg = vgui.Create("DPanel", pnl)
	things_bg:SetSize(space, 40)
	things_bg:SetPos(x, 40)

	for k, v in ipairs(columns) do
		local count = 0
		if v == "Slots" then
			count = data[v] && " | " .. AddUpTable(data[v]) or ""
		else
			count = data[v] && " | " .. table.Count(data[v]) or ""
		end
		local thing_name = DankUI.CreateLabel(things_bg, v .. count, "dank_ui.20")
		thing_name:SetPos(((k - 1) * size_per_thing) + size_per_thing / 2 - thing_name:GetWide() / 2, things_bg:GetTall() / 2 - thing_name:GetTall() / 2)
		local thing = vgui.Create("dank_ui.scroll", pnl)
		thing:SetSize(size_per_thing, pnl:GetTall())
		thing:SetPos(x, things_bg.y + things_bg:GetTall())
		thing:SetSpacing(-1)
		local add = vgui.Create("DButton", thing)
		add:SetText("Add +")
		add:SetHeight(30)
		add.DoClick = function()
			if v == "Slots" then
				if Jobs.CanAfford(LocalPlayer(), Jobs.SlotCost) then	
					SlotMenu(false, false, false, function(id)
						SendBuySlot(data["ID"], id)
						local index = Jobs.FindIndex(data["ID"])
						if data.Slots[id] then
							RPExtraTeams[index].slots[id] = data.Slots[id] + 1
						else
							RPExtraTeams[index].slots[id] = 1
						end
					end)
					fr:Close()
				else
					Cloud.Notify("You do not have enough credits for this. Adding a slot costs "..Jobs.SlotCost.." credits.")
				end
			else
				Jobs.ShopMenu(v, data, "Buy", function(job_id, attribute_id, item_name, attr)
					if Jobs.CanAfford(LocalPlayer(), attr.price) then
						BuyAttributeUI(job_id, attribute_id, item_name, attr, data.Name, function()
							CreateButton(v, attribute_id, data, thing, fr)
						end)
					else
						Cloud.Notify("You do not have enough credits for this.")
					end
				end)
			end
		end
		add:SetEnabled(HasAccess(data))
		thing:AddItem(add)
		if data[v] then
			local items = {}
			if (v == "Slots") then
				local searchh = vgui.Create("DTextEntry", thing)
				searchh:SetHeight(30)
				searchh:SetPlaceholderText("Search")
				searchh:SetUpdateOnType(true)
				searchh.OnValueChange = function(s, val)
					for k, v in pairs(items) do
						v:Remove()
					end
					for k, v in pairs(data[v]) do
						if !string.StartWith(string.lower(k), string.lower(val)) then continue end
						local btn = CreateButton("Slots", k, data, thing, fr)
						table.insert(items, btn)
					end
				end
				thing:AddItem(searchh)
			end	
			for k, val in pairs(data[v]) do
				if v == "Slots" then
					for i=1, val do
						local btn = CreateButton(v, k, data, thing, fr)
						table.insert(items, btn)
					end
				else
					local btn = CreateButton(v, val, data, thing, fr)
					table.insert(items, btn)
				end
			end
		end
		x = x + size_per_thing - 1
	end
end

local LAST_PAGE = "Create"

function Jobs.OpenMenu()
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(ScrW() * 0.8, ScrH() * 0.8)
	fr:SetTitle("Custom Jobs | " .. (Jobs.Credits or 0) .. " Credits")
	fr.UpdateCredits = function(s, amount)
		fr:SetTitle("Custom Jobs | " .. ((Jobs.Credits or 0) + amount) .. " Credits")
	end
	fr:Center()
	local claim = vgui.Create("DButton", fr)
	claim:SetSize(fr:GetWide() * 0.1, 30)
	claim:SetPos(fr.btnClose.x - claim:GetWide())
	claim:SetText("Claim Credits")
	claim.DoClick = function()
		RunConsoleCommand("credits_update")
		fr:Close()
	end

	local options = vgui.Create("dank_ui.menu", fr)
	options:SetPos(0, 29)
	options:SetSkin("material_dark")
	options:SetSize(fr:GetSize())
	options:SetLastPage(LAST_PAGE)

	options:AddDivider("Shop")

	local pnl = vgui.Create("DPanel", options)
	pnl.m_bBackground = false
	options:AddPage("Create", pnl)
	Jobs.CreateMenu(pnl, fr)

	options:AddButton("Buy Credits", function() gui.OpenURL("https://cloud-gaming.co.uk/darkrp/store.php?job_credits=true") end)
	options:AddButton("Claim Credits", function() RunConsoleCommand("credits_update") end)

	for k, v in pairs(GetServerJobs()) do
		local pnl = vgui.Create("DPanel", options)
		pnl.m_bBackground = false
		options:AddPage(v.Name, pnl)
		Jobs.CreateJobPage(pnl, v, fr, true)
	end

	options:AddDivider("Your Jobs")

	local added = {}
	for k, v in pairs(GetJobs()) do
		local name = v.Name
		while added[name] do
			name = name .. " "
		end
		local pnl = vgui.Create("DPanel", options)
		pnl.m_bBackground = false
		options:AddPage(v.Name, pnl)
		Jobs.CreateJobPage(pnl, v, fr)
		added[v.Name] = true
	end
end
concommand.Add("jobs_menu", Jobs.OpenMenu)
net.Receive("Jobs.Menu", Jobs.OpenMenu)