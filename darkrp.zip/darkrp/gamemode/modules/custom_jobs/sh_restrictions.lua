--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/sh_restrictions.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Jobs.CPModels = {"models/player/police.mdl", "models/player/police_fem.mdl", "models/player/combine_soldier.mdl", "models/player/combine_soldier_prisonguard.mdl",
"models/player/gasmask.mdl", "models/player/riot.mdl", "models/player/swat.mdl", "models/player/urban.mdl", "models/player/barney.mdl", "models/ghost/bz.mdl"}

Jobs.TerroristModels = {"models/player/phoenix.mdl"}

Jobs.ActiveRestrictions = Jobs.ActiveRestrictions or {}

local function HasCPModel(t)
	return table.HasValue(Jobs.CPModels, RPExtraTeams[t].model)
end

local function HasTerroristModel(t)
	return table.HasValue(Jobs.TerroristModels, RPExtraTeams[t].model)
end

local function ModelFrame(fr, models, msg, cback)
	local items = Jobs.CreateModelBrowser(fr, models, 128, function() end)
	local msg = DankUI.CreateLabel(fr, "To be " .. msg .. " you must use one of these\nmodels.", "dank_ui.20")
	msg:SetPos(5, items:GetTall() + items.y)
	local back = vgui.Create("DButton", fr)
	back:SetSize((fr:GetWide() / 2) - 7.5, 50)
	back:SetPos(5, fr:GetTall() - back:GetTall() - 5)
	back:SetText("Back")
	local change = vgui.Create("DButton", fr)
	change:SetSize(back:GetSize())
	change:SetPos(back.x + back:GetWide() + 5, back.y)
	change:SetText("Change Model")
	change.DoClick = function()
		fr:Close()
		cback(true)
	end
	back.DoClick = function()
		items:Remove()
		msg:Remove()
		back:Remove()
		change:Remove()
		cback(false)
	end
end

local function InfoFrame(fr, msg, cback)
	local msg = DankUI.CreateLabel(fr, msg, "dank_ui.20")
	msg:SetPos(5, 30)
	local back = vgui.Create("DButton", fr)
	back:SetSize((fr:GetWide() / 2) - 7.5, 50)
	back:SetPos(5, fr:GetTall() - back:GetTall() - 5)
	back:SetText("Back")
	back.DoClick = function()
		msg:Remove()
		back:Remove()
		cback(false)
	end
end

local function InfoFrameFunc(msg)
	return function(fr, cback) InfoFrame(fr, msg, cback) end
end

Jobs.Restrictions = {
	[1] = {attribute_id="cp", type="model", ui=function(fr, cback) ModelFrame(fr, Jobs.CPModels, "civil protection", cback) end, models=Jobs.CPModels, is_violating=function(t) return !HasCPModel(t) end},
	[2] = {attribute_id="take_hits", cant_have="cp", ui=InfoFrameFunc("You cannot take hits while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[3] = {attribute_id="meth", cant_have="cp", ui=InfoFrameFunc("You cannot spawn drugs while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[4] = {attribute_id="weed", cant_have="cp", ui=InfoFrameFunc("You cannot spawn drugs while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[5] = {attribute_id="mug", cant_have="cp", ui=InfoFrameFunc("You cannot mug while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[6] = {attribute_id="moonshine", cant_have="cp", ui=InfoFrameFunc("You cannot spawn drugs while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[7] = {attribute_id="kidnap", cant_have="cp", ui=InfoFrameFunc("You cannot kidnap while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[8] = {attribute_id="rob_bank", cant_have="cp", ui=InfoFrameFunc("You cannot rob the bank while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[9] = {attribute_id="weapon_policeshield", must_have="cp", ui=InfoFrameFunc("You must be CP to use the police shield."), is_violating=function(t) return !GAMEMODE.CivilProtection[t] end},
	[10] = {attribute_id="pro_lockpick_update", cant_have="cp", ui=InfoFrameFunc("You cannot use this while CP."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[11] = {attribute_id="3d2dcracker_weapon", cant_have="cp", ui=InfoFrameFunc("You cannot use this while CP."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[12] = {attribute_id="weapon_hack_phone", cant_have="cp", ui=InfoFrameFunc("You cannot use this while CP."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[13] = {attribute_id="wp_hammer", cant_have="cp", ui=InfoFrameFunc("You cannot use this while CP."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[14] = {attribute_id="drug_lab", cant_have="cp", ui=InfoFrameFunc("You cannot spawn drugs while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[15] = {attribute_id="cp_tree_police", must_have="cp", ui=InfoFrameFunc("You must be CP to gain access to the tree."), is_violating=function(t) return !GAMEMODE.CivilProtection[t] end},
	[16] = {attribute_id="cp_tree_medic", must_have="cp", ui=InfoFrameFunc("You must be CP to gain access to the tree."), is_violating=function(t) return !GAMEMODE.CivilProtection[t] end},
	[17] = {attribute_id="cp_tree_swat", must_have="cp", ui=InfoFrameFunc("You must be CP to gain access to the tree."), is_violating=function(t) return !GAMEMODE.CivilProtection[t] end},
	[18] = {attribute_id="terrorist", type="model", ui=function(fr, cback) ModelFrame(fr, Jobs.TerroristModels, "terrorist", cback) end, models=Jobs.TerroristModels, is_violating=function(t) return !HasTerroristModel(t) end},
	[19] = {attribute_id="cp", cant_have="terrorist", ui=InfoFrameFunc("You cannot have terrorist and CP"), is_violating=function(t) return GAMEMODE.Terrorist[t] end},
	[20] = {attribute_id="terrorist", cant_have="cp", ui=InfoFrameFunc("You cannot have terrorist and CP"), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
	[21] = {attribute_id="casino_ents", cant_have="cp", ui=InfoFrameFunc("You cannot run a casino while being a CP job."), is_violating=function(t) return GAMEMODE.CivilProtection[t] end},
}

function Jobs.AddActiveRestriction(job_id, attribute_id)
	if !Jobs.ActiveRestrictions[job_id] then 
		Jobs.ActiveRestrictions[job_id] = {}
	end
	Jobs.ActiveRestrictions[job_id][attribute_id] = true
end

function Jobs.IsRestricted(attribute_id, team_id, job_id)
	for k, v in pairs(Jobs.Restrictions) do
		if DarkRP.CustomJobAttributes[job_id][attribute_id] && v.attribute_id == attribute_id then
			if v.is_violating(team_id) then
				return true
			end
		end
	end
	return false
end

local function RemoveRestriction(job_id, attribute_id)
	Jobs.ActiveRestrictions[job_id][attribute_id] = nil
	Jobs.AddAttribute(job_id, attribute_id)
	if CLIENT then
		Cloud.Notify(attribute_id .. " is un-restricted.")
	end
end

local function AddRestriction(job_id, attribute_id)
	Jobs.ActiveRestrictions[job_id][attribute_id] = true
	Jobs.RemoveAttribute(job_id, attribute_id)
	DarkRP.CustomJobAttributes[job_id][attribute_id] = true
	if CLIENT then
		Cloud.Notify(attribute_id .. " is restricted!")
	end
end

function Jobs.RefreshRestrictions(job_id)
	if !Jobs.ActiveRestrictions[job_id] then
		Jobs.ActiveRestrictions[job_id] = {}
	end
	local team_id = Jobs.FindIndex(job_id)
	local violations = {}
	for _, v in ipairs(Jobs.Restrictions) do
		if !DarkRP.CustomJobAttributes[job_id] then
			if CLIENT then
				LocalPlayer():ChatPrint("No attributes found on job! Check console and send to roast.")
			else
				print("NO ATTRIBUTES FOUND..................................................")
			end
			return
		end
		if DarkRP.CustomJobAttributes[job_id][v.attribute_id] then
			if !v.is_violating(team_id) && Jobs.ActiveRestrictions[job_id][v.attribute_id] && !violations[v.attribute_id] then
				RemoveRestriction(job_id, v.attribute_id)
			elseif v.is_violating(team_id) && !Jobs.ActiveRestrictions[job_id][v.attribute_id] then
				AddRestriction(job_id, v.attribute_id)
				violations[v.attribute_id] = true
			end
		elseif !DarkRP.CustomJobAttributes[job_id][v.attribute_id] && Jobs.ActiveRestrictions[job_id][v.attribute_id] then
			Jobs.ActiveRestrictions[job_id][v.attribute_id] = nil
		end
	end
end