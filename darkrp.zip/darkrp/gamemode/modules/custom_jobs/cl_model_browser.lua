--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_model_browser.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function Jobs.CreateModelBrowser(fr, models, height, on_select, add)
	local items = vgui.Create("dank_ui.item_table", fr)
	items:SetSize(fr:GetWide(), height)
	items:SetPos(0, add || 30)
	items.KeepSquare = true
	local icons = {}
	for name, model in pairs(models) do
		local icon = vgui.Create("SpawnIcon")
		icon:SetModel( model )
		icon:SetSize(64,64)
		icon:SetPos(0, 0)
		icon:SetTooltip( name )
		icon.playermodel = name
		icon.model_path = model
		icon.DoClick = function()
			on_select(model, name)
		end
		table.insert(icons, icon)
	end
	items:AddItems(icons)
	return items
end