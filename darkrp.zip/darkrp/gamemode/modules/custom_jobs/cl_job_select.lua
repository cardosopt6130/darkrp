--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_job_select.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function GetAllCustomJobs()
	local jobs = {}
	for k, v in pairs(RPExtraTeams) do
		if v.category == "Custom" && v.owner_steamid then
			jobs[v.name] = {
				["name"] = v.name,
				["color"] = v.color,
				["model"] = v.model,
				["owner_steamid"] = v.owner_steamid,
				["id"] = v.id
			}
		end
	end
	return jobs
end

function Jobs.SelectMenu(cback)
	local all_jobs = GetAllCustomJobs()
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, (64 * 8) + 30)
	fr:SetTitle("Select another job to continue...")
	fr:Center()
	local scroll = vgui.Create("dank_ui.searchable_list", fr)
	scroll:SetPos(0, 30)
	scroll:SetSize(fr:GetWide(), fr:GetTall() - 30)
	for k, v in pairs(all_jobs) do
		local pnl = vgui.Create("DPanel", scroll)
		pnl:SetHeight(64)
		pnl.ID = v.name
		scroll:AddItem(pnl)
		local iconPanel = vgui.Create("DPanel", pnl)
		iconPanel:SetSize(64, 64)
		iconPanel:SetPos(0, 0)
		iconPanel.Paint = function(self, w, h)
			draw.RoundedBox(0, 0, 0, w, h, v.color)
			surface.SetDrawColor(DankUI.Outline)
			surface.DrawLine(w - 1, 0, w - 1, h)
		end
		local icon = vgui.Create("SpawnIcon", iconPanel)
		icon:SetSize(64, 64)
		icon:SetPos(0, 0)
		icon:SetModel(v.model)
		icon:SetMouseInputEnabled(false)

		local jobName = vgui.Create("DLabel", pnl)
		jobName:SetText(v.name)
		jobName:SetFont("dank_ui.small")
		jobName:SizeToContents()
		jobName:SetWide(jobName:GetWide() + 1)
		jobName:SetPos(iconPanel:GetWide() + 5, iconPanel:GetTall() / 2 - jobName:GetTall() / 2)

		pnl:SetCursor("hand")
		pnl.OnMousePressed = function()
			cback(k, v, fr, pnl, scroll)
		end
	end
end