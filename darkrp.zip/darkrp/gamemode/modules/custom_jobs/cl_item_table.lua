--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_item_table.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local PANEL = {}

function PANEL:Init()
	self:SetSkin("material_dark")
	self.scroll = vgui.Create("dank_ui.scroll", self)
	self.rows = {}
	self.count = 0
	self.height = 64
	self.items_per_row = 8
	self.items = {}
end

function PANEL:SetRowHeight(height)
	self.height = height
	self:PerformLayout()
end

function PANEL:SetItemsPerRow(num)
	self.items_per_row = num
	self:PerformLayout()
end

function PANEL:AddItems(tbl)
	local row = vgui.Create("DPanel", self.scroll)
	row:SetHeight(self.height)
			if self.KeepSquare then
				row:SetHeight(self:GetWide() / self.items_per_row)
			else
				row:SetHeight(self.height)
			end
	self.scroll:AddItem(row)
	self.items = tbl
	for k, v in pairs(tbl) do
		if self.count == self.items_per_row then
			row = vgui.Create("DPanel", self.scroll)
			if self.KeepSquare then
				row:SetHeight(self:GetWide() / self.items_per_row)
			else
				row:SetHeight(self.height)
			end
			self.scroll:AddItem(row)
			self.count = 0
		end
		v:SetParent(row)
		v:SetHeight(self.height)
		v:SetPos(self.count * v:GetWide(), 0)
		self.count = self.count + 1
	end
	self:PerformLayout()
end

function PANEL:PerformLayout(w, h)
	self.scroll:SetSize(w, h)
	local w2 = self:GetWide() / self.items_per_row
	for k, v in pairs(self.rows) do
		if self.KeepSquare then
			v:SetHeight(w2)
		else
			v:SetHeight(self.height)
		end
	end
	local count = 0
	for k, v in pairs(self.items) do
		v:SetWide(w2)
		if self.KeepSquare then
			v:SetHeight(w2)
		else
			v:SetHeight(self.height)
		end
		v:SetPos(w2 * count, v.y)
		count = count + 1
		if count == self.items_per_row then
			count = 0
		end
	end
end
vgui.Register("dank_ui.item_table", PANEL, "DPanel")