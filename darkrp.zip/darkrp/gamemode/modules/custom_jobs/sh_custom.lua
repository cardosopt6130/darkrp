--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/sh_custom.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function Jobs.FindIndex(job_id)
	for k, v in pairs(RPExtraTeams) do
		if v.id == job_id then
			return k
		end
	end
end

function Jobs.FindEntityIndex(class)
	for k, v in pairs(DarkRPEntities) do
		if v.ent == class then
			return k
		end
	end
end

function Jobs.AddEntities(entities, t)
	for k, v in ipairs(entities) do
		local index = Jobs.FindEntityIndex(v)
		if (DarkRPEntities[index]) then
			table.insert(DarkRPEntities[index].allowed, t)
		end
	end
end

function Jobs.RemoveEntities(entities, t)
	for k, v in ipairs(entities) do
		local index = Jobs.FindEntityIndex(v)
		if (DarkRPEntities[index]) then
			table.RemoveByValue(DarkRPEntities[index].allowed, t)
		end
	end
end

function Jobs.FindShipmentIndex(class)
	for k, v in pairs(CustomShipments) do
		if v.entity == class then
			return k
		end
	end
end

function Jobs.AddShipments(shipments, t)
	for k, v in ipairs(shipments) do
		local index = Jobs.FindShipmentIndex(v)
		if !index || !CustomShipments[index] || !CustomShipments[index].allowed then 
			print("INVALID SHIPMENT ON ADD: ", v)
			continue 
		end
		table.insert(CustomShipments[index].allowed, t)
	end
end

function Jobs.RemoveShipments(shipments, t)
	for k, v in ipairs(shipments) do
		local index = Jobs.FindShipmentIndex(v)
		if !index || !CustomShipments[index] || !CustomShipments[index].allowed then 
			print("INVALID SHIPMENT ON REMOVE: ", v)
			continue 
		end
		table.RemoveByValue(CustomShipments[index].allowed, t)
	end
end

function Jobs.ApplyChanges(job_id, changes)
	local index = Jobs.FindIndex(job_id)
	if !index then
		print("NO INDEX FOUND!")
		return
	end
	for key, new_value in pairs(changes) do
		RPExtraTeams[index][key] = new_value	
		if key == "color" then
			 team.SetColor(index, new_value)
		end
		if CLIENT && key == "name" && LocalPlayer():Team() == index then
			LocalPlayer().Job = new_value
		end
	end
	return RPExtraTeams[index]
end

function Jobs.AddWeapon(job_id, wep_class)
	local index = Jobs.FindIndex(job_id)
	table.insert(RPExtraTeams[index].weapons, wep_class)
end

function Jobs.RemoveWeapon(job_id, wep_class)
	local index = Jobs.FindIndex(job_id)
	table.RemoveByValue(RPExtraTeams[index].weapons, wep_class)
end

function Jobs.AddAttributes(team_id, attribute_ids, job_id)
	local weps, abilities, entities, shipments = Jobs.SortAttributes(attribute_ids)

	if DarkRP.CustomJobAttributes[job_id] then
		for k, v in pairs(attribute_ids) do
			DarkRP.CustomJobAttributes[job_id][k] = true
		end
	end
	RPExtraTeams[team_id].weapons = weps
	for k, v in ipairs(entities) do
		Jobs.AddEntities(Jobs.Attributes[v].entities, team_id)
	end
	for k, v in ipairs(shipments) do
		Jobs.AddShipments(Jobs.Attributes[v].shipments, team_id)
	end
	for k, v in ipairs(abilities) do
		local attribute = Jobs.Attributes[v]
		if attribute.func then
			attribute.func(team_id)
		end
	end
end

function Jobs.AddAttribute(job_id, attribute_id)
	local team_id = Jobs.FindIndex(job_id)
	local attr = Jobs.Attributes[attribute_id]
	if attr.type == "weapon" then
		Jobs.AddWeapon(job_id, attribute_id)
	elseif attr.type == "ability" then
		attr.func(team_id)
	elseif attr.type == "entity" then
		Jobs.AddEntities(attr.entities, team_id)
	elseif attr.type == "shipment" then
		Jobs.AddShipments(attr.shipments, team_id)
	end
	if DarkRP.CustomJobAttributes[job_id] then 
		DarkRP.CustomJobAttributes[job_id][attribute_id] = true
	end
end

function Jobs.RemoveAttribute(job_id, attribute_id)
	local attr = Jobs.Attributes[attribute_id]
	if attr.type == "weapon" then
		Jobs.RemoveWeapon(job_id, attribute_id)
	elseif attr.type == "ability" then
		attr.func(Jobs.FindIndex(job_id), true)
	elseif attr.type == "entity" then
		Jobs.RemoveEntities(attr.entities, Jobs.FindIndex(job_id))
	elseif attr.type == "shipment" then
		Jobs.RemoveShipments(attr.shipments, Jobs.FindIndex(job_id))
	end
	if DarkRP.CustomJobAttributes[job_id] then 
		DarkRP.CustomJobAttributes[job_id][attribute_id] = nil
	end
end

function Jobs.SortAttributes(attribute_ids)
	local weps, abilities, entities, shipments = {}, {}, {}, {}
	for attribute_id, v in pairs(attribute_ids) do
		local attr = Jobs.Attributes[attribute_id]
		if attr.type == "weapon" then
			table.insert(weps, attribute_id)
		elseif attr.type == "ability" then
			table.insert(abilities, attribute_id)
		elseif attr.type == "entity" then
			table.insert(entities, attribute_id)
		elseif attr.type == "shipment" then
			table.insert(shipments, attribute_id)
		end
	end
	return weps, abilities, entities, shipments
end

function Jobs.CanAfford(ply, amount)
	return ((SERVER && ply.JobCredits) or Jobs.Credits) >= amount
end