--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_restrictions.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function Jobs.RestrictionsMenu(job_data, change_model, violations)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, 500)
	fr:Center()
	fr:SetTitle("Restrictions")
	local scroll = vgui.Create("dank_ui.scroll", fr)
	scroll:SetSize(fr:GetWide(), fr:GetTall() - 30)
	scroll:SetPos(0, 30)
	for k, v in ipairs(Jobs.Restrictions) do
		local btn = vgui.Create("DButton", scroll)
		btn:SetText(v.attribute_id)
		btn:SetHeight(30)
		if job_data && Jobs.ActiveRestrictions[job_data.ID] then
			if Jobs.ActiveRestrictions[job_data.ID][v.attribute_id] then
				btn.textColor = Color(200, 10, 10)
			end
		elseif violations then
			if violations[v.attribute_id] || violations[v.attribute_id] == v.attribute_id then
				btn.textColor = Color(200, 10, 10)
			end
		end
		btn.DoClick = function()
			scroll:Hide()
			v.ui(fr, function(make_change)
				if make_change && change_model then
					change_model()
				else
					scroll:Show()
				end
			end)
		end
		scroll:AddItem(btn)
	end
end