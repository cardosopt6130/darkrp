--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_cosmetic.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function IsValidModel(str, attributes)
	if attributes then
		if attributes["cp"] && !table.HasValue(Jobs.CPModels, str) then
			Cloud.Notify("You cannot use a non CP model with a CP job.")
			return false
		end
		if !attributes["cp"] && table.HasValue(Jobs.CPModels, str) then
			Cloud.Notify("You cannot have a CP model with a non CP job.")
			return false
		end
	end
	return table.HasValue(player_manager.AllValidModels(), str) && !table.HasValue(Jobs.BlockedModels, str) && !string.StartsWith(string.lower(str), "models/player/suits/")
end

local function NameExists(str)
	for k, v in pairs(RPExtraTeams) do
		if v.name == str then
			return true
		end
	end
	return false
end

local function IsValidName(str)
	if string.len(str) >= 25 then
		Cloud.Notify("Name too long.")
		return false
	end
	if NameExists(str) then
		Cloud.Notify("Name already exists.")
		return false
	end
	return true
end

local default_color = Color(50, 50, 50, 255)
local stored_colour = default_color
local function EditNameJobMenu(job, action, name_main, cback)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, 500)
	fr:SetTitle("Edit Job")
	fr:Center()

	local name_v 
	local command_v

	local name_lbl = DankUI.CreateLabel(fr, "Name", "dank_ui.20")
	name_lbl:SetPos(fr:GetWide() / 2 - name_lbl:GetWide() / 2, 35)

	local name = vgui.Create("DTextEntry", fr)
	name:SetSize(fr:GetWide() * 0.8, 30)
	name:SetPos(fr:GetWide() / 2 - name:GetWide() / 2, name_lbl.y + name_lbl:GetTall() + 5)
	name:SetPlaceholderText(job.Name || "Choose a name")
	name:SetUpdateOnType(true)
	name.OnValueChange = function(s, v)
		name_v = string.Trim(v)
	end

	local command_lbl = DankUI.CreateLabel(fr, "Command", "dank_ui.20")
	command_lbl:SetPos(fr:GetWide() / 2 - command_lbl:GetWide() / 2, name:GetTall() + name.y + 5)

	local command = vgui.Create("DTextEntry", fr)
	command:SetSize(name:GetSize())
	command:SetPos(fr:GetWide() / 2 - command:GetWide() / 2, command_lbl.y + command_lbl:GetTall() + 5)
	command:SetPlaceholderText("chat command to become the job (no spaces/special characters)")
	command:SetUpdateOnType(true)
	command.OnValueChange = function(s, v)
		v = string.match(v, "[a-zA-Z]+")
		if !v or string.find(v, " ") or string.len(v) > 20 && string.len(v) < 3 then
			Cloud.Notify("Invalid command. Must between 3 and 20 characters long. No funny characters or numbers.")
			return
		end
		command_v = string.Trim(string.lower(v))
	end

	local colour_lbl = DankUI.CreateLabel(fr, "Colour", "dank_ui.20")
	colour_lbl:SetPos(fr:GetWide() / 2 - colour_lbl:GetWide() / 2, command:GetTall() + command.y + 5)

	local colour = table.Copy(job.Color) || stored_colour

	local picker = vgui.Create("DColorMixer", fr)
	picker:SetAlphaBar( false )
	picker:SetPalette( false )
	picker:SetColor(colour)
	picker:SetSize(name:GetWide(), 200)
	picker:SetPos(fr:GetWide() / 2 - picker:GetWide() / 2, colour_lbl:GetTall() + colour_lbl.y + 5)
	picker.ValueChanged = function(s, col)
		stored_colour = col
	end

	local color_preview = vgui.Create("DPanel", fr)
	color_preview:SetSize(picker:GetWide(), 30)
	color_preview:SetPos(picker.x, picker.y + picker:GetTall())
	color_preview.Paint = function(s, w, h)
		draw.RoundedBox(0, 0, 0, w, h, colour)
	end

	local buy = vgui.Create("DButton", fr)
	buy:SetSize(fr:GetWide() * 0.9, 50)
	buy:SetPos(fr:GetWide() / 2 - buy:GetWide() / 2, color_preview.y + color_preview:GetTall() + 10)
	buy:SetText(action)
	buy.DoClick = function()
		if name_v && !IsValidName(name_v) then
			return
		end
		cback(job.ID, false, name_v, picker:GetColor(), command_v)
		if name_v then
			name_main:SetText(name_v)
			name_main:SizeToContents()
		end
		fr:Close()
	end
end

local function CreateBodySlider(fr, model_preview, items, current_skin, current_bodygroups)
	if !current_bodygroups then
		current_bodygroups = {}
	end
	local num = model_preview.Player.Entity:SkinCount() - 1
	local body = vgui.Create("DNumSlider", fr)
	body:SetSize((fr:GetWide() - 15) * 0.5, 20)
	body:SetPos(5, items.y + items:GetTall())
	body:SetMax(num)
	body:SetValue(current_skin or 0)
	body:SetText("Skin")
	body:SetDecimals(0)
	body.OnValueChanged = function(s, val)
		model_preview.Player.Entity:SetSkin(math.Round(val))
		body.SelectedSkin = math.Round(val)
	end

	local num2 = model_preview.Player.Entity:GetNumBodyGroups() - 1
	local bodies = {}
	for i=0, num2 do
		local body2 = vgui.Create("DNumSlider", fr)
		body2:SetSize((fr:GetWide() - 15) * 0.5, 20)
		body2:SetPos(5, body.y + body:GetTall() + i * 20)
		body2:SetMax(model_preview.Player.Entity:GetBodygroupCount(i) - 1)
		body2:SetText(model_preview.Player.Entity:GetBodygroupName(i))
		body2:SetDecimals(0)
		body2.GroupIndex = i
		if current_bodygroups[i] then
			body2:SetValue(current_bodygroups[i])
		end
		body2.OnValueChanged = function(s, val)
			model_preview.Player.Entity:SetBodygroup(i, math.Round(val))
			body2.SelectedGroup = math.Round(val)
		end
		table.insert(bodies, body2)
	end
	return body, bodies
end

local function EditModelMenu(data, model_preview, action, cback)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(512, 700)
	fr:SetTitle("Edit Model")
	fr:Center()
	fr.OnFocusChanged = function(s, gained)
		if !gained then
			fr:Close()
		end
	end

	local models = table.Copy(player_manager.AllValidModels())
	for k, v in pairs(models) do
		if Jobs.BlockedModels[k] or table.HasValue(Jobs.BlockedModels, v) || string.StartsWith(string.lower(v), "models/player/suits/") then
			models[k] = nil
		end
	end
	if data.ID then
		for k, v in pairs(models) do
			if table.HasValue(Jobs.CPModels, v) then
				models[k] = nil
			end
		end
	end
	if data.Abilities then
		for _, v in pairs(Jobs.Restrictions) do
			if table.HasValue(data.Abilities, v.attribute_id) then
				if v.type == "model" then
					models = v.models
					break
				end
			end
		end
	end

	local body, bodies, items
	local model_v
	items = Jobs.CreateModelBrowser(fr, models, fr:GetTall() - (30 + 100), function(model)
		if IsValidModel(model, (data.ID && DarkRP.CustomJobAttributes[data.ID]) or false) then
			model_preview.Player:SetModel(model)
			model_v = model
			for k, v in pairs(bodies) do
				v:Remove()
			end
			body:Remove()
			body, bodies = CreateBodySlider(fr, model_preview, items)
		end
	end)
	body, bodies = CreateBodySlider(fr, model_preview, items, data.Skin, data.Bodygroups or {})

	local buy = vgui.Create("DButton", fr)
	buy:SetSize((fr:GetWide() - 15) * 0.5, fr:GetTall() - (items.y + items:GetTall() + 12.5))
	buy:SetPos(body.x + body:GetWide() + 5, items.y + items:GetTall() + 5)
	buy:SetText(action)

	buy.DoClick = function()
		if model_v && IsValidModel(model_v, (data.ID && DarkRP.CustomJobAttributes[data.ID]) or false) then
			local skinn = math.Round(body:GetValue())
			local body_groups = {}
			for k, v in pairs(bodies) do
				if v.SelectedGroup then
					body_groups[v.GroupIndex] = v.SelectedGroup
				end
			end
			cback(data.ID, model_v, false, false, false, body.SelectedSkin, #body_groups > 0 && body_groups)
			fr:Close()
		end
	end
end

function Jobs.AddCosmeticUI(pnl, data, action, cback, can_use)
	local model = vgui.Create("tokens_playerpreview", pnl)
	model:SetSize(pnl:GetWide() * 0.25, pnl:GetTall() - 29)
	model:SetZ(34)
	model.Player:SetFOV(14)
	model.Player:SetModel(data.Model or "models/player/Group01/male_02.mdl")
	if data.Skin then
		model.Player.Entity:SetSkin(data.Skin)
	end
	if data.Bodygroups then
		for k, v in pairs(data.Bodygroups) do
			model.Player.Entity:SetBodygroup(k, v)
		end
	end
	model:SetSkin("material_dark")
	local name_bg = vgui.Create("DPanel", model)
	name_bg:SetSize(model:GetWide(), 40)
	name_bg.Paint = function(s, w, h) 
		surface.SetDrawColor(data.Color || stored_colour)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(62, 62, 62, 120)
		surface.DrawOutlinedRect(0, 0, w, h)
	end
	local name = DankUI.CreateLabel(name_bg, data.Name || "Name", "dank_ui.20")
	name:SetPos(5, name_bg:GetTall() / 2 - name:GetTall() / 2)
	local edit = vgui.Create("DButton", name_bg)
	edit:SetSize(name_bg:GetWide() * 0.2, 30)
	edit:SetPos(name_bg:GetWide() - edit:GetWide() - 5, 5)
	edit:SetText("Edit")
	edit.DoClick = function() EditNameJobMenu(data, action, name, cback) end
	edit:SetEnabled(can_use)

	model.OpenEditModel = function() EditModelMenu(data, model, action, cback) end

	local edit2 = vgui.Create("DButton", model)
	edit2:SetSize(model:GetWide() * 0.75, 35)
	edit2:SetPos(model:GetWide() / 2 - edit2:GetWide() / 2, model:GetTall() - edit2:GetTall() - 10)
	edit2:SetText("Edit")
	edit2.DoClick = function() EditModelMenu(data, model, action, cback) end
	edit2:SetEnabled(can_use)
	return model
end