--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_create.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local columns = {"Weapons", "SWEPs", "Abilities", "Entities"}

local function IsValidModel(str, attributes)
	if attributes["cp"] && !table.HasValue(Jobs.CPModels, str) then
		Cloud.Notify("You must select a CP model!")
		return false
	end
	if !attributes["cp"] && table.HasValue(Jobs.CPModels, str) then
		Cloud.Notify("You cannot use a CP model with a non CP job!")
		return false
	end
	if !attributes["terrorist"] && table.HasValue(Jobs.TerroristModels, str) then
		Cloud.Notify("You cannot use a terrorist model with a non terrorist job!")
		return false
	end
	if attributes["terrorist"] && !table.HasValue(Jobs.TerroristModels, str) then
		Cloud.Notify("You must select a terrorist model!")
		return false
	end
	return table.HasValue(player_manager.AllValidModels(), str) && !table.HasValue(Jobs.BlockedModels, str) && !string.StartsWith(string.lower(str), "models/player/suits/")
end

local function IsValidName(str)
	if string.len(str) > 25 then
		Cloud.Notify("Name is too long!")
		return false 
	end
	return true
end

local function IsValidCommand(str)
	if !str then
		return false
	end
	if string.len(str) > 20 || string.len(str) < 3 then
		Cloud.Notify("Command must be between 3 and 20 characters.")
		return false
	end
	return true
end

local letters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"}

function Jobs.CreateMenu(pnl, fr)
	local model_v, name_v, color_v, command_v = "models/player/hostage/hostage_03.mdl", "Unknown Name", Color(200, 50, 200), "custom_job_" .. letters[math.random(#letters)]
	local skin_id_v, body_groups_v = 0, {}
	local model_pnl = Jobs.AddCosmeticUI(pnl, {}, "Add", function(job_id, model, name, color, command, skin_id, body_groups)
		if model then model_v = model end
		if name then name_v = name end
		if color then color_v = color end
		if command then command_v = command end
		if skin_id then skin_id_v = skin_id end
		if body_groups && #body_groups > 0 then
			body_groups_v = body_groups
		end
	end, true)

	local cart = {}
	local cart_btns = {}
	local violations = {}
	local total_cost = 50
	local UpdatePrice

	local space = pnl:GetWide() - model_pnl:GetWide()
	local size_per_thing = (space / #columns) + 2
	local x = (model_pnl:GetWide() + model_pnl.x) - 1
	local buy

	local things_bg = vgui.Create("DPanel", pnl)
	things_bg:SetSize(space, 40)
	things_bg:SetPos(x, 0)

	for k, v in ipairs(columns) do
		local thing_name = DankUI.CreateLabel(things_bg, v, "dank_ui.20")
		thing_name:SetPos(((k - 1) * size_per_thing) + size_per_thing / 2 - thing_name:GetWide() / 2, things_bg:GetTall() / 2 - thing_name:GetTall() / 2)
		local thing = vgui.Create("dank_ui.scroll", pnl)
		thing:SetSize(size_per_thing, pnl:GetTall())
		thing:SetPos(x, things_bg.y + things_bg:GetTall())
		thing:SetSpacing(-1)
		local add = vgui.Create("DButton", thing)
		add:SetText("Add +")
		add:SetHeight(30)
		add.DoClick = function()
			Jobs.ShopMenu(v, {}, "Add", function(job_id, attribute_id, item_name)
				if cart[attribute_id] then return end
				local btn = vgui.Create("DButton", thing)
				btn:SetText(item_name)
				btn:SetHeight(30)
				btn.attribute_id = attribute_id
				thing:AddItem(btn)
				table.insert(cart_btns, btn)
				cart[attribute_id] = true
				for _, v in ipairs(Jobs.Restrictions) do
					if cart[v.attribute_id] then
						local cant_have = (v.cant_have && cart[v.cant_have])
						local must_have = (v.must_have && !cart[v.must_have])
						if cant_have || must_have then
							for _, cart_btn in pairs(cart_btns) do
								if cart_btn.attribute_id == v.attribute_id then
									cart_btn.textColor = Color(200, 10, 10)
									violations[v.attribute_id] = cant_have && v.cant_have || must_have && v.must_have
								end
							end
						end
					end
				end
				total_cost = total_cost + Jobs.Attributes[attribute_id].price
				UpdatePrice = function()
					if total_cost >= 100 then
						local cost = math.Round(total_cost - total_cost * 0.2)
						buy:SetText("Buy | " .. cost .. " credits | 20% Off Applied")
						buy:SetEnabled(Jobs.CanAfford(LocalPlayer(), cost))
					else
						buy:SetText("Buy | " .. total_cost .. " credits")
						buy:SetEnabled(Jobs.CanAfford(LocalPlayer(), total_cost))
					end
				end
				UpdatePrice()
				btn.DoClick = function()
					local menu = DermaMenu()
					menu:AddOption("Remove", function()
						cart[attribute_id] = nil
						total_cost = total_cost - Jobs.Attributes[attribute_id].price
						for k, v in pairs(violations) do
								if k == attribute_id or v == attribute_id then
									violations[k] = nil
								end
								for _, cart_btn in pairs(cart_btns) do
									if cart_btn.attribute_id == k then
										cart_btn.textColor = Color(250, 250, 250, 150)
									end
								end
						end
						UpdatePrice()
						btn:Remove()
					end)
					menu:Open()
				end
			end)
		end
		thing:AddItem(add)
		x = x + size_per_thing - 1
	end

	local restrictions = vgui.Create("DButton", pnl)
	restrictions:SetSize((pnl:GetWide() - model_pnl:GetWide() - 30) / 2, 35)
	restrictions:SetPos(model_pnl:GetWide() + 10, pnl:GetTall() - restrictions:GetTall() - 40)
	restrictions:SetText("View Restrictions")
	restrictions.DoClick = function()
		Jobs.RestrictionsMenu(false, model_pnl.OpenEditModel, violations)
	end

	local discount = DankUI.CreateLabel(pnl, "Spend over 100 credits and get 20% off!", "dank_ui.20")
	local space = pnl:GetWide() - model_pnl:GetWide()
	discount:SetPos(model_pnl:GetWide() + space / 2 - discount:GetWide() / 2, restrictions.y - restrictions:GetTall())

	buy = vgui.Create("DButton", pnl)
	buy:SetSize(restrictions:GetSize())
	buy:SetPos(restrictions:GetWide() + restrictions.x + 10, restrictions.y)
	buy:SetText("Buy | " .. total_cost .. " credits")
	buy:SetEnabled(Jobs.CanAfford(LocalPlayer(), total_cost))
	buy.DoClick = function()
		if IsValidModel(model_v, cart) && IsValidCommand(command_v) && IsValidName(name_v) then
			local confirm = vgui.Create("dank_ui.confirm")
			local cost = total_cost >= 100 && math.Round(total_cost - total_cost * 0.2) || total_cost
			confirm:SetQuestion("Are you sure you want to create this job\nfor " .. cost .. " job credits?")
			confirm.OnYes = function()
				net.Start("Jobs.Create")
					net.WriteString(name_v)
					net.WriteString(model_v)
					net.WriteRGB(color_v.r, color_v.g, color_v.b)
					net.WriteString(command_v)
					net.WriteUInt(skin_id_v, 5)
					net.WriteTable(body_groups_v)
					net.WriteTable(cart)
				net.SendToServer()
				confirm:Remove()
				fr:Close()
			end
		end
	end
end