--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/sh_cfg.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Jobs = Jobs or {}

Jobs.BlockedModels = {
	["breen"] = "models/player/breen.mdl",
	["combineelite"] = "models/player/combine_super_soldier.mdl",
	["ghost"] = "models/ghost/bz.mdl",
	["Escape from Tarkov - Tagilla"] = "models/player/eft/tagilla/eft_tagilla/models/eft_tagilla_pm.mdl",

}

Jobs.SlotCost = 25
Jobs.CosmeticCost = 3
Jobs.SlotTransferCost = 5
Jobs.SellPercent = 0.65
Jobs.VerifyCost = 20
Jobs.MoneyMakingLimit = 3

Jobs.ServerJobs = {
	["Rebellion"] = true,
	["Chief Inspector"] = true,
}

function Jobs.CalculateTransferCost(price)
	if price <= 30 then
		return 5
	elseif price <= 50 then
		return 10
	elseif price <= 80 then
		return 15
	end
	return 20
end

/*
	Staff Guns
	m9k_striker12
	m9k_svu
	m9k_sig_p229r
	m9k_auga3
	m9k_fists
	bb_m4a1
	m9k_ares_shrike

	Gameplay guns
	mac_bo2_qbblsw
	mac_bo2_pdw
	mac_bo2_vector
	mac_bo2_hk416
	mac_bo2_ksg
	mac_bo2_ballista
	mac_bo2_mp7
	mac_bo2_smr
	mac_bo2_type25

	Private Guns
	blast_msbsb (Sprickles)
	blast_lsat (Sprickles)
	blast_jdj (Fed)
	Spawnable Drugs (Fed)
	m9k_an94 (Duck)
	unclen8_mk14 (Shook)
	unclen8_mg3 (Shook)
	m9k_fal (Rica)
	bb_ak47 (Duck)
	ksg (duck)
	pdw jake
	fg42 olly/shook
	ppsh duck
	m9k_m16a4_acog shadeswift
	m9k_tar21 shook
	bo2 mtar shook
	bo2 svu fed
	bo2 exec duck
	bo2 an94 duck
	bo2 scrop duck
	mac_bo2_swat next
	unclen8_sr25 shook
	DSR no owner
	mac_bo2_xpr50 hiro
	atlas_m4a4_howl manu

	private ents
	tolls panda/duck
	drugs fed
	gun shelf shook
*/

Jobs.Attributes = {
	["m9k_davy_crowbar"] = {price=20, type="weapon", desc="Davy crocket model, HL1 crowbar functionality", category="SWEP"},
	["pro_lockpick_update"] = {price=20, type="weapon", desc="Slowly pick locked doors just to get mown down instantly as soon as the door opens", category="SWEP"},
	["3d2dcracker_weapon"] = {price=20, type="weapon", desc="BEEP BEEP BEEEP BEEP fading door opens", category="SWEP"},
	["weapon_hack_phone"] = {price=30, type="weapon", desc="Opens fading doors instantly, don’t do crack just hack", category="SWEP"},
	["diguisekit"] = {price=30, type="weapon", desc="Too poor to afford ace so you just imitate, trust me you aren’t the first.", category="SWEP"},
	["climb_swep2"] = {price=30, type="weapon", desc="Reaching new heights, sadly QA higher is invite only.", category="SWEP"},
	["weapon_camo"] = {price=40, type="weapon", desc="Tyloo Approved", category="SWEP"},
	["weapon_cat"] = {price=25, model="models/dingus/dingus.mdl", type="weapon", desc="Maxwell The Cat", category="SWEP"},
	["bhop_swep"] = {price=25, type="weapon", desc="Now you don’t have to script.", category="SWEP"},
	["weapon_fists"] = {price=15, type="weapon", desc="Useless", category="SWEP"},
	["unarrest_stick"] = {price=15, type="weapon", desc="unfortunately this doesn’t work in Admin sits.", category="SWEP"},
	["wp_hammer"] = {price=15, type="weapon", desc="No longer cross mapping.", category="SWEP"},
	["weapon_lightsaber"] = {price=40, type="weapon", desc="R to heal, right click to jump.", category="SWEP"},
	["weapon_policeshield"] = {price=30, type="weapon", desc="The 10hp exploit still works.", category="SWEP"},
	["weapon_medkit"] = {price=50, type="weapon", desc="HL2 Medkit", category="SWEP"},
	["med_kit"] = {price=50, type="weapon", desc="DarkRP Medkit", category="SWEP"},
	["gmod_camera"] = {price=30, type="weapon", desc="SNAP!", category="SWEP"},
	["pickaxe"] = {price=15, type="weapon", desc="Slave away in the gulag, permanently", category="SWEP"},
	["m9k_poo"] = {price=30, type="weapon", desc="Poo gun, shoots poo...", category="SWEP"},
	["grappling_hook"] = {price=50, type="weapon", desc="Spiderman vibes", private=true, category="SWEP"},
    ["m9k_sledge_hammer"] = {price=40, type="weapon", category="SWEP", private=true},
    ["weapon_fed"] = {price=40, type="weapon", category="SWEP", private=true},
    ["weapon_bugbait"] = {price=30, type="weapon", category="SWEP", private=true},
    ["gold_fishing_rod"] = {price=40, type="weapon", category="SWEP", private=true},
    ["op_fishing_rod"] = {price=35, type="weapon", category="SWEP"},
    ["adrenaline"] = {price=60, type="weapon", category="SWEP"},

	["m9k_matador"] = {price=175, type="weapon", category="OTHER"},
	["m9k_ex41"] = {price=175, type="weapon", category="OTHER"},
	["m9k_damascus"] = {price=15, type="weapon", category="OTHER"},
	["m9k_exile"] = {price=185, type="weapon", category="OTHER"},
	["m9k_mustang"] = {price=220, type="weapon", category="OTHER"},
	["m9k_milkormgl"] = {price=200, type="weapon", category="OTHER"},
	["m9k_knife"] = {price=15, type="weapon", category="OTHER"},
	//["snowball_thrower_nodamage"] = {price=25, type="weapon", category="OTHER"},

	["weapon_crossbow"] = {price=35, type="weapon", category="HL2"},
	//["weapon_pistol"] = {price=15, type="weapon", category="HL2"},
	["weapon_crowbar"] = {price=15, type="weapon", category="HL2"},
	//["weapon_ar2"] = {price=35, type="weapon", category="HL2"},
	//["weapon_shotgun"] = {price=35, type="weapon", category="HL2"},
	//["weapon_smg1"] = {price=25, type="weapon", category="HL2"},
	["weapon_357"] = {price=35, type="weapon", category="HL2"},

	["m9k_scar"] = {price=35, type="weapon", category="AR"},
	["m9k_acr"] = {price=35, type="weapon", category="AR"},
	["m9k_ak47"] = {price=35, type="weapon", category="AR"},
	["m9k_f2000"] = {price=30, type="weapon", category="AR"},
	["m9k_l85"] = {price=35, type="weapon", category="AR"},
	["m9k_m14sp"] = {price=40, type="weapon", category="AR"},
	["m9k_m4a1"] = {price=35, type="weapon", category="AR"},
	["m9k_ace_gun"] = {price=35, type="weapon", category="AR"},
	["m9k_m16a4_acog"] = {price=30, type="weapon", category="AR", private=true},
	["mac_bo2_deathmach"] = {price=40, type="weapon", category="AR", private=true},
	["unclen8_sr25"] = {price=40, type="weapon", category="AR", private=true},
	["m9k_an94"] = {price=30, type="weapon", category="AR", private=true},
	["atlas_m4a4_howl"] = {price=30, type="weapon", category="AR", private=true},
	["mac_bo2_scar"] = {price=30, type="weapon", category="AR", private=true},
	["mac_bo2_type25"] = {price=30, type="weapon", category="AR", private=true},
	["mac_bo2_falosw"] = {price=30, type="weapon", category="AR", private=true},
	["ryry_m9k_arx"] = {price=30, type="weapon", category="AR", private=true},
	["weapon_ak47_beast"] = {price=30, type="weapon", category="AR", private=true},
	["deika_blundergat"] = {price=30, type="weapon", category="SHOTGUN", private=true},
	//["mac_bo2_m8a1"] = {price=40, type="weapon", category="AR", private=true},
	//["mac_bo2_qbblsw"] = {price=30, type="weapon", category="AR", private=true},
	//["mac_bo2_m1216"] = {price=30, type="weapon", category="SHOTGUN", private=true},
	["m9k_fal"] = {price=40, type="weapon", category="AR", private=true},
	["weapon_deagle_bornbeast"] = {price=30, type="weapon", category="PISTOL", private=true},
	["m9k_suppressed_uzi"] = {price=40, type="weapon", category="AR", private=true},
	["unclen8_mk14"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_870"] = {price=40, type="weapon", category="SHOTGUN", private=true},
	["unclen8_mg3"] = {price=40, type="weapon", category="AR", private=true},
	["bb_ak47"] = {price=40, type="weapon", category="AR", private=true},
	["m9k_svu"] = {price=40, type="weapon", category="AR", private=true},
	["unclen8_rpk"] = {price=40, type="weapon", category="AR", private=true},
	["m9k_ares_shrike"] = {price=40, type="weapon", category="AR", private=true},
	["m9k_keltec"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_peacekpr"] = {price=40, type="weapon", category="AR", private=true}, // no owner traded for s12
	["mac_bo2_s12"] = {price=40, type="weapon", category="SHOTGUN", private=true},
	["mac_bo2_an94"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_scorp"] = {price=40, type="weapon", category="SMG", private=true},
	["m9k_mp5sd"] = {price=40, type="weapon", category="SMG", private=true},
	["mac_bo2_chicom"] = {price=40, type="weapon", category="SMG", private=true},
	["mac_bo2_hamr"] = {price=40, type="weapon", category="AR", private=true},
	["doi_stg44"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_swat"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_dsr50"] = {price=40, type="weapon", category="AR", private=true},
	["mac_bo2_xpr50"] = {price=40, type="weapon", category="AR", private=true},
	//["m9k_amr11"] = {price=40, type="weapon", category="AR", private=true},
	["m9k_amd65"] = {price=30, type="weapon", category="AR"},
	["m9k_m416"] = {price=30, type="weapon", category="AR"},
	["m9k_val"] = {price=40, type="weapon", category="AR"},
	["m9k_g36"] = {price=35, type="weapon", category="AR"},
	["m9k_winchester73"] = {price=50, type="weapon", category="AR"},
	["m9k_ak74"] = {price=35, type="weapon", category="AR"},
	["m9k_g3a3"] = {price=30, type="weapon", category="AR"},
	["m9k_vikhr"] = {price=30, type="weapon", category="AR"},
	["m9k_tar21"] = {price=35, type="weapon", category="AR", private=true},
	["m9k_famas"] = {price=35, type="weapon", category="AR"},
    ["ryry_m9k_remington"] = {price=65, private=true, type="weapon", category="AR"},

    ["m9k_mp40"] = {price=25, type="weapon", category="SMG"},
    ["m9k_magpulpdr"] = {price=30, type="weapon", category="SMG"},
    ["m9k_honeybadger"] = {price=35, type="weapon", category="SMG"},
    ["m9k_bizonp19"] = {price=35, type="weapon", category="SMG"},
    ["m9k_ump45"] = {price=25, type="weapon", category="SMG"},
    ["m9k_mp9"] = {price=35, type="weapon", category="SMG"},
    ["m9k_uzi"] = {price=30, type="weapon", category="SMG"},
    ["m9k_mp7"] = {price=30, type="weapon", category="SMG"},
    ["m9k_vector"] = {price=30, type="weapon", category="SMG"},
    ["m9k_smgp90"] = {price=25, type="weapon", category="SMG"},
    ["m9k_mp5"] = {price=30, type="weapon", category="SMG"},
    ["m9k_usc"] = {price=25, type="weapon", category="SMG"},
    ["m9k_kac_pdw"] = {price=30, private=true, type="weapon", category="SMG"},
    ["m9k_sten"] = {price=20, type="weapon", category="SMG"},
    ["m9k_thompson"] = {price=20, type="weapon", category="SMG"},
    ["m9k_tec9"] = {price=20, type="weapon", category="SMG"},
    ["juju_ppsh"] = {price=65, private=true, type="weapon", category="SMG"},
    ["blast_msbsb"] = {price=40, private=true, type="weapon", category="SMG"},

    ["m9k_m1918bar"] = {price=30, type="weapon", category="LMG"},
    ["mac_bo2_lsat"] = {price=35, type="weapon", category="LMG"},
    ["m9k_minigun"] = {price=50, type="weapon", category="LMG"},
    ["m9k_m60"] = {price=40, type="weapon", category="LMG"},
    ["m9k_pkm"] = {price=40, type="weapon", category="LMG"},
    ["m9k_m249lmg"] = {price=40, type="weapon", category="LMG"},
    ["m9k_fg42"] = {price=40, type="weapon", category="LMG", private=true},
    ["blast_lsat"] = {price=40, type="weapon", category="LMG", private=true},
    ["mac_bo2_exec"] = {price=40, type="weapon", category="SHOTGUN", private=true},
    ["mac_bo2_mtar"] = {price=40, type="weapon", category="SMG", private=true},
    ["mac_bo2_svu"] = {price=40, type="weapon", category="SNIPER", private=true},

	["m9k_m40a3"] = {price=40, type="weapon", category="SNIPER"},
    ["m9k_aw50"] = {price=40, type="weapon", category="SNIPER"},
    ["m9k_svt40"] = {price=30, type="weapon", category="SNIPER"},
    ["m9k_dragunov"] = {price=35, type="weapon", category="SNIPER"},
    ["m9k_sl8"] = {price=40, type="weapon", category="SNIPER"},
    ["m9k_psg1"] = {price=30, type="weapon", category="SNIPER"},
    ["m9k_remington7615p"] = {price=30, type="weapon", category="SNIPER"},
	["m9k_contender"] = {price=20, type="weapon", category="SNIPER"},
    ["m9k_barret_m82"] = {price=35, type="weapon", category="SNIPER"},
	//["blast_jdj"] = {price=30, type="weapon", category="SNIPER", private=true},
	["weapon_m4a1_beast"] = {price=40, type="weapon", category="AR", private=true},
    ["m9k_m98b"] = {price=35, type="weapon", category="SNIPER"},
    ["m9k_m24"] = {price=35, type="weapon", category="SNIPER"},
    ["m9k_intervention"] = {price=35, type="weapon", category="SNIPER"},

    ["m9k_colt1911"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_coltpython"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_hk45"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_deagle"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_glock"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_m29satan"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_ragingbull"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_scoped_taurus"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_model3russian"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_model500"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_remington1858"] = {price=20, type="weapon", category="PISTOL"},
    ["m9k_deagle"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_usp"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_m92beretta"] = {price=15, type="weapon", category="PISTOL"},
    ["m9k_luger"] = {price=15, type="weapon", category="PISTOL"},
    ["mac_bo2_b23r"] = {price=30, type="weapon", category="PISTOL"},
    ["m9k_enzo"] = {price=150, type="weapon", category="PISTOL", private=true},


    ["m9k_browningauto5"] = {price=30, type="weapon", category="SHOTGUN"},
    ["m9k_ithacam37"] = {price=35, type="weapon", category="SHOTGUN"},
    ["m9k_dbarrel"] = {price=45, type="weapon", category="SHOTGUN"},
    ["m9k_usas"] = {price=40, type="weapon", category="SHOTGUN"},
    ["m9k_spas12"] = {price=40, type="weapon", category="SHOTGUN"},
    ["m9k_m3"] = {price=30, type="weapon", category="SHOTGUN"},
    ["m9k_jackhammer"] = {price=35, type="weapon", category="SHOTGUN"},
    ["m9k_remington870"] = {price=25, type="weapon", category="SHOTGUN"},
    ["m9k_1897winchester"] = {price=35, type="weapon", category="SHOTGUN"},
    ["m9k_1887winchester"] = {price=35, type="weapon", category="SHOTGUN"},
    ["m9k_mossberg590"] = {price=35, type="weapon", category="SHOTGUN"},

    ["bb_awp"] = {price=55, type="weapon", category="CSS"},
    ["bb_deagle"] = {price=25, type="weapon", category="CSS"},
    ["bb_dualelites"] = {price=25, type="weapon", category="CSS"},
    ["bb_p90"] = {price=30, type="weapon", category="CSS"},
    ["bb_g3sg1"] = {price=40, type="weapon", category="CSS"},
    ["bb_galil"] = {price=35, type="weapon", category="CSS"},
    ["bb_glock"] = {price=25, type="weapon", category="CSS"},
    ["bb_ump45"] = {price=25, type="weapon", category="CSS"},
    ["bb_scout"] = {price=35, type="weapon", category="CSS"},
    ["bb_p228"] = {price=15, type="weapon", category="CSS"},
    ["bb_sg550"] = {price=40, type="weapon", category="CSS"},
    ["bb_m249"] = {price=40, type="weapon", category="CSS"},
    ["bb_css_knife"] = {price=20, type="weapon", category="CSS"},
    ["bb_usp"] = {price=25, type="weapon", category="CSS"},
    ["bb_m3"] = {price=35, type="weapon", category="CSS"},
    ["bb_mac10"] = {price=35, type="weapon", category="CSS"},
    ["bb_mp5"] = {price=30, type="weapon", category="CSS"},
    ["bb_sg552"] = {price=35, type="weapon", category="CSS"},
    ["bb_aug"] = {price=35, type="weapon", category="CSS"},
    ["bb_tmp"] = {price=35, type="weapon", category="CSS"},
    ["bb_xm1014"] = {price=35, type="weapon", category="CSS"},
    ["awpdragon"] = {price=70, type="weapon", category="CSS", private=true},

	//abilities
	["take_hits"] = {price=40, type="ability", category="ABILITY", broadcast=true, desc="Take hits", func = function(t, remove) 
		if remove then
			DarkRP.HitmanTeams[t] = nil
		else
			DarkRP.addHitmanTeam(t) 
		end
	end},
	["rob_bank"] = {price=25, type="ability", category="ABILITY", desc="Rob the bank", func = function(t, remove) 
		if remove then
			GAMEMODE.RobBank[t] = nil 
		else
			GAMEMODE.RobBank[t] = true 
		end
	end},
	["cp"] = {price=35, type="ability",category="ABILITY", desc="Act as CP", func = function(t, remove) 
		if remove then
			GAMEMODE.CivilProtection[t] = nil
		else
			GAMEMODE.CivilProtection[t] = true 
		end
	end},
	["terrorist"] = {price=35, type="ability",category="ABILITY", desc="Act as terrorist", func = function(t, remove) 
		if remove then
			GAMEMODE.Terrorist[t] = nil
		else
			GAMEMODE.Terrorist[t] = true 
		end
	end},
	["mug"] = {price=15, type="ability",category="ABILITY", desc="Mug people", func = function(t, remove) 
		if remove then
			RPExtraTeams[t].permissions["Can mug"] = false
		else
			RPExtraTeams[t].permissions["Can mug"] = true 
		end
	end},
	["kidnap"] = {price=15, type="ability",category="ABILITY", desc="Kidnap people", func = function(t, remove) 
		if remove then
			RPExtraTeams[t].permissions["Can kidnap"] = false
		else
			RPExtraTeams[t].permissions["Can kidnap"] = true 
		end
	end},
	["100_armor"] = {price=40, type="ability",category="ABILITY", desc="100 Armor", func = function(t, remove) 
		if remove then
			RPExtraTeams[t].armor = 0
		else
			RPExtraTeams[t].armor = 100
		end
	end},
	// cp tree
	["cp_tree_medic"] = {price=50, type="ability",category="ABILITY", desc="CP Medic Tree", is_tree=true, func= function(t, remove)
		if remove then
			JobLevels.RemoveJob(t)
		else
			JobLevels.AddJob(t, "swat_medic")
		end
	end},
	["cp_tree_swat"] = {price=50, type="ability",category="ABILITY", desc="CP SWAT Tree", is_tree=true, func=function(t, remove)
		if remove then
			JobLevels.RemoveJob(t)
		else
			JobLevels.AddJob(t, "swat")
		end
	end},
	["cp_tree_police"] = {price=50, type="ability",category="ABILITY", desc="CP Police Tree", is_tree=true, func=function(t, remove)
			if remove then
			JobLevels.RemoveJob(t)
		else
			JobLevels.AddJob(t, "police")
		end
	end},
	// misc
	["scoped_hud"] = {price=70, type="ability",category="ABILITY", desc="See peoples above head HUD when scoping.", private=true, func=function(t, remove)
		if CLIENT then
			if remove then
				GAMEMODE.ScopedHUD[t] = nil
			else
				GAMEMODE.ScopedHUD[t] = true
			end
		end
	end},
	// money entity
	["weed"] = {price=50, type="entity",category="ENTITY", desc="Grow weed.", money_making=true, entities={"weed_plant", "weed_box", "weed_seed", "weed_grow"}},
	["moonshine"] = {price=50, type="entity",category="ENTITY", desc="Produce moonshine.", money_making=true, entities={"bottle1", "bottle2", "bottlemaker"}},
	["cocaine"] = {price=50, type="entity",category="ENTITY", desc="Make a cocaine factory.", money_making=true, entities={"cocaine_extractor"}},
	["meth"] = {price=50, type="entity",category="ENTITY", desc="Cook meth.", money_making=true, entities={"eml_jar", "eml_iodine", "eml_gas", "eml_macid", "eml_pot", "eml_spot", "eml_stove", "eml_sulfur", "eml_water"}},
	["crypto_miner"] = {price=35, type="entity",category="ENTITY", desc="Mine cryptos.", money_making=true, entities={"crypto_miner"}},
	["gun_shelf"] = {price=40, type="entity",category="ENTITY", desc="Gun shelf", money_making=true, private=true, entities={"gun_shelf"}},
	["casino_ents"] = {price=50, type="entity",category="ENTITY", desc="Blackjack and roulette table.", money_making=true, entities={"pcasino_roulette_table", "pcasino_blackjack_table"}},
	// entity
	["dj"] = {price=30, type="entity",category="ENTITY", desc="Blast the tunes.", entities={"whk_tv"}},
	["armor_charger"] = {price=50, type="entity",category="ENTITY", desc="Spawn armor charger.", entities={"armor_charger_slow"}},
	["drug_lab"] = {price=50, type="entity",category="ENTITY", desc="Lab that spawns drugs.", entities={"drug_lab"}},
	["store_shelf"] = {price=40, type="entity",category="ENTITY", desc="Allows you to sell inventory items.", entities={"store_shelf"}},
	["drugs"] = {price=75, type="entity",category="ENTITY", desc="Droooogs.", private=true, entities={"durgz_alcohol", "durgz_pcp", "durgz_weed"}},
	["toll"] = {price=50, type="entity",category="ENTITY", desc="Tolls", private=true, entities={"toll"}},
	// shipments
	["gun_dealer_guns"] = {price=30, type="shipment", category="ENTITY", desc="Gun dealer weapons.", shipments={"m9k_colt1911", "m9k_luger", "m9k_psg1"}},
	["spec_arms_guns"] = {price=30, type="shipment", category="ENTITY", desc="Special arms weapons.", shipments={"weapon_plasmanade", "m9k_rpg7", "m9k_m98b"}},
	["duck_guns"] = {price=30, type="shipment", private=true, category="ENTITY", desc="Weapons from dumpsters, mining and gang dealer.", shipments={"m9k_contender", "bb_m4a1"}},
}