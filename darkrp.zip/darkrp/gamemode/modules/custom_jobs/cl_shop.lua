--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_shop.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local gun_stats = {
	["RPM"] = function(w, wep) 
		local rpm = wep.Primary.RPM
		return math.Clamp((rpm * (w / 1000)), 0, w), rpm, 1000
	end,
	["ClipSize"] = function(w, wep) 
		local cs = wep.Primary.ClipSize
		return  math.Clamp((cs * (w / 100)), 0, w), cs, 100 
	end,
	["Damage"] = function(w, wep) 
		local dmg = wep.Primary.Damage
		return math.Clamp((dmg * (w / 100)), 0, w), dmg, 100 
	end,
	["Spread"] = function(w, wep) 
		local spread = 1 - wep.Primary.Spread
		return math.Clamp((spread * (w / 1)), 0, w), spread, 1 
	end,
	["NumShots"] = function(w, wep) 
		local num_shots = wep.Primary.NumShots
		return math.Clamp((num_shots * (w / 10)), 0, w), num_shots, 10
	end,
	["KickUp"] = function(w, wep) 
		local kickup = wep.Primary.KickUp
		return math.Clamp((kickup * (w / 3)), 0, w), kickup, 3 
	end,
	["KickDown"] = function(w, wep) 
		local kickdown = wep.Primary.KickDown
		return math.Clamp((kickdown * (w / 3)), 0, w), kickdown, 3
	end,
	["KickHorizontal"] = function(w, wep) 
		local kickh = wep.Primary.KickHorizontal
		return math.Clamp((kickh * (w / 3)), 0, w), kickh, 3
	end,
}

local function DrawWeaponStats(fr, wep, items, job_id, attribute_id, action, attr, cback)
	items:Hide()
	local mdl = vgui.Create("DModelPanel", fr)
	mdl:SetSize(fr:GetWide() * 0.5, fr:GetWide() * 0.5)
	mdl:SetPos(0, 30)
	mdl:SetModel(wep.WorldModel)
	mdl:SetFOV(60)
	local shouldRotate = true
	local rotation = Angle(0, 40, 0)
	mdl.OnMousePressed = function() 
		shouldRotate = !shouldRotate 
	end
	mdl.Entity:SetAngles(Angle(0, 40, 0))
	function mdl:LayoutEntity(ent) 
		local count = ent:GetBoneCount()
		local boneNumber = count == 1 and 0 or count / 2
		local bonePos = ent:GetBonePosition(boneNumber)
		local pos = bonePos + Vector(0, 0, -2.5)
		mdl:SetLookAt(pos)
		mdl:SetCamPos(pos-Vector(-40, 40, -25))
		if shouldRotate then
			ent:SetAngles(rotation)
			rotation = rotation + Angle(0, 0.5, 0)
		end
	end

	local buy = vgui.Create("DButton", fr)
	buy:SetSize(mdl:GetWide() * 0.75, 40)
	buy:SetPos(mdl:GetWide() / 2 - buy:GetWide() / 2, fr:GetTall() - (buy:GetTall() + 20))
	buy:SetText(action)
	buy.DoClick = function()
		cback(job_id, attribute_id, wep.PrintName, attr)
		fr:Close()
	end

	local stats = vgui.Create("DPanel", fr)
	stats:SetSize(fr:GetWide() * 0.5, fr:GetTall() - 30)
	stats:SetPos(mdl.x + mdl:GetWide(), 30)

	local count = 0
	for k, v in pairs(gun_stats) do
		local barW = stats:GetWide() - 20
		local width, num, maxNum = v(barW, wep)
		local name = DankUI.CreateLabel(stats, k .. " (" .. num .. "/" .. maxNum .. ")", "dank_ui.small")
		name:SetPos(10, 5 + count  * 45)
		local bar = vgui.Create("DPanel", stats)
		bar:SetSize(barW, 20)
		bar:SetPos(10, name.y + name:GetTall())
		bar.Paint = function(s, w, h)
			surface.SetDrawColor(50, 200, 50, 150)
			surface.DrawRect(0, 0, width, h)
			surface.SetDrawColor(DankUI.Outline)
			surface.DrawOutlinedRect(0, 0, w, h)
		end
		count = count + 1
	end
end

local function FindEnt(entz)
	for k, v in pairs(DarkRPEntities) do
		if table.HasValue(entz, v.ent) then
			return v
		end
	end
	return false
end

local function FindShipment(entz)
	for k, v in pairs(CustomShipments) do
		if table.HasValue(entz, v.entity) then
			return v
		end
	end
	return false
end

local hl2 = {
	["weapon_pistol"] = {name="HL2 Pistol", model="models/weapons/w_pistol.mdl"},
	["weapon_crossbow"] = {name="HL2 Crossbow", model="models/weapons/w_crossbow.mdl"},
	["weapon_crowbar"] = {name="HL2 Crowbar", model="models/weapons/w_crowbar.mdl"},
	["weapon_smg1"] = {name="HL2 SMG", model="models/weapons/w_smg1.mdl"},
	["weapon_shotgun"] = {name="HL2 Shotgun", model="models/weapons/w_shotgun.mdl"},
	["weapon_ar2"] = {name="HL2 AR2", model="models/weapons/w_irifle.mdl"},
	["weapon_357"] = {name="HL2 357", model="models/weapons/w_357.mdl"},
}

local function GetItemInfo(id, item_type, type)
	if item_type == "Weapons" || item_type == "SWEPs" then
		if hl2[id] then
			return hl2[id], hl2[id].name, hl2[id].model
		end
		local wep = weapons.Get(id)
		if !wep then 
			print("NO WEP FOR " .. id)
			return 
		end
		return wep, wep.PrintName, wep.WorldModel
	elseif item_type == "Entities" then
		if type == "shipment" then
			local shipment = FindShipment(Jobs.Attributes[id].shipments)
			return shipment, Jobs.Attributes[id].desc, shipment.model
		elseif type == "entity" then
			local ent = FindEnt(Jobs.Attributes[id].entities)
			return ent, Jobs.Attributes[id].desc, ent.model
		end
	end
	return Jobs.Attributes[id], Jobs.Attributes[id].desc, nil
end

local function GetItemsOfCategory(category)
	local items = {}
	for k, v in pairs(Jobs.Attributes) do
		if table.HasValue(category, v.category) then
			if v.private && (!LocalPlayer():IsOwner() && !(Cloud.QAMode && LocalPlayer():IsSeniorAdmin())) then
				continue
			end
			items[k] = v
		end
	end
	return items
end

local type_to_category = {
	["Weapons"] = {"SHOTGUN", "OTHER", "SMG", "PISTOL", "SNIPER", "AR", "CSS", "HL2", "LMG"},
	["SWEPs"] = {"SWEP"},
	["Abilities"] = {"ABILITY"},
	["Entities"] = {"ENTITY"},
}

local item_types = {
	["Weapons"] = {func=DrawWeaponStats, no_desc=true},
	["SWEPs"] = {},
	["Abilities"] = {no_spawn_icon = true, no_desc=true},
	["Entities"] = {no_desc=true}
}

function Jobs.ShopMenu(item_type, data, action, cback)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, 500)
	fr:SetTitle("View " .. item_type)
	fr:Center()
	local tip = vgui.Create("DPanel")
	tip:SetVisible(false)
	fr.OnClose = function()
		tip:Remove()
	end
	local items = vgui.Create("dank_ui.searchable_list", fr)
	items:SetSize(fr:GetWide(), fr:GetTall() - 25)
	items:SetPos(0, 30)
	items.sort = SortedPairsByMemberValue
	items.key = "price"
	for attribute_id, v in SortedPairsByMemberValue(GetItemsOfCategory(type_to_category[item_type]), "price") do
		local item, item_name, item_model = GetItemInfo(attribute_id, item_type, v.type)
		if !item then 
			print("No item for " .. attribute_id)
			continue 
		end
		local info = item_types[item_type]
		local has_attribute = data[item_type] and table.HasValue(data[item_type], attribute_id)
		local pnl = vgui.Create("DPanel")
		pnl:SetSize(250, 64)
		pnl:SetSkin("material_dark")
		pnl.price = v.price
		pnl.IDs = {item_name, attribute_id}
		table.Merge(pnl.IDs, string.Explode(" ", item_name))
		if !has_attribute then
			pnl:SetCursor("hand")
			pnl.OnMousePressed = function()
				if info.func && !hl2[attribute_id] then
					info.func(fr, item, items, data["ID"], attribute_id, action, v, cback)
				else
					cback(data["ID"], attribute_id, item_name, v)
					fr:Close()
				end
			end
		end
		local x = 10
		if !info.no_spawn_icon then
			local iconPanel = vgui.Create("DPanel", pnl)
			iconPanel:SetSize(64, 64)
			iconPanel:SetPos(0, 0)
			iconPanel.Paint = function(self, w, h)
				draw.Gradient(self, items, w - 2, h - 2, Color(30, 30, 30, 200), 0.2, "top",Color(50, 50, 50, 220) , 1, 1)
				surface.SetDrawColor(DankUI.Outline)
				surface.DrawLine(w - 1, 0, w - 1, h)
			end
			local icon = vgui.Create("SpawnIcon", iconPanel)
			icon:SetModel(Jobs.Attributes[attribute_id].model || item_model)
			icon:SetSize(64,64)
			icon:SetPos(0, 0)
			icon:SetMouseInputEnabled(false)
			x = 64 + 5
		end
		if !info.no_desc then
			pnl.OnCursorEntered = function()
				if IsValid(tip) then
					tip:SetVisible(true)
					local txt = Jobs.Attributes[attribute_id].desc or ""
					local wrap = DankUI.WordWrap("dank_ui.small", txt, 200)
					if IsValid(tip.desc) then
						tip.desc:Remove()
					end
					tip.desc = DankUI.CreateLabel(tip, table.concat(wrap, "\n"), "dank_ui.small")
					tip:SetSkin("material_dark")
					tip:MakePopup()
					tip:SetSize(tip.desc:GetWide(), tip.desc:GetTall() - 5)
					tip.desc:SetPos(5, 5)
					local x, y = gui.MousePos()
					tip:SetPos(x, y - tip:GetTall())
				end
			end
			pnl.OnCursorMoved = function()
				local x, y = gui.MousePos()
				if IsValid(tip) then
					tip:SetPos(x, y - tip:GetTall())
				end
			end
			pnl.OnCursorExited = function()
				if IsValid(tip) then
					tip:SetVisible(false)
				end
			end
		end
		local name = DankUI.CreateLabel(pnl, item_name, "dank_ui.small")
		name:SetPos(x, (pnl:GetTall() / 2 - name:GetTall() / 2) - name:GetTall() / 2)
		local price = DankUI.CreateLabel(pnl, v.price .. " credits", "dank_ui.small")
		price:SetPos(name.x, name.y + price:GetTall())
		if has_attribute then
			name:SetColor(Color(50, 200, 50))
			price:SetColor(Color(50, 200, 50))
		end
		items:AddItem(pnl)
	end
end