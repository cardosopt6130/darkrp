--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_admin.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local fr
local job_id

local function FilterByCategory(weps, swep)
	local swepz = {}
	for k, v in pairs(weps) do
		local attr = Jobs.Attributes[v]
		if attr.category == "SWEP" && swep then
			table.insert(swepz, v)
		elseif attr.category != "SWEP" && !swep then
			table.insert(swepz, v)
		end
	end
	return swepz
end

local function OpenMenu()
	if LocalPlayer():IsSuperAdmin() || Cloud.QAMode && LocalPlayer():IsSeniorAdmin() then
		Jobs.SelectMenu(function(k, v, frame)
			fr = frame
			job_id = v.id
			net.Start("Jobs.Admin")
				net.WriteUInt(v.id, 11)
			net.SendToServer()
		end)
	end
end
concommand.Add("jobs_admin", OpenMenu)

net.Receive("Jobs.Admin", function()
	if IsValid(fr) then
		fr:Remove()
	end
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(ScrW() * 0.8, ScrH() * 0.8)
	fr:SetTitle("Custom Jobs | Admin")
	fr:Center()
	fr.UpdateCredits = function()

	end
	local pnl = vgui.Create("DPanel", fr)
	pnl:SetSize(fr:GetWide(), fr:GetTall() - 30)
	pnl:SetPos(0, 30)

	local slots, attributes, verified, skin_id, bodygroups = Jobs.ReadJobInfo()
	local weps, abilities, entities, shipments = Jobs.SortAttributes(attributes)

	local index = Jobs.FindIndex(job_id)
	local v = RPExtraTeams[index]

	local tbl = {
			["Name"] = v.name,
			["Color"] = v.color,
			["Model"] = v.model,
			["Skin"] = skin_id,
			["Bodygroups"] = bodygroups,
			["Slots"] = slots,
			["Weapons"] = FilterByCategory(weps, false),
			["SWEPs"] = FilterByCategory(weps, true),
			["Abilities"] = abilities,
			["Entities"] = entities,
			["OwnerSteamID"] = v.owner_steamid,
			["Verified"] = verified,
			["ID"] = v.id,
			["TeamID"] = index
	}

	Jobs.CreateJobPage(pnl, tbl, fr)
end)