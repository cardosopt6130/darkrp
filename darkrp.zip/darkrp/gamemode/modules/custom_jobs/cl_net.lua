--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/custom_jobs/cl_net.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function Jobs.ReadJob()
	local job = {}
	job.name = net.ReadString()
	job.model = net.ReadString()
	job.color = Color(net.ReadRGB())
	job.category = "Custom"
	job.command = net.ReadString()
	job.max = 20
	job.salary = 100
	job.description = ""
	job.weapons = {}
	job.admin = 0
	job.vote = false
	job.hasLicense = false
	job.owner_steamid = net.ReadString()
	job.candemote = false
	job.chief = false
	if net.ReadBit() == 1 then
		job.attributes = net.ReadTable()
	end
	return job
end

function Jobs.ReadJobInfo()
	return net.ReadTable(), net.ReadTable(), net.ReadBool(), net.ReadUInt(5), net.ReadTable()
end

DarkRP.CustomJobs = DarkRP.CustomJobs or {}
DarkRP.CustomJobAttributes = DarkRP.CustomJobAttributes or {}

local function AddJob(id, job, has_access)
	local callAfter = function(team_id)
		if job.attributes then
			Jobs.AddAttributes(team_id, job.attributes, id)
		end
	end
	if (has_access) || Jobs.ServerJobs[job.name] then
		local slots, attributes, verified, skin_id, bodygroups = Jobs.ReadJobInfo()
		job.slots = slots
		job.skin_id = skin_id != 0 && skin_id
		job.bodygroups = #bodygroups > 0 && bodygroups || false
		job.customCheck = function(ply) return slots[ply:SteamID()] end
		job.verified = verified
		callAfter = function(team_id)
			DarkRP.CustomJobAttributes[id] = {}
			if job.attributes then
				table.Merge(attributes, job.attributes)
			end
			Jobs.AddAttributes(team_id, attributes, id)
			Jobs.RefreshRestrictions(id)
		end
	else
		job.customCheck = function(ply) return false end
	end

	if Jobs.ServerJobs[job.name] then
		job.customCheck = function(ply) return true end
		job.CustomCheckFailMsg = "To purchase this job type !jobs"
	end

	job.permissions = {
		["Can raid"] = true,
		["Can mug"] = false,
		["Can kidnap"] = false
	}
	job.id = id
	local team_id = DarkRP.createJob(job.name, job)
	table.insert(DarkRP.CustomJobs, team_id)
	if callAfter then callAfter(team_id) end
end

net.Receive("Jobs.Create", function()
	AddJob(net.ReadUInt(11), Jobs.ReadJob(), net.ReadBit() == 1)
end)

Jobs.Credits = Jobs.Credits or 0

net.Receive("Jobs.Credits", function()
	local amount = net.ReadUInt(16) 
	Jobs.Credits = amount
end)

net.Receive("Jobs.InitialData", function()
	local count = net.ReadUInt(11)
	for k, v in pairs(DarkRP.CustomJobs) do
		DarkRP.removeJob(v.team_id)
	end
	for i=1, count do
		AddJob(net.ReadUInt(11), Jobs.ReadJob(), net.ReadBit() == 1)
	end
	hook.Run("DarkRP.JobsLoaded")
end)

net.Receive("Jobs.Update", function()
	local job_id = net.ReadUInt(11)
	local changes = net.ReadTable()
	Jobs.ApplyChanges(job_id, changes)
	if changes["model"] then
		Jobs.RefreshRestrictions(job_id)
	end
end)

net.Receive("Jobs.Info", function()
	local job_id = net.ReadUInt(11)
	local slots, attributes, verified, skin_id, bodygroups = Jobs.ReadJobInfo()
	local index = Jobs.FindIndex(job_id)
	RPExtraTeams[index].permissions = {
		["Can raid"] = false,
		["Can mug"] = false,
		["Can kidnap"] = false
	}
	RPExtraTeams[index].slots = slots
	RPExtraTeams[index].customCheck = function(ply) return RPExtraTeams[index].slots[ply:SteamID()] end
	RPExtraTeams[index].verified = verified
	RPExtraTeams[index].skin_id = skin_id != 0 && skin_id
	RPExtraTeams[index].bodygroups = #bodygroups > 0 && bodygroups || false

	DarkRP.CustomJobAttributes[job_id] = {}
	Jobs.AddAttributes(index, attributes, job_id)
	Jobs.RefreshRestrictions(job_id)
end)

net.Receive("Jobs.Attribute", function()
	local remove = net.ReadBool()
	local job_id = net.ReadUInt(11)
	local attribute_id = net.ReadString()
	if remove then
		Jobs.RemoveAttribute(job_id, attribute_id)
	else
		Jobs.AddAttribute(job_id, attribute_id)
	end
	if DarkRP.CustomJobAttributes[job_id] then
		Jobs.RefreshRestrictions(job_id)
	end
end)

net.Receive("Jobs.Verify", function()
	local job_id = net.ReadUInt(11)
	local index = Jobs.FindIndex(job_id)
	RPExtraTeams[index].verified = true
end)

net.Receive("Jobs.UpdateOwner", function()
	local job_id = net.ReadUInt(11)
	local index = Jobs.FindIndex(job_id)
	RPExtraTeams[index].owner_steamid = net.ReadString()
end)