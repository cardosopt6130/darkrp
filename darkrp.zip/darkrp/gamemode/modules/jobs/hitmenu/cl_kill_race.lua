--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/hitmenu/cl_kill_race.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

net.Receive("Contracts", function()
	local next_bounty = net.ReadUInt(17)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, 500)
	fr:Center()
	if next_bounty > CurTime() then
		fr:SetTitle("Contracts (" .. Cloud.TimeLeftString(next_bounty - CurTime()) .. " cooldown)")
	else
		fr:SetTitle("Contracts")
	end
	local scroll = vgui.Create("dank_ui.scroll", fr)
	scroll:SetSize(fr:GetWide(), fr:GetTall() - 30)
	scroll:SetPos(0, 30)
	scroll:SetPadding(1)
    local players = table.Copy(player.GetAll())

    table.sort(players, function(a, b)
        local aTeam, bTeam, aNick, bNick = team.GetName(a:Team()), team.GetName(b:Team()), string.lower(a:Nick()), string.lower(b:Nick())
        return aTeam == bTeam and aNick < bNick or aTeam < bTeam
    end)
	for k, v in pairs(players) do
		if !IsValid(v) || v == LocalPlayer() then continue end
		local pnl = vgui.Create("DPanel", scroll)
		pnl:SetTall(30)
		pnl:SetCursor("hand")
		pnl.OnMousePressed = function()
			local entry = vgui.Create("dank_ui.entry")
			entry:SetQuestion("How much?")
			entry:SetNumeric(true)
			entry.OnYes = function(s, value)
				local num = value && tonumber(value)
				if num && num > 1000 && LocalPlayer():canAfford(num) then
					net.Start("Contracts")
						net.WritePlayer(v)
						net.WriteUInt(num, 30)
					net.SendToServer()
					fr:Close()
				else
					DarkRP.NotifyWithName("Amount needs to be great than £1000, you must also be able to afford it.", "Cloud")
				end
			end
		end
		pnl.Paint = function(s, w, h)
			if !IsValid(v) then return end
			draw.RoundedBox(0, 0, 0, w, h, team.GetColor(v:Team()))
			draw.SimpleTextOutlined(v:Nick(), "dank_ui.20", 5, h/2, color_white, nil, TEXT_ALIGN_CENTER, 1, color_black)
			draw.SimpleTextOutlined(team.GetName(v:Team()), "dank_ui.20", w - 5, h/2, color_white, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER, 1, color_black)
		end
		scroll:AddItem(pnl)
	end
end)