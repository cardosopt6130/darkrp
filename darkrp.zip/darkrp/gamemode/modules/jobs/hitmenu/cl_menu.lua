--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/hitmenu/cl_menu.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local PANEL

/*---------------------------------------------------------------------------
Hitman menu
---------------------------------------------------------------------------*/
PANEL = {}

AccessorFunc(PANEL, "hitman", "Hitman")
AccessorFunc(PANEL, "target", "Target")
AccessorFunc(PANEL, "selected", "Selected")

function PANEL:Init()
    self.BaseClass.Init(self)

    self.btnClose = vgui.Create("DButton", self)
    self.btnClose:SetText("")
    self.btnClose.DoClick = function() self:Remove() end
    self.btnClose.Paint = function(panel, w, h) derma.SkinHook("Paint", "WindowCloseButton", panel, w, h) end

    self.icon = vgui.Create("SpawnIcon", self)
    self.icon:SetDisabled(true)
    self.icon.PaintOver = function(icon) icon:SetTooltip() end
    self.icon:SetTooltip()

    self.title = vgui.Create("DLabel", self)
    self.title:SetText(DarkRP.getPhrase("hitman"))

    self.name = vgui.Create("DLabel", self)
    self.price = vgui.Create("DLabel", self)

    self.playerList = vgui.Create("DScrollPanel", self)

    self.btnRequest = vgui.Create("HitmanMenuButton", self)
    self.btnRequest:SetText(DarkRP.getPhrase("hitmenu_request"))
    self.btnRequest.DoClick = function()
        if IsValid(self:GetTarget()) then
			if !DarkRP.CanPlaceHitOn(self:GetTarget()) then
                DarkRP.Notify("You cannot place a hit on that person.", 1)
                return
            end
            if !LocalPlayer():canAfford(self:GetHitman():getHitPrice() and self:GetHitman():getHitPrice() or 15000) then
                DarkRP.Notify("You cannot afford this persons hit price.", 1)
                return
            end
            local confirm = vgui.Create("dank_ui.confirm")
            confirm:SetQuestion("Are you sure you want to place this hit\n for " .. DarkRP.formatMoney(self:GetHitman():GetNetVar("hitPrice") and self:GetHitman():getHitPrice() or 15000) .. "?")
            confirm.OnYes = function()
                if self:GetTarget() then
                    RunConsoleCommand("darkrp", "requesthit", self:GetTarget():SteamID(), self:GetHitman():UserID())
                end
                confirm:Remove()
                self:Remove()
            end
        end
    end

    self.btnCancel = vgui.Create("HitmanMenuButton", self)
    self.btnCancel:SetText(DarkRP.getPhrase("cancel"))
    self.btnCancel.DoClick = function() self:Remove() end

    self:SetSkin("material_dark")

    self:InvalidateLayout()
end

function PANEL:Think()
    if not IsValid(self:GetHitman()) or self:GetHitman():GetPos():Distance(LocalPlayer():GetPos()) > GAMEMODE.Config.minHitDistance then
        self:Remove()
        return
    end

    -- update the price (so the hitman can't scam)
    self.price:SetText(DarkRP.getPhrase("priceTag", DarkRP.formatMoney(self:GetHitman():getHitPrice()), ""))
    self.price:SizeToContents()
end

function PANEL:PerformLayout()
    local w, h = self:GetSize()

    self:SetSize(500, 700)
    self:Center()

    self.btnClose:SetSize(24, 24)
    self.btnClose:SetPos(w - 24 - 5, 5)

    self.icon:SetSize(128, 128)
    self.icon:SetModel(self:GetHitman():GetModel())
    self.icon:SetPos(20, 20)

    self.title:SetFont("ScoreboardHeader")
    self.title:SetPos(20 + 128 + 20, 20)
    self.title:SizeToContents(true)

    self.name:SizeToContents(true)
    self.name:SetText(DarkRP.getPhrase("name", self:GetHitman():Nick()))
    self.name:SetPos(20 + 128 + 20, 20 + self.title:GetTall())

    self.price:SetFont("HUDNumber5")
    self.price:SetColor(Color(255, 0, 0, 255))
    self.price:SetText(DarkRP.getPhrase("priceTag", DarkRP.formatMoney(self:GetHitman():getHitPrice()), ""))
    self.price:SetPos(20 + 128 + 20, 20 + self.title:GetTall() + 20)
    self.price:SizeToContents(true)

    self.playerList:SetPos(20, 20 + self.icon:GetTall() + 20)
    self.playerList:SetWide(self:GetWide() - 40)

    self.btnRequest:SetPos(20, h - self.btnRequest:GetTall() - 20)
    self.btnRequest:SetButtonColor(Color(0, 120, 30, 255))

    self.btnCancel:SetPos(w - self.btnCancel:GetWide() - 20, h - self.btnCancel:GetTall() - 20)
    self.btnCancel:SetButtonColor(Color(140, 0, 0, 255))

    self.playerList:StretchBottomTo(self.btnRequest, 20)

    self.BaseClass.PerformLayout(self)
end

function PANEL:Paint()
    local w, h = self:GetSize()

    surface.SetDrawColor(Color(0, 0, 0, 200))
    surface.DrawRect(0, 0, w, h)
end

function PANEL:AddPlayerRows()
    local players = table.Copy(player.GetAll())

    table.sort(players, function(a, b)
        local aTeam, bTeam, aNick, bNick = team.GetName(a:Team()), team.GetName(b:Team()), string.lower(a:Nick()), string.lower(b:Nick())
        return aTeam == bTeam and aNick < bNick or aTeam < bTeam
    end)

    for k, v in pairs(players) do
        if !v:Alive() then continue end

        local line = vgui.Create("HitmanMenuPlayerRow")
        line:SetPlayer(v)
        self.playerList:AddItem(line)
        line:SetWide(self.playerList:GetWide() - 100)
        line:Dock(TOP)

        line.DoClick = function()
            self:SetTarget(line:GetPlayer())

            if IsValid(self:GetSelected()) then
                self:GetSelected():SetSelected(false)
            end

            line:SetSelected(true)
            self:SetSelected(line)
        end
    end
end
vgui.Register("HitmanMenu", PANEL, "DPanel")

/*---------------------------------------------------------------------------
Hitmenu button
---------------------------------------------------------------------------*/
PANEL = {}

AccessorFunc(PANEL, "btnColor", "ButtonColor")

function PANEL:PerformLayout()
    self:SetSize(self:GetParent():GetWide() / 2 - 30, 100)
    self:SetFont("HUDNumber5")
    self:SetTextColor(Color(255, 255, 255, 255))

    self.BaseClass.PerformLayout(self)
end

function PANEL:Paint()
    local w, h = self:GetSize()
    local col = self:GetButtonColor() or Color(0, 120, 30, 255)
    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    surface.DrawRect(0, 0, w, h)
end

vgui.Register("HitmanMenuButton", PANEL, "DButton")

/*---------------------------------------------------------------------------
Player row
---------------------------------------------------------------------------*/
PANEL = {}

AccessorFunc(PANEL, "player", "Player")
AccessorFunc(PANEL, "selected", "Selected", FORCE_BOOL)

function PANEL:Init()
    self.lblName = vgui.Create("DLabel", self)
    self.lblName:SetMouseInputEnabled(false)
    self.lblName:SetColor(Color(255,255,255,200))

    self.lblTeam = vgui.Create("DLabel", self)
    self.lblTeam:SetMouseInputEnabled(false)
    self.lblTeam:SetColor(Color(255,255,255,200))

    self:SetText("")

    self:SetCursor("hand")
end

function PANEL:PerformLayout()
    local ply = self:GetPlayer()
    if not IsValid(ply) then self:Remove() return end

    self.lblName:SetFont("UiBold")
    self.lblName:SetText(DarkRP.deLocalise(ply:Nick()))
    self.lblName:SizeToContents()
    self.lblName:SetPos(10, 1)

    self.lblTeam:SetFont("UiBold")
    self.lblTeam:SetText((ply.DarkRPVars and DarkRP.deLocalise(ply:getDarkRPVar("job") or "")) or team.GetName(ply:Team()))
    self.lblTeam:SizeToContents()
    self.lblTeam:SetPos(self:GetWide() / 2, 1)
end

function PANEL:Paint()
    if not IsValid(self:GetPlayer()) then self:Remove() return end

    local color = team.GetColor(self:GetPlayer():Team())
    color.a = self:GetSelected() and 70 or 255

    surface.SetDrawColor(color)
    surface.DrawRect(0, 0, self:GetWide(), 20)
end
vgui.Register("HitmanMenuPlayerRow", PANEL, "Button")

/*---------------------------------------------------------------------------
Open the hit menu
---------------------------------------------------------------------------*/
function DarkRP.openHitMenu(hitman)
    local frame = vgui.Create("HitmanMenu")
    frame:SetHitman(hitman)
    frame:AddPlayerRows()
    frame:SetVisible(true)
    frame:MakePopup()
end
