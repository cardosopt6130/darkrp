--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/hitmenu/sh_init.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local plyMeta = FindMetaTable("Player")
DarkRP.HitmanTeams = DarkRP.HitmanTeams or {}

local no_hits = {
	teams = {
		["Admin on Duty"] = true,
		["Mod on Duty"] = true
	},
	steamids = {
		["STEAM_0:0:60762189"] = true,
		["STEAM_0:1:5261809"] = true,
		["STEAM_0:1:28503096"] = true,
		["STEAM_0:0:24317764"] = true,
		["STEAM_0:0:50052151"] = true,
		["STEAM_0:0:591586800"] = true,
		["STEAM_0:0:145690593"] = true,
	}
}

function DarkRP.CanPlaceHitOn(targ)
	return !no_hits.steamids[targ:SteamID()] && !no_hits.teams[team.GetName(targ:Team())]
end

function plyMeta:isHitman()
    return DarkRP.HitmanTeams[self:Team()]
end

function plyMeta:hasHit()
    return self:getDarkRPVar("hasHit") or false
end

function plyMeta:getHitTarget()
    return self:getDarkRPVar("hitTarget")
end

function plyMeta:getHitPrice()
    return self:getDarkRPVar("hitPrice") or 15000
end

function DarkRP.addHitmanTeam(job)
    if not job or not RPExtraTeams[job] then return end
    if DarkRP.DARKRP_LOADING and DarkRP.disabledDefaults["hitmen"][RPExtraTeams[job].command] then return end

    DarkRP.HitmanTeams[job] = true
end
DarkRP.getHitmanTeams = fp{fn.Id, DarkRP.HitmanTeams}

function DarkRP.isHitmanTeam(job)
    return DarkRP.HitmanTeams[job]
end

hook.Add("onJobRemoved", "hitmenuUpdate", function(i, job)
    DarkRP.HitmanTeams[i] = nil
end)

/*---------------------------------------------------------------------------
DarkRPVars
---------------------------------------------------------------------------*/
nw.Register "hasHit"
	:Write(net.WriteBool)
	:Read(net.ReadBool)
	:SetPlayer()
nw.Register "hitTarget"
	:Write(net.WritePlayer)
	:Read(net.ReadPlayer)
	:SetLocalPlayer()
	:SetHook("nw.HitTarget")
nw.Register "hitPrice"
    :Write(net.WriteUInt, 18)
    :Read(net.ReadUInt, 18)
    :SetPlayer()