--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/hitmenu/cl_init.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local localplayer
local textCol1, textCol2 = Color(0, 0, 0, 200), Color(128, 30, 30, 255)
local plyMeta = FindMetaTable("Player")

hook.Add("HUDPaint", "DrawHitOption", function()
    local localplayer = LocalPlayer()
    local x, y
    local ply = localplayer:GetEyeTrace().Entity

    if localplayer:isHitman() and localplayer:hasHit() and IsValid(localplayer:getHitTarget()) then
        if Camo.IsEnabled(ply) or ply.Disguise then
            return
        end
        x, y = chat.GetChatBoxPos()
        local text = DarkRP.getPhrase("current_hit", localplayer:getHitTarget():Nick())
        draw.DrawNonParsedText(text, "HUDNumber5", x + 1, y + 1, textCol1, 0)
        draw.DrawNonParsedText(text, "HUDNumber5", x, y, team.GetColor(localplayer:getHitTarget():Team()), 0)
    end
end)

hook.Add("nw.HitTarget", "DarkRP.HitTargetChange", function(ply, new, old)
	if new == nil && IsValid(old) then
    	hook.Run("onHitCompleted", ply, old)
	elseif IsValid(new) then
    	hook.Run("onHitAccepted", ply, new)
	end
end)
