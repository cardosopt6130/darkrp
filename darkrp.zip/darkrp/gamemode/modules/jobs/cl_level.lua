--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/cl_level.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local pairs = pairs
local ipairs = ipairs
local player_GetAll = player.GetAll
local LocalPlayer = LocalPlayer

local cvar = CreateClientConVar("cg_cp_esp", 1)

local function CountTrees(tree_data)
	local count = 0
	for k, v in pairs(tree_data) do
		if v.tree then
			count = count + 1
		end
	end
	return count
end

local button_w, button_h = 100, 50
local spacing = 10
local line_thickness = 1
local line_colour = Color(200, 200, 200, 60)

local selected_job

local hidden = {}

local function ToFadeIn(pnl)
	pnl:SetAlpha(0)
	table.insert(hidden, pnl)
end

local function FadeIn()
	wait = true
	for k, v in pairs(hidden) do
		v:AlphaTo(255, 1.75, 0, function()
			wait = false
		end)
	end
	table.Empty(hidden)
end

local function GenerateDescription(current_preview)
	if !current_preview then
		return "Unknown description." 
	end
	if current_preview.desc then
		return current_preview.desc
	end
	if current_preview.name == "Model" then
		return "New player model while playing the job."
	end
	if current_preview.name == "Speed" then
		return "Boosts run speed while playing the job."
	end
	if current_preview.swep then
		local wep = weapons.Get(current_preview.swep)
		if wep && wep.PrintName then
			return "New weapon (" .. wep.PrintName .. ") while playing the job."
		else
			return "New weapon (" .. current_preview.swep .. ") while playing the job."
		end
	end
	if current_preview.salary then
		return "Boosts salary to " .. DarkRP.formatMoney(current_preview.salary) .. "!"
	end
	if current_preview.tree then
		return "Unlocks new tree pathway. Note: this locks other pathways."
	end
	return "Unknown description."
end

local function GetModel(current_preview)
	if current_preview.model then
		return current_preview.model, current_preview.fov
	end
	if current_preview.salary then
		return "models/props/cs_assault/money.mdl"
	end
	if current_preview.swep then
		local wep = weapons.Get(current_preview.swep)
		if wep && wep.WorldModel then
			return wep.WorldModel, 20
		end
	end
	if current_preview.name == "Speed" then
		return "models/props_junk/shoe001a.mdl", 20
	end
	if current_preview.name == "Armor" then
		return "models/Items/hevsuit.mdl", 70
	end
	return "models/props_lab/monitor01a.mdl", 30
end

local preview
local unlock
local function PreviewPanel(fr, trees, current_preview)
	if !IsValid(preview) then
		preview = vgui.Create("DPanel", fr)
		preview.SetPreview = function(s, new_preview, btn)
			for k, v in pairs(preview:GetChildren()) do
				if IsValid(v) then
					v:Remove()
				end
			end
			PreviewPanel(fr, trees, new_preview)
			preview.Current = new_preview
			preview.TreeButton = btn
			local unlock_data = JobLevels.UnlockIDToData[selected_job.id] && JobLevels.UnlockIDToData[selected_job.id][new_preview.id]
			unlock:SetEnabled(JobLevels.CanUnlock(selected_job.id, new_preview.id, unlock_data, selected_job))
		end
		preview:SetSize(fr:GetWide() - trees:GetWide() + 1, fr:GetTall() * 0.8)
		preview:SetPos(trees.x + trees:GetWide() - 1, trees.y)
	end

	local title = DankUI.CreateLabel(preview, current_preview.name || "Boobzka", "dank_ui.medium")
	title:SetPos(preview:GetWide() / 2 - title:GetWide() / 2, 5)

	local divider = vgui.Create("dank_ui.divider", preview)
	divider:SetPos(10, title.y + title:GetTall() + 5)

	local wrapped = D3A.WordWrap("dank_ui.20", GenerateDescription(current_preview), preview:GetWide() - 20)
	local desc = DankUI.CreateLabel(preview, table.concat(wrapped, "\n"), "dank_ui.20")
	desc:SetPos(10, divider.y + divider:GetTall() + 5)

	local image_w = preview:GetWide() - 30
	local image_bg = vgui.Create("DPanel", preview)
	image_bg:SetSize(image_w, image_w * 0.8)
	image_bg:SetPos(15, desc.y + desc:GetTall())

	local mdl, fov = GetModel(current_preview)
	local image = vgui.Create("DModelPanel", image_bg)
	image:SetModel(mdl)
	image:SetSize(image_bg:GetSize())
	if mdl == "models/Items/hevsuit.mdl" then
		image:SetLookAt(Vector(20, 20, 40))
	elseif mdl=="models/Items/combine_rifle_ammo01.mdl" then
		image:SetLookAt(Vector(20, 20, 24))
	else
		image:SetLookAt(Vector(20, 20, 20))
	end
	image:SetFOV(fov || 10)
	if current_preview.name == "Model" then
		image:SetFOV(70)
		image:SetLookAt(Vector(20, 20, 42))
	end

	if selected_job.unlocks[current_preview.id] then
		local btn = vgui.Create("DButton", preview)
		btn:SetSize(image_bg:GetWide(), 40)
		btn:SetPos(15, preview:GetTall() - btn:GetTall() - 5)
		if selected_job.unlocks[current_preview.id] == 1 then
			btn:SetText("Un-equip")
		else
			btn:SetText("Equip")
		end
		btn.DoClick = function()
			RunConsoleCommand("joblevels_equip", selected_job.id, current_preview.id)
			if selected_job.unlocks[current_preview.id] == 1 then
				btn:SetText("Equip")
			else
				btn:SetText("Un-equip")
			end
		end

		image_bg:SetTall(btn.y - image_bg.y - 5)
	end
end

local function TableMatch(tbl1, tbl2)
	for k, v in pairs(tbl1) do
		for x, y in pairs(tbl2) do
			if k == x then
				return true
			end
		end
	end
end

local blue = Color(50, 50, 200, 40)
local count = 0
local function DrawTreePanel(pnl, tree_data, last_pos, branch_count, flip, disable_all)
	local total_tree_count = CountTrees(tree_data)
	local singles = #tree_data - total_tree_count
	local spacing = (pnl:GetWide() - (25 * total_tree_count)) / 3
	local tree_count = 0
	local first_pos = last_pos
	local line = vgui.Create("DPanel", pnl)
	line:SetSize(line_thickness, (singles + 1)*(button_h + 5) - (branch_count > 1 && 2.5 || button_h))
	line:SetPos(last_pos.x + button_w / 2 - line:GetWide() / 2, last_pos.y - (branch_count > 1 && 2.5 || -button_h))
	line:SetAlpha(0)
	table.insert(hidden, line)
	line.Paint = function(s, w, h)
		draw.RoundedBox(0, 0, 0, w, h, line_colour)
	end
	for k, v in SortedPairs(tree_data) do
		local unlock = JobLevels.UnlockIDToData[selected_job.id] && JobLevels.UnlockIDToData[selected_job.id][v.id]
		local previous_unlock = unlock.previous != 0 && JobLevels.UnlockIDToData[selected_job.id][unlock.previous]
		local is_opposed = previous_unlock && previous_unlock.opposing && TableMatch(selected_job.unlocks, previous_unlock.opposing)
		if is_opposed && !selected_job.unlocks[v.id] then
			disable_all = true
		end

		local x, y = last_pos.x, last_pos.y + button_h + 5
		if v.tree then
			if flip then
				x = tree_count == 0 && (first_pos.x) + ((button_w / 2) * branch_count) + 5 || last_pos.x - (button_w * tree_count) - (tree_count * 5)
			else
				x = tree_count == 0 && (first_pos.x + (2.5 * (tree_count + 1))) - ((button_w / 2) * branch_count) - 7.5 || last_pos.x + (button_w * tree_count) + (tree_count * 5)
			end
			y = tree_count == 0 && y || last_pos.y

			if tree_count == 0 then
				local line = vgui.Create("DPanel", pnl)
				line:SetSize(button_w + 5, line_thickness)
				line:SetAlpha(0)
				line.Paint = function(s, w, h)
					draw.RoundedBox(0, 0, 0, w, h, line_colour)
				end
				if flip then
					line:SetPos((x - 5) - button_w / 2, last_pos.y + button_h + 2.5)
				else
					line:SetPos(x + button_w / 2, last_pos.y + button_h + 2.5)
				end
				table.insert(hidden, line)
			end
			tree_count = tree_count + 1

			DrawTreePanel(pnl, v.tree, {x=x, y=y}, branch_count + 1, (branch_count + 1) >= 2 && tree_count == 2, disable_all)
		end

		local name = vgui.Create("DButton", pnl)
		name:SetSize(button_w, button_h)
		name:SetText(v.name)
		name:SetPos(x, y)
		name:SetAlpha(0)
		if disable_all then
			name.textColor = Color(100, 100, 100)
		end

		if selected_job.unlocks[v.id] then
			name.Style = function(self, w, h, col)
				DankUI.Element.MovingGradient(self, w, h, blue, -0.5, 0, false, true)
			end
		end
		name.DoClick = function(s)
			preview:SetPreview(v, s)
		end
		if count == 0 then
			preview:SetPreview(v, s)
		end
		count = count + 1
		table.insert(hidden, name)

		last_pos = {x=x, y=y}
	end
end

local function CountTotalVerticalTrees(trees)
	local count = 0
	for k, v in SortedPairs(trees) do 
		count = count + 1
		if v.tree then
			count = count + CountTotalVerticalTrees(v.tree)
			break
		end
	end
	return count
end

local function TreePanel(pnl, job_id)
	count = 0
	local total_tree_count = table.Count(JobLevels.Trees[job_id]) - 1
	local center_x = pnl:GetWide() / 2 - button_w / 2
	local total_height = CountTotalVerticalTrees(JobLevels.Trees[job_id]) * (button_h + 5)
	local x, y = center_x, (pnl:GetTall() / 2 - total_height / 2) - (button_h + 5)
	DrawTreePanel(pnl, JobLevels.Trees[job_id], {x=x, y=y}, 1)
	FadeIn()
end

local function ReadJobLevelData(id)
	return {minutes=net.ReadUInt(20), points=net.ReadUInt(7), level=net.ReadUInt(7), unlocks=net.ReadTable(), id=id}
end

local function Respec(fr)
	if !selected_job.id then return end
	local confirm = vgui.Create("dank_ui.confirm")
	confirm:SetQuestion("Are you sure you would like to refund all unlocks for\n£10M?")
	confirm.OnYes = function()
		RunConsoleCommand("joblevels_respec", selected_job.id)
		confirm:Remove()
		fr:Close()
	end
end

local wait = false

local function UI()
	local total_jobs = net.ReadUInt(3)
	local jobs = {}
	for i=1, total_jobs do
		local id = net.ReadString()
		jobs[id] = ReadJobLevelData(id)
	end
	local current_job_id = JobLevels.JobToID[LocalPlayer():Team()]
	selected_job = current_job_id && jobs[current_job_id] || table.GetFirstValue(jobs)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(ScrW() * 0.8, ScrH() * 0.8)
	fr:SetTitle(selected_job.points .. " Points          ")
	fr:Center()

	local respec = vgui.Create("DButton", fr)
	respec:SetSize(fr:GetWide() * 0.15, 30)
	respec:SetPos(fr.btnClose.x - respec:GetWide(), 0)
	respec:SetText("Respec (£10M)")
	respec.DoClick = function() Respec(fr) end

	local complete = vgui.Create("DButton", fr)
	complete:SetSize(fr:GetWide() * 0.15, 30)
	complete:SetPos(respec.x - complete:GetWide(), 0)
	local points_to_give = JobLevels.CountTree(JobLevels.Trees[selected_job.id])
	local cost = math.Round(points_to_give * 5)
	complete:SetText("Buy Tree ("..cost.." tokens)")
	complete.DoClick = function() 
		local confirm = vgui.Create("dank_ui.confirm")
		confirm:SetQuestion("Are you sure you would like to unlock this tree for\n"..cost.." tokens?")
		confirm.OnYes = function()
			RunConsoleCommand("joblevels_token_buy", selected_job.id)
			confirm:Remove()
			fr:Close()
		end
	end
	button_w, button_h = fr:GetWide() * 0.08, fr:GetTall() * 0.04

	local trees = vgui.Create("DPanel", fr)
	local num_of_buttons = 6
	local offset = 25
	trees:SetSize(offset + (button_w * num_of_buttons) + (num_of_buttons * spacing), fr:GetTall() * 0.75)
	trees:SetPos(0, 30)

	PreviewPanel(fr, trees, {}) // locally set in this file

	unlock = vgui.Create("DButton", fr)
	unlock:SetText("Unlock [1 point]")
	unlock:SetSize(preview:GetWide() - 20, 50)
	unlock.Style = function(self, w, h, col)
		DankUI.Element.MovingGradient(self, w, h, DankUI.CloudBlueFaint, 0.1, 0.5, false, true)
	end
	unlock.DoClick = function()
		if preview.Current && selected_job.id && !selected_job.unlocks[preview.Current.id] then
			preview.TreeButton.Style = function(self, w, h, col)
				DankUI.Element.MovingGradient(self, w, h, blue, -0.5, 0, false, true)
			end
			selected_job.points = selected_job.points - 1
			selected_job.unlocks[preview.Current.id] = true
			fr:SetTitle(selected_job.points .. " Points")
			net.Start("JobLevels.Buy")
				net.WriteString(selected_job.id)
				net.WriteString(preview.Current.id)
			net.SendToServer()
		end
	end
	
	local level_title = DankUI.CreateLabel(fr, "Level", "dank_ui.20")
	level_title:SetPos(10, fr:GetTall() - level_title:GetTall() - 10)

	local current = DankUI.CreateLabel(fr, "Current", "dank_ui.20")
	current:SetPos(level_title.x, level_title.y - level_title:GetTall() - 2.5)

	local minutes_progress = JobLevels.GetLevelProgress(selected_job.minutes, selected_job.level)
	local goal = JobLevels.GetMinutesToLevel(selected_job.level + 1)

	local level_bar = vgui.Create("DPanel", fr)
	level_bar:SetSize(trees:GetWide() - current:GetWide() - 30, 20)
	level_bar:SetPos(current.x + current:GetWide() + 10, current.y + (current:GetTall() / 2 - level_bar:GetTall() / 2))
	level_bar.Paint = function(s, w, h)
		draw.RoundedBox(8, 0, 0, w, h, Color(50, 50, 50, 220))
		draw.RoundedBox(8, 0, 0, w / (goal/minutes_progress), h, Color(50, 255, 50, 220))
	end

	local current_level = DankUI.CreateLabel(fr, selected_job.level, "dank_ui.medium")
	current_level:SetPos(level_bar.x, level_title.y + (level_title:GetTall() / 2 - current_level:GetTall() / 2))

	local progress = DankUI.CreateLabel(fr, minutes_progress .. "/" .. goal, "dank_ui.20")
	progress:SetPos(level_bar.x + level_bar:GetWide() - progress:GetWide(), current_level.y)

	local options = vgui.Create("DPanel", fr)
	options:SetSize(trees:GetWide(), 51)

	local count = 0
	local btn_w = ((options:GetWide() - 20) / total_jobs)
	local btns = {}
	for k, v in pairs(jobs) do
		local btn = vgui.Create("DButton", options)
		btn:SetSize(btn_w, options:GetTall() - 10)
		btn:SetPos(5 + (count * (5 +btn_w)), 5)
		btn:SetText(JobLevels.IDToName[v.id])
		btn.DoClick = function()
			if wait then return end
			selected_job = v
			local points_to_give = JobLevels.CountTree(JobLevels.Trees[selected_job.id])
			local cost = math.Round(points_to_give * 5)
			complete:SetText("Buy Tree ("..cost.." tokens)")
			fr:SetTitle(selected_job.points .. " Points")
			minutes_progress = JobLevels.GetLevelProgress(selected_job.minutes, selected_job.level)
			goal = JobLevels.GetMinutesToLevel(selected_job.level + 1)
			current_level:SetText(selected_job.level)
			current_level:SetPos(level_bar.x, level_title.y + (level_title:GetTall() / 2 - current_level:GetTall() / 2))
			progress:SetText(minutes_progress .. "/" .. goal)
			progress:SizeToContents()
			progress:SetPos(level_bar.x + level_bar:GetWide() - progress:GetWide(), current_level.y)
			wait = true
			for k, v in pairs(trees:GetChildren()) do
				if IsValid(v) then
					v:AlphaTo(0, 0.2, 0, function()
						v:Remove()
					end)
				end
			end
			for k, v in pairs(btns) do
				v.Style = nil
			end
			btn.Style = function(self, w, h, col)
				DankUI.Element.MovingGradient(self, w, h, DankUI.CloudBlueFaint, 0.25, 0.75, false, false, true, true)
			end
			timer.Simple(0.2, function()
				TreePanel(trees, selected_job.id)
				wait = false
			end)
		end
		if k == current_job_id || (!current_job_id && count == 0) then
			btn.Style = function(self, w, h, col)
				DankUI.Element.MovingGradient(self, w, h, DankUI.CloudBlueFaint, 0.25, 0.75, false, false, true, true)
			end
		end
		count = count + 1
		table.insert(btns, btn)
	end

	local h = (current.y - current:GetTall()) - 15
	preview:SetHeight(h)
	trees:SetHeight(h-50)
	options:SetPos(trees.x, trees.y + trees:GetTall() - 1)
	unlock:SetPos(preview.x + 10, current.y + current:GetTall() - unlock:GetTall() / 2)

	TreePanel(trees, selected_job.id)
end
net.Receive("JobLevels.UI", UI)

local pos = Vector(-2118.175049, 482.656586, 54.104881)
local pos2 = Vector(534.587036, 6619.021973, -155.741013)
net.Receive("JobLevels.Waypoint", function()
	if net.ReadBool() then
		Cloud.Waypoint.Create(pos2, "Terrorist Computer", 150)
	else
		Cloud.Waypoint.Create(pos, "CP Computer", 150)
	end
end)

local function ESP(job_id)
	hook.Add("HUDPaint", "CP.ESP", function()
		if !LocalPlayer():OutOfRP() then
			return
		end
		if !cvar:GetBool() then
			return
		end
		local job_id = JobLevels.JobToID[LocalPlayer():Team()]
		if (!job_id || job_id != "swat_medic") && team.GetName(LocalPlayer():Team()) != ".Ghost" then
			hook.Remove("HUDPaint", "CP.ESP")
		end
		for k, v in pairs(player_GetAll()) do	
			if v:isCP() && v != LocalPlayer() then
				Cloud.DrawESP(v, true, false, true)
			end
		end
	end)
end

local function HUDScope()
	LocalPlayer().HUDScope = true
	timer.Create("JobLevels.HUDScope", 0.5, 0, function()
		local job_id = JobLevels.JobToID[LocalPlayer():Team()]
		if !job_id || job_id != "swat" then
			LocalPlayer().HUDScope = false
			timer.Remove("JobLevels.HUDScope")
		end
	end)
end

local unlocks = {
	[0] = ESP,
	[1] = HUDScope
}

net.Receive("JobLevels.Activate", function()
	local unlock_id = net.ReadUInt(2)
	unlocks[unlock_id]()
end)