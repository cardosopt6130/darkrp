--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/jobs/sh_level.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

JobLevels = JobLevels || {Trees={}, JobToID={}, IDToName={}, UnlockIDToData={}, IDToNotifyID={}}

JobLevels.RespecCost = 10000000

local compound = 30

local function AddUnlocks(id, tree, previous_unlock_id)
	for k, v in ipairs(tree) do
		v.previous = previous_unlock_id || 0
		JobLevels.UnlockIDToData[id][v.id] = v
		if v.tree then
			AddUnlocks(id, v.tree, v.id)
			if !JobLevels.UnlockIDToData[id][previous_unlock_id].opposing then
				JobLevels.UnlockIDToData[id][previous_unlock_id].opposing = {}
			end
			JobLevels.UnlockIDToData[id][previous_unlock_id].opposing[v.id] = true
			continue
		end
		previous_unlock_id = v.id
	end
end

function JobLevels.Register(job_index, id, tree, name, notify_id)
	JobLevels.Trees[id] = tree
	JobLevels.JobToID[job_index] = id
	JobLevels.IDToName[id] = name
	JobLevels.UnlockIDToData[id] = {}	
	JobLevels.IDToNotifyID[id] = notify_id
	AddUnlocks(id, tree)
end

function JobLevels.AddJob(job_index, id)
	JobLevels.JobToID[job_index] = id
end

function JobLevels.RemoveJob(job_index)
	JobLevels.JobToID[job_index] = nil
end

local function TableMatch(tbl1, tbl2)
	for k, v in pairs(tbl1) do
		for x, y in pairs(tbl2) do
			if k == x then
				return true
			end
		end
	end
end

function JobLevels.CanUnlock(job_id, unlock_id, unlock, data)
	if Cloud.QAMode then return true end
	if !unlock then return false end
	local previous_unlock = unlock.previous != 0 && JobLevels.UnlockIDToData[job_id][unlock.previous]
	local is_opposed = previous_unlock && previous_unlock.opposing && TableMatch(data.unlocks, previous_unlock.opposing)
	local has_previous = unlock.previous == 0 || data.unlocks && data.unlocks[unlock.previous]
	return data && data.points && data.points >= 1 && !is_opposed && has_previous && !data.unlocks[unlock_id]
end

function JobLevels.JobExists(job)
	return JobLevels.Trees[job]
end

function JobLevels.TotalMinutesToLevel(level)
	local total = 0
	for i=0, level do
		total = total + (60 + (i * compound))
	end
	return total
end

function JobLevels.GetLevelProgress(total_minutes, current_level)
	local minutes_overlap = (total_minutes - JobLevels.TotalMinutesToLevel((current_level - 1)))
	return minutes_overlap 
end

function JobLevels.GetMinutesToLevel(level)
	return 60 + (level * compound)
end

function JobLevels.Armor(amount)
	return function(ply) ply:SetArmor(ply:Armor() + amount) end
end

function JobLevels.Speed(amount)
	return function(ply) ply:SetRunSpeed(ply:GetRunSpeed() + amount) end
end

local function CountPossibleOptions(tree)
	local count = 0
	for k, v in ipairs(tree) do
		if v.tree then 
			count = count + 1 
		end
	end
	return count
end

function JobLevels.CountTree(tree)
	local count = 0
	local options = CountPossibleOptions(tree)
	if options > 0 then
		for k, v in ipairs(tree) do
			if v.tree then
				count = count + k + JobLevels.CountTree(v.tree)
				break
			end
		end
	else
		count = count + #tree
	end
	return count
end