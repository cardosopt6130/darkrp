--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/f4/cl_f4.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

surface.CreateFont("f4.info", {
	font = "Roboto",
	size = 18,
	weight = 500
})

local LAST_PAGE = "Home"

local tabs = {}

function F4.ReloadTab(tab)
	if !tabs[tab] then return end
	local pnl, func = unpack(tabs[tab])
	if !IsValid(pnl) then return end
	pnl:Clear()
	func(pnl)
end

local function AddTab(menu, name, func)
    local panel = vgui.Create("DPanel", menu)
	panel:SetSkin("material_dark")
	menu:AddPage(name, panel)
    func(panel)
	tabs[name] = {panel, func}
end

local function InfoPanel(pnl, name, tbl, set_text)
	local lbl = DankUI.CreateLabel(pnl, name, "dank_ui.medium")
	lbl:SetPos(pnl:GetWide() / 2 - lbl:GetWide() / 2, 5)
	local pnl2 = vgui.Create("DPanel", pnl)
	pnl2:SetSize(pnl:GetWide() - 20, pnl:GetTall() - (lbl:GetTall() + lbl.y + 15))
	pnl2:SetPos(10, lbl.y + lbl:GetTall() + 5)
	local scroll = vgui.Create("dank_ui.scroll", pnl2)
	scroll:SetSize(pnl2:GetSize())
	scroll:SetPadding(-1)

	for k, v in SortedPairs(tbl) do
		local btn = vgui.Create("DButton", scroll)
		set_text(btn, k, v)
		btn:SetHeight(30)
		scroll:AddItem(btn)
	end
end

local money_making = {
	[1] = {name = "Crypto", difficulty=1, produce=1, desc="Three crypto stations to sell at. Legal. Just don't get mugged."},
	[2] = {name = "Moonshine", difficulty=1, produce=1, desc="Brew moonshine and instantly get money without leaving your base."},
	[3] = {name = "Printers", difficulty=2, produce=3, desc="Classic money printing. Just don't get raided..."},
	[4] = {name = "Meth", difficulty=2, produce=2, desc="One NPC to sell to. Sells instantly. You become wanted."},
	[5] = {name = "Weed", difficulty=4, produce=4, desc="Two NPCs to sell to. Takes time to sell weed and CP's are notified. Very risky but pays the best."},
	[6] = {name = "Locker", difficulty=4, produce=3, desc="As terrorist steal the CP locker and get it back to the terrorist HQ."},
	[7] = {name="Gold", difficulty=4, produce=2, desc="Rob the bank and sell gold to one NPC. CP's are notified."},
	[8] = {name = "Gambling", difficulty=4, produce=1, desc="Jackpot. Coin flips. Spins. The casino opposite spawn. Good luck."},
	[9] = {name = "Mining", difficulty=2, produce=3, desc="Mine underground and sell your ores. Watch out for mutants."},
	[10] = {name = "Trading", difficulty=2, produce=2, desc="Trade weapons or in game items for money. You can start doing this as gun dealer."},
	[11] = {name = "Raiding", difficulty=4, produce=2, desc="Raid a base, and take their printer was your own."},
}

local num_to_color = {
	[1] = Color(50, 200, 50, 100),
	[2] = Color(200, 100, 0, 100),
	[3] = Color(200, 0, 0, 100),
	[4] = Color(255, 0, 0, 100),
}

local num_to_color2 = {
	[4] = Color(50, 200, 50, 100),
	[3] = Color(200, 100, 0, 100),
	[2] = Color(200, 0, 0, 100),
	[1] = Color(255, 0, 0, 100),
}

local bg_col = Color(30, 30, 30)

local function DrawLaws(pnll)
	local pnl = vgui.Create("DPanel", pnll)
	pnl:SetSize(pnll:GetWide() * 0.7, pnll:GetTall() * 0.5)
	InfoPanel(pnl, "Laws Of Downtown", DarkRP.getLaws(), function(btn, k, v )
		btn:SetText(k .. ") " .. v)
	end)
	pnl = vgui.Create("DPanel", pnll)
	pnl:SetSize(pnll:GetWide() * 0.3 + 2, pnll:GetTall() * 0.5)
	pnl:SetPos(pnll:GetWide() * 0.7 - 1, 0)
	InfoPanel(pnl, "Prices", Prices.GetAllCurrent(), function(btn, k, v )
		btn:SetText(k .. ": " .. DarkRP.formatMoney(v))
	end)

	pnl = vgui.Create("DPanel", pnll)
	pnl:SetSize(pnll:GetWide(), pnll:GetTall() * 0.5 + 1)
	pnl:SetPos(0, pnll:GetTall() * 0.5 - 1)
	local lbl = DankUI.CreateLabel(pnl, "Money Making", "dank_ui.medium")
	lbl:SetPos(pnl:GetWide() / 2 - lbl:GetWide() / 2, 5)
	local pnl2 = vgui.Create("DPanel", pnl)
	pnl2:SetSize(pnl:GetWide() - 20, pnl:GetTall() - (lbl:GetTall() + lbl.y + 15))
	pnl2:SetPos(10, lbl.y + lbl:GetTall() + 5)
	local scroll = vgui.Create("dank_ui.scroll", pnl2)
	scroll:SetSize(pnl2:GetSize())
	scroll:SetPadding(-1)

	local lbl2 = DankUI.CreateLabel(pnl, "Difficulty", "dank_ui.small")
	lbl2:SetPos(pnl2.x + 5, pnl2.y - lbl2:GetTall())

	local lbl3 = DankUI.CreateLabel(pnl, "Return", "dank_ui.small")
	lbl3:SetPos(pnl2.x + scroll:GetWide() * 0.1 + 10, lbl2.y)

	for k, v in SortedPairsByMemberValue(money_making, "difficulty") do
		local bg = vgui.Create("DPanel", scroll)
		bg:SetSize(scroll:GetWide(), 30)
		local bar = vgui.Create("DPanel", bg)
		bar:SetSize(bg:GetWide() * 0.1, 20)
		bar:SetPos(5, 5)
		bar.Paint = function(s, w, h)
			draw.RoundedBox(8, 0, 0, w, h, bg_col)
			draw.RoundedBox(8, 0, 0, (w/4)*v.difficulty, h, num_to_color[v.difficulty])
		end
		local bar2 = vgui.Create("DPanel", bg)
		bar2:SetSize(bar:GetSize())
		bar2:SetPos(bar.x + bar:GetWide() + 5, bar.y)
		bar2.Paint = function(s, w, h)
			draw.RoundedBox(8, 0, 0, w, h, bg_col)
			draw.RoundedBox(8, 0, 0, (w/4)*v.produce, h, num_to_color2[v.produce])
		end
		local lbl = DankUI.CreateLabel(bg, v.name .. " | " .. v.desc, "dank_ui.small")
		lbl:SetPos(bar2.x + bar2:GetWide() + 5, 5)
		scroll:AddItem(bg)
	end
end

function GM:ShowSpare2()
	local w, h = math.Clamp(ScrW() * 0.7, 720, 3000), math.Clamp(ScrH() * 0.9, 500, 3000)
	local menu = vgui.Create("dank_ui.top_menu")
	menu:SetTitle("Main Menu")
	menu:SetSize(w, h)
	menu:Center()
	menu:SetLastPage(LAST_PAGE)
	menu.OnNewPage = function(self, title)
		LAST_PAGE = title
	end
	menu.OnKeyCodePressed = function(self, key)
		if key == KEY_F4 then
			menu:Close()
		end
	end

	AddTab(menu, "Home", F4.CreateHomePage)
	AddTab(menu, "Jobs", F4.CreateJobsPage)
	AddTab(menu, "Entities", F4.CreateEntitiesPage)
	AddTab(menu, "Info", DrawLaws)
	menu:AddButton("Store", function() menu:Close() Tokens.CreateMenu() end, true)
	menu:AddButton("Skills", function() menu:Close() RunConsoleCommand("say", "!skills") end)
end