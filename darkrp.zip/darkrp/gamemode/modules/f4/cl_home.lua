--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/f4/cl_home.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function data_command(title, question, cmd)
	local entry = vgui.Create("dank_ui.entry")
	entry:SetQuestion(question)
	entry.OnYes = function(s, value)
		LocalPlayer():ConCommand(cmd .. " " .. value)
	end
end

local general_cmds = {
	["Gangs"] = function(f4) f4:Close() LocalPlayer():ConCommand("say /gang") end,
	["Rules"] = function() LocalPlayer():ConCommand("say !motd") end,
	["Store"] = function(f4) f4:Close() Tokens.CreateMenu() end, 
	["Accessory Adjustments"] = function(f4) RunConsoleCommand("_adj") end, 
	["Weapon Slots"] = function(f4) f4:Close() RunConsoleCommand("weapon_slots") end, 
	["Clear Waypoints"] = function(f4) RunConsoleCommand("clear_waypoints") end, 
	["Steam"] = function() RunConsoleCommand("say", "!steam") end, 
	["Jobs"] = function(f4) f4:Close() Jobs.OpenMenu() end, 
	["Help"] = function() gui.OpenURL("https://cloud-gaming.co.uk/forum/index.php?/topic/15584-help/") end
}

local roleplay_cmds = {
	["Drop Money"] = function() data_command("Drop Money", "How much would you like to drop?", "say /dropmoney") end,
	["Give Money"] = function() data_command("Give Money", "How much would you like to give?", "say /give") end,
	["Sell All Doors"] = function() LocalPlayer():ConCommand("say /sellalldoors") end,
	["Remove Small Ents"] = function() LocalPlayer():ConCommand("say /removesmallents") end,
	["Change Name"] = function() data_command("Change Name", "What name you would like?", "say /rpname") end,
	["Change Job Title"] = function() data_command("Change Job", "What title you would like?", "say /job") end,
	["Request License"] = function() LocalPlayer():ConCommand("say /requestlicense") end,
}

local police_cmds = {
	["Warrant"] = function() 
		local menu = DermaMenu()
		for _, ply in pairs(player.GetAll()) do
			if not ply:getDarkRPVar("warrant") and ply ~= LocalPlayer() then
				menu:AddOption(ply:Nick(), function()
					data_command("Warrant", "Why would you warrant " .. ply:Nick().. "?", "say /warrant " .. ply:SteamID())
				end)
			end
        end
		menu:Open()
	end,
	["Want"] = function() 
		local menu = DermaMenu()
		for _, ply in pairs(player.GetAll()) do
			if not ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
				menu:AddOption(ply:Nick(), function()
					data_command("Wanted", "Why would you want " .. ply:Nick().. "?", "say /wanted " .. ply:SteamID())
				end)
			end
        end
		menu:Open()
	end,
	["Unwant"] = function()
		local menu = DermaMenu()
		for _,ply in pairs(player.GetAll()) do
			if ply:getDarkRPVar("wanted") and ply ~= LocalPlayer() then
				menu:AddOption(ply:Nick(), function() LocalPlayer():ConCommand("say /unwanted " .. ply:SteamID()) end)
			end
		end
		menu:Open()
	end,
}

local mayor_cmds = {
	["Lockdown"] = function() LocalPlayer():ConCommand("say /lockdown") end,
	["Stop lockdown"] = function() LocalPlayer():ConCommand("say /unlockdown") end,
	["Give license"] = function() LocalPlayer():ConCommand("say /givelicense") end,
	["Place laws"] = function() LocalPlayer():ConCommand("say /placelaws") end,
	["Start lottery"] = function() data_command("Start a lottery", "How much? (1000-5000)", "say /lottery") end,
	["Broadcast"] = function() data_command("Broadcast", "What would you like to say?", "say /broadcast") end,
	["Add law"] = function() data_command("Add a law", "Type the law you would to add.", "say /addlaw") end,
	["Remove law"] = function() data_command("Remove a law", "Enter the number of the law you would like to remove here.", "say /removelaw") end,
	["Set toll fee"] = function() data_command("Set toll price", "Enter the new toll fee (100-500).", "say /settoll") end
}

local hitman_cmds = {
	["Set hit price"] = function() data_command("Set hit price", "How much? (£10,000-£150,000)", "say /hitprice") end
}

local gambling_cmds = {
	["Jackpot"] = function() RunConsoleCommand("say", "!jackpot") end,
	["Spins"] = function() RunConsoleCommand("say", "!spins") end,
	["Flips"] = function() RunConsoleCommand("say", "!flips") end
}

local function CreateDivider(scroll, name, draw_divider)
    local divider = vgui.Create("DLabel", scroll)
    divider:SetText(name)
    divider:SetSize(scroll:GetWide(), 32)
    divider:SetFont("tokens_button2")
    divider:SetContentAlignment(5)
	if draw_divider then
		local d = vgui.Create("dank_ui.divider", scroll)
		scroll:AddItem(d)
	end
	scroll:AddItem(divider)

	return divider
end

local function CreateCommands(scroll, commands, f4)
    for k, v in pairs(commands) do
        local button = vgui.Create("DButton", scroll)
        button:SetSize(scroll:GetWide(), 30)
        button:SetText(k)
        button:DockMargin(0, 0, 0, -1)
        button.DoClick = function() v(f4) end
	scroll:AddItem(button)
    end
end

local catagories = {
	["Settings"] = {
		["Third person"] = "cg_thirdperson",
		["Enable media players"] = "whk_mediaenabled",
		["Enable custom crosshair"] = "cg_crosshair",
		["Enable officer down HUD"] = "cg_officer_down",
		["Enable waypoints"] = "cg_waypoints",
	},
	["FPS Options"] = {
		["Gang ESP (must be level 13+)"] = "cg_gang_esp",
		["CP ESP (unlocked via computer)"] = "cg_cp_esp",
		["Skybox"] = "r_3dsky",
		["Draw monitors"] = "cl_drawmonitors",
		["Shadows"] = "r_shadows",
		["Printer Boost AOE"] = "printer_boost_aoe",
		["Shotgun Shells"] = "cl_ejectbrass",
		["Multi Core (experimental)"] = "gmod_mcore_test",
	},
	["Chat"] = {
		["Show OOC"] = "cg_chat_ooc",
		["Show Laws"] = "cg_chat_laws",
		["Show Money"] = "cg_chat_money",
		["Show Wanted"] = "cg_chat_wanted",
		["Show Flips"] = "cg_chat_flips",
		["Show Connections"] = "cg_chat_connections",
		["Show Staff"] = "cg_chat_staff_ofd",
		["Use Steam Filter"] = "cg_chat_steam_filter",
	},
}

local function AddSettings(scroll)
	local count = 0
	for categoryName, settings in pairs(catagories) do
    	CreateDivider(scroll, categoryName, count != 0)
		count = count + 1
		for name, setting in pairs(settings) do
			local checkBox = vgui.Create("DCheckBoxLabel", scroll)
			checkBox:SetText(name)
			checkBox:SetConVar(setting)
			scroll:AddItem(checkBox)
		end
	end
end

local wsettings = {
	["Scoped Sensitivity"] = "cg_scoped_sensitivity_multiplyer",
	["Weapon Bob"] = "cg_weapon_bob",
	["Weapon Sway"] = "cg_weapon_sway",
}

local function AddWeaponSettings(scroll)
	local bw = scroll:GetWide() / 2

	for k, v in pairs(wsettings) do
		local colour = vgui.Create("DButton", scroll)
		colour:SetSize(bw, 30)
		colour:SetText(k)
		colour.noHighlight = true
		colour.DoClick = function()
			data_command(k, "Input a number", v)
		end
		scroll:AddItem(colour)
	end

	local reset = vgui.Create("DButton", scroll)
	reset:SetSize(200, 30)
	reset:SetText("Reset")
	reset.noHighlight = true
	reset.DoClick = function()
		RunConsoleCommand("cg_scoped_sensitivity_multiplyer", 1)
		RunConsoleCommand("cg_weapon_bob", 0.75)
		RunConsoleCommand("cg_weapon_sway", 0.75)
	end
	scroll:AddItem(reset)
end

local function AddCrosshairSettings(scroll)
	local bw = scroll:GetWide() / 2

	local colour = vgui.Create("DButton", scroll)
	colour:SetSize(bw, 30)
	colour:SetText("Colour")
	colour.noHighlight = true
	colour.DoClick = function()
		local colours = DermaMenu()
		colours:AddOption("Red", function() RunConsoleCommand("cg_crosshair_color", "red") end)
		colours:AddOption("Green", function() RunConsoleCommand("cg_crosshair_color", "green") end)
		colours:AddOption("Purple", function() RunConsoleCommand("cg_crosshair_color", "purple") end)
		colours:AddOption("Blue", function() RunConsoleCommand("cg_crosshair_color", "blue") end)
		colours:AddOption("Orange", function() RunConsoleCommand("cg_crosshair_color", "orange") end)
		colours:AddOption("Pink", function() RunConsoleCommand("cg_crosshair_color", "pink") end)
		colours:AddOption("Light blue", function() RunConsoleCommand("cg_crosshair_color", "lblue") end)
		colours:Open()
	end
	scroll:AddItem(colour)

	local size = vgui.Create("DButton", scroll)
	size:SetSize(bw, 30)
	size:SetText("Size")
	size.noHighlight = true
	size.DoClick = function()
		data_command("Crosshair Size", "What size would you like?", "cg_crosshair_size")
	end
	scroll:AddItem(size)

	local gap = vgui.Create("DButton", scroll)
	gap:SetSize(bw, 30)
	gap:SetText("Gap")
	gap.noHighlight = true
	gap.DoClick = function()
		data_command("Crosshair Gap", "What gap size would you like?", "cg_crosshair_gap")
	end
	scroll:AddItem(gap)

	local thickness = vgui.Create("DButton", scroll)
	thickness:SetSize(bw, 30)
	thickness:SetText("Thickness")
	thickness.noHighlight = true
	thickness.DoClick = function()
		data_command("Crosshair Thickness", "What thickness size would you like?", "cg_crosshair_thickness")
	end
	scroll:AddItem(thickness)

	local reset = vgui.Create("DButton", scroll)
	reset:SetSize(200, 30)
	reset:SetText("Reset")
	reset.noHighlight = true
	reset.DoClick = function()
		RunConsoleCommand("cg_crosshair_gap", 9)
		RunConsoleCommand("cg_crosshair_size", 5)
		RunConsoleCommand("cg_crosshair_thickness", 2)
		RunConsoleCommand("cg_crosshair_color", "red")
	end
	scroll:AddItem(reset)
end

function F4.CreateHomePage(panel)
    local scroll = vgui.Create("dank_ui.scroll", panel)
    scroll:SetSize(panel:GetWide() * 0.75 - 20, panel:GetTall() - 20)
	scroll:SetPos(10, 10)
	scroll:SetPadding(-1)
	scroll.Paint = function(s, w, h)
		DankUI.DrawOutlinedBox(0, 0, w, h, DankUI.Panel, DankUI.Outline)
	end
    CreateDivider(scroll, "General")
    CreateCommands(scroll, general_cmds, panel:GetParent())
    CreateDivider(scroll, "Roleplay")
    CreateCommands(scroll, roleplay_cmds)
	CreateDivider(scroll, "Gambling")
	CreateCommands(scroll, gambling_cmds)
    if LocalPlayer():isCP() then
        CreateDivider(scroll, "Civil Protection")
        CreateCommands(scroll, police_cmds)
    end
	if LocalPlayer():Team() == TEAM_MAYOR then
        CreateDivider(scroll, "Mayor")
        CreateCommands(scroll, mayor_cmds)
    end

	if LocalPlayer():isHitman() then
        CreateDivider(scroll, "Hitman")
        CreateCommands(scroll, hitman_cmds)
    end

    local scroll2 = vgui.Create("dank_ui.scroll", panel)
    scroll2:SetSize(panel:GetWide() - scroll:GetWide() - 30, panel:GetTall() - 20)
	scroll2:SetPos(scroll.x + scroll:GetWide() + 10, 10)
	scroll2:SetPadding(5)
	scroll2.Paint = function(s, w, h)
		DankUI.DrawOutlinedBox(0, 0, w, h, DankUI.Panel, DankUI.Outline)
	end
	AddSettings(scroll2)
	CreateDivider(scroll2, "Weapon", true)
	AddWeaponSettings(scroll2)
	CreateDivider(scroll2, "Crosshair", true)
	AddCrosshairSettings(scroll2)
end