--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/f4/cl_jobs.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function AddJobs(scroll, catagories, preview, info)
	for categoryName, jobs in pairs(catagories) do
		local category = vgui.Create("DCollapsibleCategory", scroll)
		category:SetSize(scroll:GetWide(), 200)
		category:Dock(TOP)
		category:SetLabel(categoryName)
		category:SetHeaderHeight(30)
		scroll:AddItem(category)

		local jobList = vgui.Create("DIconLayout", category)
		jobList.Paint = function() end
		for k, v in pairs(jobs) do
			if categoryName == "Custom" and v.customCheck and !v.customCheck(LocalPlayer()) then continue end
			local mdl = v.model[1] == "m" and v.model or v.model[1]
			if LocalPlayer():GetJobName() == v.name then
				preview.Player:SetModel(mdl)
				preview:NewIdlePose()
				info.UpdateJob(v)
			end
			local job = jobList:Add("DPanel")
			job:SetSize(category:GetWide(), 50)
			job:SetCursor( "hand" )
			job.OnMousePressed = function()
				LocalPlayer():ConCommand("say /" .. v.command)
				timer.Simple(0.25, function()
					F4.ReloadTab("Entities")
					F4.ReloadTab("Home")
				end)
			end

			job.Style = function(self, w, h, col, t)
				draw.RoundedBox(0, 0, 0, w, h, Color(v.color.r, v.color.g, v.color.b, 100))
				draw.RoundedBox(0, 0, 0, w, h, Color(v.color.r, v.color.g, v.color.b, col.a + 50))
				surface.SetDrawColor(DankUI.Outline)
				surface.DrawLine(0, h-1, w, h-1)
			end

			job.OnCursorEntered = function()
				preview.Player:SetModel(mdl)
				preview:NewIdlePose()
				info.UpdateJob(v)
			end

			local iconPanel = vgui.Create("DPanel", job)
			iconPanel:SetSize(50, 50)
			iconPanel:SetPos(0, (job:GetTall() / 2) - iconPanel:GetTall() / 2)
			iconPanel.Paint = function(self, w, h)
				draw.Gradient(self, scroll, w - 2, h - 2, v.color, 0.2, "top",Color(50, 50, 50, 220) , 1, 1)
				surface.SetDrawColor(DankUI.Outline)
				surface.DrawLine(w - 1, 0, w - 1, h)
			end
			local icon = vgui.Create("SpawnIcon", iconPanel)
			icon:SetSize(50, 50)
			icon:SetPos(0, 0)
			icon:SetModel(mdl)
			icon:SetMouseInputEnabled(false)

			local jobName = vgui.Create("DLabel", job)
			jobName:SetText(v.name)
			jobName:SetFont("dank_ui.small")
			jobName:SizeToContents()
			jobName:SetWide(jobName:GetWide() + 1)

			local max = vgui.Create("DLabel", job)
			max:SetText(team.NumPlayers( v.team ).."/"..v.max)
			max:SetFont("dank_ui.small")
			max:SizeToContents()
			max:SetWide(max:GetWide() + 1)

			jobName:SetPos(icon:GetWide() + 5, (job:GetTall() / 2) - (jobName:GetTall() / 2) - (max:GetTall() / 2))
			max:SetPos(jobName.x, jobName:GetTall() + jobName.y)

			jobList:Add(job)
		end
		category:SetContents(jobList)
	end
end

function F4.CreateJobsPage(panel)
	local catagories = {}
	for k, v in pairs(RPExtraTeams) do
		if !catagories[v.category] then
			catagories[v.category] = {}
		end
		table.insert(catagories[v.category], v)
	end
	local scroll = vgui.Create("dank_ui.scroll", panel)
	scroll:SetSize(panel:GetWide() * 0.4, panel:GetTall())

	local info = vgui.Create("DPanel", panel)
	info:SetSize(panel:GetWide() * 0.6, panel:GetTall() * 0.25)
	info:SetPos(scroll.x + scroll:GetWide(), 0)
	info:SetSkin("material_dark")
	info.m_bBackground = false
	info.job = {}

	local title = vgui.Create("DPanel", info)
	title:SetSize(info:GetWide(), info:GetTall() * 0.25)
	title.Paint = function(s, w, h)
		surface.SetDrawColor(info.job.color or Color(200, 50, 50))
		surface.DrawRect(0, 0, w, h)
		draw.SimpleTextOutlined(info.job.name, "dank_ui.small", w / 2, info:GetTall() * 0.25 / 2, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
	end

	local info_scroll = vgui.Create("dank_ui.scroll", info)
	info_scroll:SetSize(info:GetWide(), info:GetTall() - title:GetTall() + 5)
	info_scroll:SetPos(0, title.y + title:GetTall())
	info_scroll:SetPadding(-1)

	info.UpdateJob = function(job)
		info.job = job
		info_scroll:Reset()
		local pnl = vgui.Create("DPanel", info_scroll)
		pnl:SetHeight(info_scroll:GetTall() * 0.25)
		info_scroll:AddItem(pnl)
		local public = (job.name == "Sniper" or job.name == "Fatman Joe")
		local lbl = DankUI.CreateLabel(pnl, job.description, (job.category == "Custom" and !public) and "DermaDefault" or "dank_ui.small")
		lbl:Center()
		if istable(info.job.permissions) then
			local height = info_scroll:GetTall() * 0.25
			for k, v in pairs(job.permissions) do
				local pnl = vgui.Create("DPanel", info_scroll)
				pnl:SetHeight(height)
				info_scroll:AddItem(pnl)
				local lbl = DankUI.CreateLabel(pnl, k .. ": " .. (isbool(v) and (v and "Yes" or "No") or v), "dank_ui.small")
				lbl:Center()
			end
		end
	end
	
	local preview = vgui.Create("tokens_playerpreview", panel)
	preview:SetSize(panel:GetWide() * 0.6, panel:GetTall() * 0.75)
	preview:SetPos(info.x, info.y + info:GetTall())
	preview:SetZ(36)
	preview.Player:SetFOV(35)
	local hat, mask = LocalPlayer():GetHat(), LocalPlayer():GetMask()
	if hat then 
		hat = Tokens.Accessories.Get(hat)
		preview:UpdateItems(hat)
	end

	if mask then
		mask = Tokens.Accessories.Get(mask)
		preview:UpdateItems(mask)
	end

	AddJobs(scroll, catagories, preview, info)
end