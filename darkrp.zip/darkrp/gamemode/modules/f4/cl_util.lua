--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/f4/cl_util.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function IsAllowed(allowed)
	for k, v in ipairs(allowed) do
		if v == LocalPlayer():Team() then return true end
	end
	return false
end

local grey = Color(30, 30, 30, 200)
local red = Color(200, 50, 50, 220)
local grey2 = Color(50, 50, 50, 220)

function F4.AddEntitiesTo(panel, catagories, command)
	local count = 0
	for categoryName, entities in pairs(catagories) do
		for k, v in pairs(entities) do
			if v.allowed and !IsAllowed(v.allowed) then continue end
			if v.hide then continue end
			if v.customCheckOnUI && !v.customCheck(LocalPlayer()) then continue end
			count = count + 1
		end
	end
	local cat_list = vgui.Create("dank_ui.categorylist", panel)
	cat_list:SetSize(panel:GetSize())
	for categoryName, entities in SortedPairs(catagories) do
		local category = cat_list:Add(categoryName)
		category:SetSize(panel:GetWide(), 200)
		category:SetHeaderHeight(30)

		local entityList = vgui.Create("DIconLayout", category)
		entityList:SetSpaceX(-1)
		entityList:SetSpaceY(-1)
		local count = 0
		for k, v in pairs(entities) do
			if v.allowed and !IsAllowed(v.allowed) then continue end
			if v.hide then continue end
			if v.customCheckOnUI && !v.customCheck(LocalPlayer()) then continue end
			count = count + 1
			local entity = vgui.Create("DPanel", entityList)
			entity:SetSize(category:GetWide()  / 3, 64)
			entity:SetCursor( "hand" )
			entity.FadeColor = table.Copy(DankUI.CloudBlue)
			entity.FadeColor.a = 0
			entity.FadeMax = 100
			entity.Style = function(self, w, h, col, t)
				draw.BottomGradient(self, category, w, h, col)
			end
			local entType = v.cmd != nil and "entity" or "weapon"
			entity.OnMousePressed = function()
				if v.ammoType != nil then
					LocalPlayer():ConCommand("say /buyammo " .. v.ammoType)
				elseif v.cmd != nil then
					LocalPlayer():ConCommand("say /" .. v.cmd)
				elseif categoryName == "Shipments" then
					LocalPlayer():ConCommand("say /buyshipment " .. v.name)
				else
					LocalPlayer():ConCommand("say /buy ".. v.name)
				end
			end
			local iconPanel = vgui.Create("DPanel", entity)
			iconPanel:SetSize(64, 64)
			iconPanel:SetPos(0, (entity:GetTall() / 2) - iconPanel:GetTall() / 2)
			iconPanel.Paint = function(self, w, h)
				if v.hot then
					draw.Gradient(self, panel, w - 2, h - 2, grey, 0.2, "top", red, 1, 1)
				else
					draw.Gradient(self, panel, w - 2, h - 2, grey, 0.2, "top",grey2 , 1, 1)
				end
				surface.SetDrawColor(DankUI.Outline)
				surface.DrawLine(w - 1, 0, w - 1, h)
			end
			local icon = vgui.Create("SpawnIcon", iconPanel)
			icon:SetSize(64, 64)
			icon:SetModel(v.model)
			icon:SetMouseInputEnabled(false)

			local entName = vgui.Create("DLabel", entity)
			if categoryName == "Shipments" then
				entName:SetText(v.name .. " Shipment")
			else
				entName:SetText(v.name)
			end
			entName:SetFont("dank_ui.small")
			entName:SizeToContents()
			entName:SetWide(entName:GetWide() + 1)

			local price = vgui.Create("DLabel", entity)
			local cost = categoryName == "Weapons" and v.pricesep or v.price
			local discountPercent = hook.Run("DarkRP.PriceDiscount", LocalPlayer(), v, entType)
	    	if discountPercent then
        		cost = math.Round(cost - (cost * discountPercent))
			end
			price:SetText(DarkRP.formatMoney(cost))
			price:SetFont("dank_ui.small")
			price:SizeToContents()
			price:SetWide(price:GetWide() + 1)

			entName:SetPos(icon:GetWide() + 5, (entity:GetTall() / 2) - (entName:GetTall() / 2) - (price:GetTall() / 2))
			price:SetPos(entName.x, entName:GetTall() + entName.y)

			entityList:Add(entity)
		end
		if count == 0 then 
			category:Remove()
		else
			category:SetContents(entityList)
		end
	end
end