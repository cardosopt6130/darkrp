--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/turfs/sh_item.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Inventory.RegisterItem({
	Name = "Start Turf",
	Description = "Starts a turf war on your location (must be a valid turf spot).",
	Class = "start_turf",
	Model = "models/props_lab/bewaredog.mdl",
	Stackable = false,
	Entity = "start_turf", 
	Tag = "turf",
	Rarity = Loot.EPIC,
	BlockDrop = true,
	CanUse = function(self, ply)
		if Turfs.HasActive() then return false end
		local zone = Gangs.GetTurfZone(ply)
		return zone 
	end,
	Base = "base_commodity",
	Use = function(self, ply)  
		local zone = Gangs.GetTurfZone(ply)
		Gangs.Turfs.StartBattle(zone)
	end,
	ShouldSave = true 
})

Crafting.RegisterRecipe("start_turf", {
    ["junk"] = 20,
    ["plastic"] = 20,
    ["gold"] = 2,
    ["gold_ore"] = 10,
    ["marlin_fish"] = 1,
    ["mythril_ore"] = 10,
    ["emerald_ore"] = 10,
    ["platinum_ore"] = 15,
    ["arapaima_fish"] = 1,
}, "Start Turf War", "Starts a turf war on your location (must be a valid turf spot).", "start_turf", "start_turf", "models/props_lab/bewaredog.mdl", "Misc")