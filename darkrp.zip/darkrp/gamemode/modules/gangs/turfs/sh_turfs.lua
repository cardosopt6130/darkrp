--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/turfs/sh_turfs.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Gangs.Turfs = Gangs.Turfs or {}

Gangs.Turfs.Spots = {
    ["residential"] = true,
    ["farm"] = true,
    ["beach"] = true,
    ["industrial"] = true
}

function Gangs.GetTurfZone(ply)
	for k, v in pairs(Gangs.Turfs.Spots) do
		if Cloud.Zone.InMapArea(ply, k) then
			return k
		end
	end
end

timer.Simple(1, function()
	Turfs.Register("gang", function(ply) return ply:GetGang() end, function(gang) return Gangs.GetColor(gang) end, SERVER && Gangs.Turfs.Start, SERVER && Gangs.Turfs.End, 2, Color(160, 0, 0, 50))
end)