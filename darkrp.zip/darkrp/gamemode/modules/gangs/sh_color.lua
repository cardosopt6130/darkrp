--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_color.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local gang_colors = {}

function Gangs.GetColor(gang)
	local gang_id = Gangs.Cache.IDFromName(gang)
    return gang_colors[gang_id] or Color(255, 255, 255, 255)
end

function Gangs.StringToColor(str)
    local x = string.Explode(",", str)
    return Color(x[1], x[2], x[3])
end

function Gangs.ColorToString(color)
    return color.r .. "," .. color.g .. "," .. color.b
end

if CLIENT then
    net.Receive("Gangs.Color", function()
        local col = net.ReadColor()
        col.a = 255
        gang_colors[net.ReadUInt(13)] = col
    end)

    net.Receive("Gangs.AllColors", function()
        gang_colors = net.ReadTable()
        for k, v in pairs(gang_colors) do
            v.a = 255
        end
    end)
end

    concommand.Add("_gc", function(ply)
		if ply:IsSuperAdmin() then
			for k, v in pairs(Gangs.Cache.GetNames()) do
				print(k .. ": " .. v)
			end
			for k, v in pairs(gang_colors) do
				print("Gang name: " .. (Gangs.Cache.GetName(k) or "NIL"))
				print(k .. ": " .. Gangs.ColorToString(v))
			end
		end
    end)

if SERVER then
    function Gangs.ColorIsSynced(gang_id)
        return gang_colors[gang_id] != nil
    end

    util.AddNetworkString("Gangs.Color")
    function Gangs.SyncColor(gang_id, color)
        gang_colors[gang_id] = color

        net.Start("Gangs.Color")
            net.WriteColor(color)
            net.WriteUInt(gang_id, 13)
        net.Broadcast()
    end

    util.AddNetworkString("Gangs.AllColors")
    function Gangs.SyncAllColors(ply)
        net.Start("Gangs.AllColors")
            net.WriteTable(gang_colors)
        net.Send(ply)
    end
end