--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_leaderboard.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local info = {
	[0] = "Activity",
	[1] = "Monthly",
	[2] = "Placing",
	[3] = "Players"
}

local function ActivityStats(activity)
	local frame = vgui.Create("dank_ui.frame")
	frame:SetSize(600, 400)
	frame:Center()
	frame:SetTitle("Stats")
	local scroll = vgui.Create("dank_ui.scroll", frame)
	scroll:SetSize(frame:GetWide() - 20, frame:GetTall() - 30)
	scroll:SetPadding(-1)
	scroll:SetPos(10, 40)
	Leaderboard.GetData("gang_member_data", function(data)
		for ply, count in pairs(data[activity]) do
			local row = vgui.Create("DPanel", scroll)
			scroll:AddItem(row)
			row:SetSize(scroll:GetWide(), 50)
			row:SetPos(0, 0)

			local name = DankUI.CreateLabel(row, ply, "dank_ui.20")
			name:SetPos(5, row:GetTall() / 2 - name:GetTall() / 2)

			local count = DankUI.CreateLabel(row, count, "dank_ui.20")
			count:SetPos(row:GetWide() - count:GetWide() - 5, row:GetTall() / 2 - count:GetTall() / 2)
		end
	end)
end

local function DrawUI(gang, panel, data)
	local title = DankUI.CreateLabel(panel, "Your Stats. Updates Every 5 Minutes.", "dank_ui.medium")
	title:SetPos(10, 7.5)

	local web = vgui.Create("DButton", panel)
	web:SetSize(panel:GetWide() * 0.3, title:GetTall())
	web:SetPos(panel:GetWide() - web:GetWide() - 10, 7.5)
	web:SetText("View Other Gangs")
	web.DoClick = function()
		gui.OpenURL("https://cloud-gaming.co.uk/darkrp/leaderboard_gangs.php")
	end

    local scroll = vgui.Create("dank_ui.scroll", panel)
    scroll:SetSize(panel:GetWide() - 20, panel:GetTall() - 30)
	scroll:SetPadding(-1)
    scroll:SetPos(10, title.y + title:GetTall() + 5)

	local row = vgui.Create("DPanel", scroll)
	scroll:AddItem(row)
	row:SetSize(scroll:GetWide(), 50)
	row:SetPos(0, 0)
	for i=0, 3 do
		local box = vgui.Create("DPanel", row)
		box:SetPos(i * row:GetWide() * 0.25, 0)
		box:SetSize(row:GetWide() * 0.25, row:GetTall())

		local credits = DankUI.CreateLabel(box, info[i], "dank_ui.medium")
		credits:SetPos(box:GetWide() / 2 - credits:GetWide() / 2, box:GetTall() / 2 - credits:GetTall() / 2)
	end
	for k, v in pairs(data) do
		local row = vgui.Create("DPanel", scroll)
		scroll:AddItem(row)
		row:SetSize(scroll:GetWide(), 75)
		row:SetPos(0, 0)
		for i=0, 2 do
			local box = vgui.Create("DPanel", row)
			box:SetSize(row:GetWide() * 0.25, row:GetTall())
			box:SetPos(i * row:GetWide() * 0.25, 0)

			local credits = DankUI.CreateLabel(box, i==0 and k or v[i], "dank_ui.20")
			credits:SetPos(box:GetWide() / 2 - credits:GetWide() / 2, box:GetTall() / 2 - credits:GetTall() / 2)
		end
		local btn = vgui.Create("DButton", row)
		btn:SetSize(row:GetWide() * 0.25 - 20, row:GetTall() - 20)
		btn:SetPos((3 * row:GetWide() * 0.25) + 10, 10)
		btn:SetText("View")
		btn.DoClick = function()
			ActivityStats(k)
		end
	end
end

function Gangs.CreateLeaderboardPage(frame, panel)
	local gang = LocalPlayer():GetGang()
	Leaderboard.GetData("gang_data", function(data)
		DrawUI(gang, panel, data)	
	end)
end