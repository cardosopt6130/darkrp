--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_home.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function SetMOTD(panel, motdString, width)
	if Gangs.MOTD then Gangs.MOTD:Remove() end
	local wrapped = D3A.WordWrap("dank_ui.20", motdString, width)
	local text = table.concat(wrapped, "\n")
	Gangs.MOTD = DankUI.CreateLabel(panel, text, "dank_ui.20")
	Gangs.MOTD:SetPos(5, 5)
	return Gangs.MOTD
end

local function OnlineMembers()
	local players = {}
	for k, v in pairs(player.GetAll()) do
		if v:GetDataVar("gang") == LocalPlayer():GetDataVar("gang") then
			table.insert(players, v)
		end
	end
	return players
end

local function Members(gang)
	return #OnlineMembers() .. "/" .. table.Count(Gangs.Cache.GetMembers(gang))
end

local infos = {
	["Level"] = Gangs.Cache.GetLevel,
	["Power"] = Gangs.Cache.GetPower,
	["Prestige"] = Gangs.Cache.GetPrestige,
	["Online"] = Members,
	["Ranks"] = function(gang) return Gangs.Cache.RankCount(gang) .. "/" .. Gangs.Cache.GetMaxRanks(gang) + table.Count(Gangs.DefaultRanks) end,
	["Wealth"] = function(gang) return DarkRP.formatMoney(Gangs.Cache.GetWealth(gang)) end,
	["Elo"] = Gangs.Cache.GetElo
}

function Gangs.CreateHomePage(frame, panel)
	local gang = LocalPlayer():GetGang()
	local title = DankUI.CreateLabel(panel, gang, "dank_ui.large")
	title:SetPos(10, 10)
	local divider = vgui.Create("dank_ui.divider", panel)
	divider:SetPos(10, title.y + title:GetTall() + 10)
	local list = vgui.Create("DIconLayout", panel)
	list:SetSpaceX(15)
	list:SetPos(15, divider.y + divider:GetTall() + 20)
	list:SetSize(panel:GetWide() - 30, 100)
	for name, func in pairs(infos) do
		local pnl = list:Add("DPanel")
		local w = ((list:GetWide() - ((table.Count(infos) - 1) * 15)) / table.Count(infos))
		pnl:SetSize(w, list:GetTall())
		local lbl = DankUI.CreateLabel(pnl, name, "dank_ui.medium")
		local value = DankUI.CreateLabel(pnl, func(gang), "dank_ui.30")
		lbl:SetPos(pnl:GetWide() / 2 - lbl:GetWide() / 2, pnl:GetTall() / 2 - lbl:GetTall() / 2 - value:GetTall() / 2)
		value:SetPos(lbl.x + lbl:GetWide() / 2 - value:GetWide() / 2, lbl.y + lbl:GetTall())
		if value:GetWide() > w then
			value:SetFont("dank_ui.20")
			value:SizeToContents()
			value:SetPos(lbl.x + lbl:GetWide() / 2 - value:GetWide() / 2, lbl.y + lbl:GetTall() + 5)
		end
		local color = Gangs.GetColor(LocalPlayer():GetGang())
		value:SetTextColor(color != color_white and color or DankUI.Red)
	end

	local motdW = panel:GetWide() * 0.7
	local motd_bg = vgui.Create("DPanel", panel)
	motd_bg:SetSize(motdW, panel:GetTall() - (list:GetTall() + list.y) - 30)
	motd_bg:SetPos(15, list.y + list:GetTall() + 15)

	local motd = SetMOTD(motd_bg, Gangs.Cache.GetMOTD(gang), motdW)

	local commands = vgui.Create("dank_ui.button_list", panel)
	commands:SetSize(list:GetWide() - (motd_bg:GetWide() + motd_bg.x + 15) + 15, motd_bg:GetTall())
	commands:SetPos(motd_bg.x + motd_bg:GetWide() + 15, motd_bg.y)

	commands:AddButton(function(parent)
		local setMotd = Gangs.CreateCommandButton("Change MOTD", "m", parent, function()
			local frame = vgui.Create("dank_ui.frame")
			frame:SetTitle("Change MOTD")
			frame:SetSize(400, 400)
			frame:Center()

			local entry = vgui.Create("DTextEntry", frame)
			entry:SetSize(frame:GetWide(), frame:GetTall() - 60)
			entry:SetPos(0, 30)
			entry:SetValue(Gangs.Cache.GetMOTD(gang))
			
			local sumbit = vgui.Create("DButton", frame)
			sumbit:SetText("Submit")
			sumbit:SetSize(frame:GetWide(), 30)
			sumbit:SetPos(0, frame:GetTall() - sumbit:GetTall())
			sumbit.DoClick = function()
				local value = entry:GetValue()
				local length = string.len(string.Trim(value))
				if length >= 4 and length <= 255 then
					RunConsoleCommand("gw_set_motd", value)
					SetMOTD(motd_bg, value, motdW)
				end
				frame:Close()
			end
		end)
		return setMotd
	end)

	commands:AddButton(function(parent)
		local leave = vgui.Create("DButton", parent)
		if LocalPlayer():GetGangRank() == "owner" and Gangs.Cache.CountOwners(gang) == 1 then
			leave:SetText("Disband")
		else
			leave:SetText("Leave")
		end
		leave.DoClick = function()
			local confirm = vgui.Create("dank_ui.confirm")
			if LocalPlayer():GetDataVar("gangRank") == "owner" and Gangs.Cache.CountOwners(gang) == 1 then
				confirm:SetQuestion("Are you sure you want to disband?")
			else
				confirm:SetQuestion("Are you sure you want to leave?")
			end
			confirm.OnYes = function()
				RunConsoleCommand("gw_leave_gang")
				confirm:Remove()
				if IsValid(frame) then
					frame:Close()
				end
			end
		end
		return leave
	end)

	commands:AddButton(function(parent)
		local change_name = vgui.Create("DButton", parent)
		change_name:SetText("Change Name (" .. DarkRP.formatMoney(Gangs.Config.NameChangeCost) .. ")")
		change_name:SetEnabled(Gangs.Permissions.HasPermission("n"))
		change_name.DoClick = function()
			local entry = vgui.Create("dank_ui.entry")
			entry:SetQuestion("What new name would you like? (" .. DarkRP.formatMoney(Gangs.Config.NameChangeCost) .. ")")
			entry.OnYes = function(s, value)
				if !LocalPlayer():canAfford(Gangs.Config.NameChangeCost) then Gangs.Term("cannot_afford") return end
				if !Gangs.IsValidName(value) then
					Gangs.Notify("Invalid gang name.")
					return
				end
				RunConsoleCommand("gw_change_name", value)
				title:SetText(value)
				title:SizeToContents()
				title:SetPos(5, 5)
			end
		end
		return change_name
	end)

	commands:AddButton(function(parent)
		local invite = Gangs.CreateCommandButton("Invite", "i", parent, function(self)
			frame:SetVisible(false)
			local entry = vgui.Create("dank_ui.entry")
			entry:PlayerAutoComplete()
			entry:SetQuestion("Invite an online player.")
			entry.OnClose = function()
				frame:SetVisible(true)
			end
			entry.OnYes = function(s, v)
				frame:SetVisible(true)
				if isstring(v) then
					Gangs.Notify("Please select a player from the drop down list.")
					return
				end
				net.Start("Gangs.Invite")
					net.WritePlayer(v)
				net.SendToServer()
				Gangs.Notify("You invited " .. v:Nick() .. " to your gang.")
			end
		end)
		return invite
	end)
end