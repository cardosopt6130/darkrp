--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_model_table.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local PANEL = {}

function PANEL:Init()
	self:SetSkin("material_dark")
	self.table = vgui.Create("dank_ui.item_table", self)
	self.models = {}
end

function PANEL:SetRowHeight(height)
	self.table:SetRowHeight(height)
	self:PerformLayout()
end

function PANEL:SetItemsPerRow(num)
	self.table:SetItemsPerRow(num)
end

function PANEL:Finish()
	self.table:AddItems(self.models)
end

function PANEL:AddModel(mdl, do_click, text)
	local bg = vgui.Create("DPanel", self.table)
	bg:SetSize(self:GetWide() / self.table.items_per_row, self.table.height)
	if text then
		local txt = DankUI.CreateLabel(bg, text, "dank_ui.20")
		txt:SetPos(5, bg:GetTall() - txt:GetTall())
	end
	local item = vgui.Create("DModelPanel", bg)
	item:SetSize(bg:GetSize())
	item:SetModel(mdl)
	item.OnMousePressed = do_click
	local shouldRoate = false
	local function newLayoutFunc(s, ent)
		if shouldRoate then
			local z = ent:GetAngles().z + 0.35
			ent:SetAngles(Angle( 0, 0, z ))
		end
	end
	item.OnCursorEntered = function()
		shouldRoate = true
	end
	item.OnCursorExited = function()
		shouldRoate = false
	end
	
	local min, max = item.Entity:GetRenderBounds()

	item:SetCamPos( Vector( 0.55, 0.55, 0.55 ) * min:Distance( max ) )
	item:SetLookAt( ( min + max ) / 2 )

	item.LayoutEntity = newLayoutFunc
	table.insert(self.models, bg)
	return item, bg
end

function PANEL:PerformLayout(w, h)
	self.table:SetSize(w, h)
end
vgui.Register("dank_ui.model_table", PANEL, "DPanel")