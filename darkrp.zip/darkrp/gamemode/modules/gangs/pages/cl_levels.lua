--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_levels.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local prestige_info = {
	["Level Reset"] = "Your gang level will reset to prestige %s, level 1.",
	["Prestige Unlock Token"] = "Your gang will get an prestige unlock token to spend.",
	["Permanently Unlock Level"] = "Choose a level to permanently unlock.",
	["Cost"] = "The cost is " .. DarkRP.formatMoney(Gangs.Config.PrestigeCost) .. " OR " .. math.ceil(Gangs.Config.PrestigeCost/Gangs.Config.CreditToCash) .. " credits.",
}

local green = Color(50, 150, 50)

local function PrestigeMenu(gang, frame, price, level_num)
	local fr = vgui.Create("dank_ui.frame")
	fr:SetSize(500, 700)
	fr:SetTitle("Prestige")
	local prestige_to_enter = Gangs.Cache.GetPrestige(gang) + 1
	local info = DankUI.CreateLabel(fr, "Prestige " .. prestige_to_enter, "dank_ui.medium")
	info:SetPos(fr:GetWide() / 2- info:GetWide() / 2, 35)
	local divider = vgui.Create("dank_ui.divider", fr)
	divider:SetPos(150, info.y + info:GetTall() + 2.5)
	local next_y = divider.y + divider:GetTall() + 10
	for k, v in pairs(prestige_info) do
		local btn = vgui.Create("DPanel", fr)
		btn:SetSize(fr:GetWide() - 30, 50)
		btn:SetPos(15, next_y)
		local title = DankUI.CreateLabel(btn, k, "dank_ui.20")
		title:SetPos(btn:GetWide() / 2-  title:GetWide() / 2, 2.5)
		local desc = DankUI.CreateLabel(btn, string.format(v, prestige_to_enter), "dank_ui.small")
		desc:SetPos(btn:GetWide() / 2 - desc:GetWide() / 2, title.y + title:GetTall())
		btn:SetTall(desc.y + desc:GetTall() + 5)
		next_y = next_y + btn:GetTall() + 5
	end
	local divider = vgui.Create("dank_ui.divider", fr)
	divider:SetPos(5, next_y + 5)
	local btn = vgui.Create("DButton", fr)
	btn:SetSize(fr:GetWide() / 2 - 15, 50)
	btn:SetPos(10, divider:GetTall() + divider.y + 10)
	btn:SetText("Enter Prestige (£600M)")
	local credit_cost = math.ceil(price/Gangs.Config.CreditToCash)
	local function func(credits)
		local entry = vgui.Create("dank_ui.entry")
		entry:SetQuestion("What level would you like to permanently unlock?")
		entry:SetNumeric(true)
		entry.OnYes = function(s, value)
			if !credits && LocalPlayer():canAfford(price) || credits && Gangs.Cache.GetCredits(gang) >= credit_cost then
				RunConsoleCommand("gw_level_up", level_num, credits && "y" || "n", math.Round(tonumber(value)))
				fr:Close()
				frame:Close()
			else
				Gangs.Term("cannot_afford")
			end
			entry:Remove()
		end
	end
	btn.DoClick = function()
		func(false)
	end
	local btn2 = vgui.Create("DButton", fr)
	btn2:SetSize(btn:GetSize())
	btn2:SetPos(btn.x + btn:GetWide() + 10, divider:GetTall() + divider.y + 10)
	btn2:SetText("Enter Prestige (" .. credit_cost.. " credits)")
	btn2.DoClick = function()
		func(true)
	end
	
	fr:SetTall(btn.y + btn:GetTall() + 10)
	fr:Center() 
end

local function DrawCallingCards(fr, options, do_click)
	local tbl = vgui.Create("dank_ui.item_table", fr)
	tbl:SetSize(fr:GetWide(), fr:GetTall() - 30)
	tbl:SetPos(0, 30)
	tbl:SetRowHeight(64 + 5)
	tbl:SetItemsPerRow(3)
	local items = {}
	for id, option in pairs(options) do
		local item = vgui.Create("DButton", tbl)
		item:SetSize(math.Round(tbl:GetWide() / tbl.items_per_row), tbl.height)
		item:SetText("")
		item.Paint = function(s, w, h)
			draw.WebImage(option, 2.5, 2.5, w - 5, 64, Color(255, 255, 255, s:IsHovered() && 255 || 100))
		end
		item.DoClick = function() do_click(id) end
		table.insert(items, item)
	end
	tbl:AddItems(items)
end

local function DrawWeapons(fr, options, do_click)
	local tbl = vgui.Create("dank_ui.model_table", fr)
	tbl:SetSize(fr:GetWide(), fr:GetTall() - 30)
	tbl:SetPos(0, 30)
	tbl:SetRowHeight((fr:GetTall() - 30) / 2)
	tbl:SetItemsPerRow(3)
	local items = {}
	for id, option in pairs(options) do
		local wep = weapons.Get(id)
		if !wep then continue end
		tbl:AddModel(wep.WorldModel, function()
			do_click(id) 
		end, wep.PrintName)
	end
	tbl:Finish()
end

local shouldRoate = false
local function newLayoutFunc(s, ent)
	if shouldRoate then
		local z = ent:GetAngles().z + 0.35
		ent:SetAngles(Angle( 0, 0, z ))
	end
end

local function GangSignMaterial(fr, options, do_click, btn_txt)
	local sign = vgui.Create("DModelPanel", fr)
	sign:SetSize(fr:GetWide() * 0.5, fr:GetTall() - 80)
	sign:SetPos(fr:GetWide() * 0.5, 30)
	sign:SetModel("models/hunter/plates/plate1x1.mdl")
	sign:SetCamPos(Vector(0, 0, 90))
	sign:SetFOV(50)
	sign.OnMousePressed = function()
		shouldRoate = !shouldRoate
	end

	local selected_material

	local unlock = vgui.Create("DButton", fr)
	unlock:SetSize(sign:GetWide(), 50)
	unlock:SetPos(fr:GetWide() * 0.5, sign.y + sign:GetTall())
	unlock:SetText(btn_txt || "Unlock")
	unlock.DoClick = function()
		if selected_material then
			do_click(selected_material)
		end
	end
	
	sign.Entity:SetMaterial("phoenix_storms/gear")
	sign.LayoutEntity = newLayoutFunc

	local tbl = vgui.Create("dank_ui.item_table", fr)
	tbl:SetSize(fr:GetWide() * 0.5, fr:GetTall())
	tbl:SetPos(0, 30)
	tbl:SetRowHeight(70)
	tbl:SetItemsPerRow(3)
	local items = {}
	for _, option in pairs(options) do
		local item = vgui.Create("DButton", tbl)
		item:SetSize(math.Round(tbl:GetWide() / tbl.items_per_row), tbl.height)
		item:SetText("")
		item:SetMaterial(option)
		item.DoClick = function()
			sign.Entity:SetMaterial(option)
			selected_material = option
		end
		table.insert(items, item)
	end
	tbl:AddItems(items)
end

local function GetAccessories(filter_tbl)
	local accessories = {}
	for id, accessory in pairs(Gangs.Accessories) do
		if filter_tbl && !filter_tbl[id] then continue end
		table.insert(accessories, accessory)
	end
	return accessories 
end

local function TokenItemsPanel(fr, options, do_click)
	local pnl = vgui.Create("DPanel", fr)
	pnl:SetSize(fr:GetWide(), fr:GetTall() - 30)
	pnl:SetPos(0, 30)
	local items = vgui.Create("tokens_items_panel", pnl)
	items:SetNonManageable(true)
	items:SetSize(pnl:GetSize())
	items:SetDrawPrice(false)
	items:SetItemsPerRow(5)
	items:SetTitle("Exclusive Items")
	items:AddItems(options)
	items.OnItemPressed = function(s, item_id)
		do_click(item_id)
	end
end

local function GetItemsOfType(typ)
	local items = Gangs.Cache.GetItems(LocalPlayer():GetGang())
	local found = {}
	for k, item_id in pairs(items) do
		local item = Gangs.Config.PrestigeShop[typ].options[item_id] || (table.HasValue(Gangs.Config.PrestigeShop[typ].options, item_id) && item_id)
		if item then
			found[item_id] = item
		end
	end
	return found
end

local function DrawPlayerModels(fr, options, do_click, txt)
	local gang = LocalPlayer():GetGang()
	local data = {}
	local models = {}
	if options[1] && istable(options[1]) then
		for k, v in pairs(options) do
			local mdl, skin_id, bodygroups = unpack(v)
			table.insert(models, mdl)
			data[k] = {skin_id=skin_id, bodygroups=bodygroups}
		end
	else
		models = options
	end
	local remove = vgui.Create("DButton", fr)
	remove:SetSize(100, 30)
	remove:SetPos(fr.btnClose.x - remove:GetWide(), 0)
	remove:SetText("No Model")
	remove.DoClick = function()
		RunConsoleCommand("playermodel_remove")
		fr:Close()
	end
	PlayerModel.Draw(fr, models, data, function(model, skin_id, bodygroups, index)
		if txt == "Equip" then
			net.Start("Gangs.EquipPlayerModel")
				net.WriteString(model)
				net.WriteUInt(index, 3)
			net.SendToServer()
			fr:Close()
		else
			local confirm = vgui.Create("dank_ui.confirm")
			confirm:SetQuestion("Are you sure you want to unlock this player model?")
			confirm.OnYes = function()
				confirm:Remove()
				if table.HasValue(Gangs.Cache.GetItems(gang), model) then
					Gangs.Notify("Your gang already owns this item.")
					return
				end
				if Gangs.Cache.GetPrestigeTokens(gang) < 1 then
					Gangs.Notify("Your gang does not have any prestige tokens.")
					return
				end
				net.Start("Gangs.PlayerModel")
					net.WriteString(model)
					if skin_id then
						net.WriteBit(1)
						net.WriteUInt(skin_id, 8)
					else
						net.WriteBit(0)
					end
					if bodygroups then
						net.WriteBit(1)
						net.WriteTable(bodygroups)
					else
						net.WriteBit(0)
					end
				net.SendToServer()
				fr:Close()
			end
		end
	end, txt)
end

local types = {
	["calling_card"] = {func=DrawCallingCards, txt="calling card"},
	["cosmetic"] = {func=TokenItemsPanel, parse=GetAccessories, txt="cosmetic"},
	["gang_sign_material"] = {func=GangSignMaterial, txt="material"},
	["weapon"] = {func=DrawWeapons, txt="weapon"},
	["player_model"] = {func=DrawPlayerModels, txt="model"},
}

local auto_equip = CreateClientConVar("gang_auto_equip", 0, true)

local function InventoryMenu(fr, typ)
	local items = typ == "player_model" && Gangs.Cache.GetPlayerModels(LocalPlayer():GetGang()) || GetItemsOfType(typ)
	local tbl = types[typ]
	tbl.func(fr, tbl.parse && tbl.parse(items) || items, function(item_id)
		local confirm = vgui.Create("dank_ui.confirm")
		confirm:SetQuestion("Are you sure you want to equip this " .. tbl.txt .. "?")
		confirm.OnYes = function()
			RunConsoleCommand("gw_equip_item", typ, item_id)
			if typ == "weapon" then
				auto_equip:SetBool(true)
			end
			confirm:Remove()
		end
	end, "Equip")
end

local red = table.Copy(DankUI.Red)
red.a = 100
local pnl_col = table.Copy(DankUI.Panel)
pnl_col.a = 255
local function PrestigeShop(gang, pnl)
	local color = Gangs.GetColor(gang)
	color = color != color_white and color or red
	local count = table.Count(Gangs.Config.PrestigeShop)
	local h = math.Round((pnl:GetTall() - (count - 1) * 5) / count) 
	local next_y = 0
	for k, v in pairs(Gangs.Config.PrestigeShop) do
		local item = vgui.Create("DPanel", pnl)
		item:SetSize(pnl:GetWide(), h - 2)
		item:SetPos(0, next_y)
		local title = DankUI.CreateLabel(item, v.name .. (v.limit && (" (Limit: " .. v.limit..")") || ""), "dank_ui.20")
		title:SetPos(item:GetWide() / 2 - title:GetWide() / 2, 2.5)
		item.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, pnl_col)
			surface.SetDrawColor(DankUI.Outline)
			surface.DrawOutlinedRect(0, 0, w, h)
			draw.RoundedBox(0, 0, 0, w, title.y + title:GetTall() + 2.5, color) 
		end
		if v.options then
			local btn = vgui.Create("DButton", item)
			btn:SetSize(item:GetWide() / 2 - 15, item:GetTall() - title:GetTall() - 20)
			btn:SetPos(10, title.y + title:GetTall() + 10)
			btn:SetText("Browse")
			btn.DoClick = function()
				local fr = vgui.Create("dank_ui.frame")
				fr:SetSize(ScrW() * 0.5, ScrH() * 0.6)
				fr:SetTitle("Browse")
				fr:Center()
				local tbl = types[k]
				tbl.func(fr, tbl.parse && tbl.parse() || v.options, function(item_id)
					local confirm = vgui.Create("dank_ui.confirm")
					confirm:SetQuestion("Are you sure you want to unlock this " .. tbl.txt .. "?")
					confirm.OnYes = function()
						confirm:Remove()
						if table.HasValue(Gangs.Cache.GetItems(gang), item_id) then
							Gangs.Notify("Your gang already owns this item.")
							return
						end
						if Gangs.Cache.GetPrestigeTokens(gang) < 1 then
							Gangs.Notify("Your gang does not have any prestige tokens.")
							return
						end
						RunConsoleCommand("gw_prestige_token", k, item_id)
						fr:Close()
					end
				end)
			end
			local inv = vgui.Create("DButton", item)
			inv:SetSize(btn:GetSize())
			inv:SetPos(btn.x + btn:GetWide() + 10, btn.y)
			inv:SetText("Inventory")
			inv.DoClick = function()
				local fr = vgui.Create("dank_ui.frame")
				fr:SetSize(ScrW() * 0.5, ScrH() * 0.6)
				fr:SetTitle("Inventory")
				fr:Center()
				InventoryMenu(fr, k)
			end
		else
			local btn = vgui.Create("DButton", item)
			btn:SetSize(item:GetWide() - 20, item:GetTall() - title:GetTall() - 20)
			btn:SetPos(item:GetWide() / 2 - btn:GetWide() / 2, title.y + title:GetTall() + 10)
			btn:SetText("Unlock")
			btn.DoClick = function()
				local confirm = vgui.Create("dank_ui.confirm")
				confirm:SetQuestion("Are you sure you want to unlock "..v.name.." for\nyour gang?")
				confirm.OnYes = function()
					confirm:Remove()
					if table.HasValue(Gangs.Cache.GetItems(gang), k) then
						Gangs.Notify("Your gang already owns this item.")
						return
					end
					if Gangs.Cache.GetPrestigeTokens(gang) < 1 then
						Gangs.Notify("Your gang does not have any prestige tokens.")
						return
					end
					RunConsoleCommand("gw_prestige_token", k)
				end
			end
		end
		next_y = next_y + h + 5
	end
end

local function PrestigeLevelUI(frame, pnl2, k, v)
	local gang = LocalPlayer():GetGang()
	local prestige_to_enter = Gangs.Cache.GetPrestige(gang) + 1
	local color
	local txt 
	if prestige_to_enter > 10 then
		color = Gangs.PrestigeColors[10]
		txt = "Max Prestige"
	else
		color = Gangs.PrestigeColors[prestige_to_enter]
		txt = "Ready To Prestige"
	end
	color.a = 50 
	local name = DankUI.CreateLabel(pnl2, txt, "dank_ui.20")
	name:SetPos(pnl2:GetWide() / 2 - name:GetWide() / 2, 5)
	local divider = vgui.Create("dank_ui.divider", pnl2)
	divider:SetPos(100, name.y + name:GetTall() + 5)
	local btn = vgui.Create("DButton", pnl2)
	btn:SetSize(pnl2:GetWide() - 20, 60)
	btn:SetPos(pnl2:GetWide() / 2 - btn:GetWide() / 2, divider.y + divider:GetTall() + 10)
	if prestige_to_enter > 10 then
		btn:SetText("Maxed Out")
		btn:SetEnabled(false)
	else
		btn:SetText("Prestige Info")
	end
	btn.Style = function(self, w, h, col)
		DankUI.Element.MovingGradient(self, w, h, color, 0.25, 0.75, false, false, true, true, 6)
	end
	btn.DoClick = function()
		PrestigeMenu(gang, frame, v.price, k)
	end
	btn.Font = "dank_ui.20"
	pnl2:SetTall(btn.y + btn:GetTall() + 10)
	return pnl2
end

function Gangs.CreateLevelsPage(frame, panel)
	local gang = LocalPlayer():GetGang()
	local pnl = vgui.Create("DPanel", panel)
	pnl:SetSize(panel:GetWide() / 2 - 7.5, (panel:GetTall() - (50 + 15)) * 0.25)
	pnl:SetPos(5, 5)

	local current_lvl = DankUI.CreateLabel(pnl, "Prestige " .. Gangs.Cache.GetPrestige(gang) .. " | Level " .. Gangs.Cache.GetLevel(gang), "dank_ui.30")
	current_lvl:SetPos(pnl:GetWide() / 2 - current_lvl:GetWide() / 2, 5)
	pnl:SetTall(current_lvl.y + current_lvl:GetTall() + 5)

	local pnl2 = vgui.Create("DPanel", panel)
	pnl2:SetSize(pnl:GetWide(), panel:GetTall() * 0.6)
	pnl2:SetPos(pnl.x, pnl:GetTall() + pnl.y + 5)

	local pnl3 = vgui.Create("DPanel", panel)
	local scroll2 = vgui.Create("dank_ui.scroll", pnl3)
	local all_levels = DankUI.CreateLabel(pnl3, "All Levels", "dank_ui.medium")

	local k = Gangs.Cache.GetLevel(gang) + 1
	local v = Gangs.Config.Levels[k]
	if v.prestige then
		PrestigeLevelUI(frame, pnl2, k, v)
	else
		local lvl = DankUI.CreateLabel(pnl2, "Next Level: " .. k, "dank_ui.medium")
		lvl:SetPos(pnl2:GetWide() / 2 - lvl:GetWide() / 2, 5)
		local divider = vgui.Create("dank_ui.divider", pnl2)
		divider:SetPos(5, lvl.y + lvl:GetTall() + 2.5)
		local name = DankUI.CreateLabel(pnl2, v.name, "dank_ui.20")
		name:SetPos(pnl2:GetWide() / 2 - name:GetWide() / 2, divider.y + divider:GetTall() + 2.5)
		local power = DankUI.CreateLabel(pnl2, "+" .. v.power .. " power", "dank_ui.20")
		power:SetPos(pnl2:GetWide() / 2 - power:GetWide() / 2, name.y + name:GetTall())
		power:SetColor(Color(200, 50, 50))
		local credit_cost = math.ceil(v.price/Gangs.Config.CreditToCash)
		local price = DankUI.CreateLabel(pnl2, DarkRP.formatMoney(v.price) .. " OR " .. credit_cost .. " credits", "dank_ui.20")
		price:SetPos(pnl2:GetWide() / 2 - price:GetWide() / 2, power.y + power:GetTall())
		price:SetColor(green)
		local buy = vgui.Create("DButton", pnl2)
		buy:SetSize(pnl2:GetWide() / 2 - 15, 50)
		buy:SetPos(10, price.y + price:GetTall() + 5)
		buy:SetText("Unlock Level " .. k .. " ("..DarkRP.formatMoney(v.price) .. ")")
		local color = Gangs.GetColor(gang)
		color.a = 50
		buy.Style = function(self, w, h, col)
			DankUI.Element.MovingGradient(self, w, h, color, 0.25, 0.75, false, false, true, true, 6)
		end
		local buy2 = vgui.Create("DButton", pnl2)
		local function UpdateFunc(gang_credits)
			local entry = vgui.Create("dank_ui.confirm")
			entry:SetQuestion("Are you sure you want to unlock this level?")
			entry.OnYes = function()
				entry:Remove()
				if (gang_credits && Gangs.Cache.GetCredits(gang) >= credit_cost) || !gang_credits && LocalPlayer():canAfford(v.price) then
					RunConsoleCommand("gw_level_up", k, gang_credits && "y" || "n")
					k = k + 1
					v = Gangs.Config.Levels[k]
					current_lvl:SetText("Prestige " .. Gangs.Cache.GetPrestige(gang) .. " | Level " .. k - 1)
					current_lvl:SizeToContents()
					current_lvl:SetPos(pnl:GetWide() / 2 - current_lvl:GetWide() / 2, 5)
					if k == 25 then
						for k, v in pairs(pnl2:GetChildren()) do
							if IsValid(v) then
								v:Remove()
							end
						end
						local pnl69 = PrestigeLevelUI(frame, pnl2, k, Gangs.Config.Levels[k])
						pnl3:SetPos(pnl3.x, pnl69.y + pnl69:GetTall() + 5)
						pnl3:SetTall(panel:GetTall() - pnl3.y - 5)
						local space = all_levels.y + all_levels:GetTall()
						scroll2:SetSize(pnl3:GetWide(), pnl3:GetTall() - space)
						scroll2:SetPos(0, space + 5)
						return
					end
					lvl:SetText("Next Level: " .. k)
					lvl:SizeToContents()
					name:SetText(v.name)
					name:SizeToContents()
					name:SetPos(pnl2:GetWide() / 2 - name:GetWide() / 2, divider.y + divider:GetTall() + 2.5)
					power:SetText("+" .. v.power .. " power")
					power:SizeToContents()
					power:SetPos(pnl2:GetWide() / 2 - power:GetWide() / 2, name.y + name:GetTall())
					power:SetColor(Color(200, 50, 50))
					price:SetText(DarkRP.formatMoney(v.price))
					price:SizeToContents()
					price:SetPos(pnl2:GetWide() / 2 - price:GetWide() / 2, power.y + power:GetTall())
					buy:SetText("Unlock Level " .. k .. " ("..DarkRP.formatMoney(v.price) .. ")")
					local credit_cost = math.ceil(v.price/Gangs.Config.CreditToCash)
					buy2:SetText("Unlock Level " .. k .. " ("..credit_cost.. " credits)")
				else
					Gangs.Term("cannot_afford")
				end
			end
		end
		buy.DoClick = function()
			UpdateFunc(false)
		end
		buy2:SetSize(buy:GetSize(), 50)
		buy2:SetPos(buy.x + buy:GetWide() + 10, price.y + price:GetTall() + 5)
		buy2:SetText("Unlock Level " .. k .. " ("..credit_cost.. " credits)")
		local color = Gangs.GetColor(gang)
		color.a = 50
		buy2.Style = function(self, w, h, col)
			DankUI.Element.MovingGradient(self, w, h, color, 0.25, 0.75, false, false, true, true, 6)
		end
		buy2.DoClick = function()
			UpdateFunc(true)
		end
		pnl2:SetTall(buy2.y + buy2:GetTall() + 10)
	end

	pnl3:SetSize(pnl:GetWide(), panel:GetTall() - (pnl:GetTall() + pnl2:GetTall() + 20))
	pnl3:SetPos(pnl.x, pnl2:GetTall() + pnl2.y + 5)

	all_levels:SetPos(pnl3:GetWide() / 2 - all_levels:GetWide() / 2, 5)
	
	local space = all_levels.y + all_levels:GetTall()
	scroll2:SetSize(pnl3:GetWide(), pnl3:GetTall() - space)
	scroll2:SetPos(0, space + 5)
	scroll2:SetPadding(-1)

	local permanent_levels = Gangs.Cache.GetPermanentLevels(gang)
	for k, v in SortedPairs(Gangs.Config.Levels) do
		local lvl_pnl = vgui.Create("DPanel", scroll2)
		lvl_pnl:SetTall(100)
		scroll2:AddItem(lvl_pnl)
		local text ="Level: " .. k
		if permanent_levels[k] then
			lvl_pnl.Paint = function(s, w, h)
				draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, 100))
			end
			text = text.. " [Unlocked]"
		end
		local lvl = DankUI.CreateLabel(lvl_pnl, text .. " | +" .. v.power .. " power", "dank_ui.20")
		lvl:SetPos(lvl_pnl:GetWide() / 2 - lvl:GetWide() / 2, 5)
		local divider = vgui.Create("dank_ui.divider", lvl_pnl)
		divider:SetPos(lvl_pnl:GetWide() * 0.2, lvl.y + lvl:GetTall() + 2.5)
		local name = DankUI.CreateLabel(lvl_pnl, v.name, "dank_ui.20")
		name:SetPos(lvl_pnl:GetWide() / 2 - name:GetWide() / 2, divider.y + divider:GetTall() + 2.5)
		local power = DankUI.CreateLabel(lvl_pnl, DarkRP.formatMoney(v.price) .. " | " .. math.ceil(v.price/Gangs.Config.CreditToCash) .. " credits", "dank_ui.20")
		power:SetPos(lvl_pnl:GetWide() / 2 - power:GetWide() / 2, name.y + name:GetTall())
		lvl_pnl:SetTall(power.y + power:GetTall() + 5)
	end

	local token_panel = vgui.Create("DPanel", panel)
	token_panel:SetSize(pnl:GetWide(), 50)
	token_panel:SetPos(pnl.x + pnl:GetWide() + 5, 5)
	local tkns = DankUI.CreateLabel(token_panel, "Prestige Tokens: " .. Gangs.Cache.GetPrestigeTokens(gang), "dank_ui.30")
	tkns:SetPos(5, 5)
	local info = vgui.Create("DButton", token_panel)
	info:SetSize(token_panel:GetWide() * 0.25, token_panel:GetTall() - 15)
	info:SetPos(token_panel:GetWide() - info:GetWide() - 7.5, 7.5)
	info:SetText("Info")
	info.DoClick = function()
		local fr = vgui.Create("dank_ui.frame")
		fr:SetTitle("Info ")
		fr:SetSize(550, 300)
		fr:Center()
		local lbl = DankUI.CreateLabel(fr, "In this store you can use tokens earned from\nprestiging to unlock exclusive permanent items\nfor members apart of your gang.\n\nIf members leave/get kicked they lose their items.\n\nAfter prestiging max rank/member slots do not change.\n\nPermanently unlocking a level means you get the benefits\nbut still have to pay for it again to prestige.",
		"dank_ui.20")
		lbl:SetPos(5, 30)
	end
	token_panel:SetTall(tkns.y + tkns:GetTall() + 5)
	local prestige_token_pnl = vgui.Create("DPanel", panel)
	prestige_token_pnl.Paint = function() end
	prestige_token_pnl:SetSize(token_panel:GetWide(), panel:GetTall() - (token_panel:GetTall() + 15))
	prestige_token_pnl:SetPos(token_panel.x, token_panel.y + token_panel:GetTall() + 5)
	PrestigeShop(gang, prestige_token_pnl)
end