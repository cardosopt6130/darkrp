--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_ranks.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function TableToString(table, seperator)
	local string = ""
	for k, v in pairs(table) do
		string = string .. (string == "" and "" or seperator) .. v
	end
	return string
end

local addedTbl = {}
local removedTbl = {}

local function CreateFlagButtons(self, option, added, removed, startY)
	local flags = option.data
	local newRow = false
	local spacing = 20
	local x = spacing
	local count = 0
	local y = self.name.y + self.name:GetTall() + 10
	for k, v in pairs(Gangs.Permissions.Flags) do
		local btn = vgui.Create("DButton", self.selected)
		btn:SetPos(x, y)
		btn:SetSize((self.selected:GetWide() - 60) * 0.5, 40)
		btn:SetText(v)
		local hasFlag = flags == "*" or flags[k]
		if hasFlag then
			btn.textColor = Color(50, 150, 50)
		else 
			btn.textColor = DankUI.Red
		end
		x = x + btn:GetWide() + spacing
		count = count + 1
		if count == 2 then 
			y = y + btn:GetTall() + spacing
			x = spacing
			count = 0
		end

		btn.DoClick = function()
			if (hasFlag or addedTbl[k]) and !removedTbl[k] then
				if addedTbl[k] then
					addedTbl[k] = nil
					added:Remove()
					added = DankUI.CreateLabel(self.selected, "Added: " .. TableToString(addedTbl, ", "), "dank_ui.small")
					added:SetPos(self.selected:GetWide() / 2 - added:GetWide() / 2, startY - 5)
				end
				removedTbl[k] = v
				btn.textColor = DankUI.Red
				removed:Remove()
				removed = DankUI.CreateLabel(self.selected, "Removed: " .. TableToString(removedTbl, ", "), "dank_ui.small")
				removed:SetPos(self.selected:GetWide() / 2 - removed:GetWide() / 2, added.y - added:GetTall() - 5)
			else
				if removedTbl[k] then
					removedTbl[k] = nil
					removed:Remove()
					removed = DankUI.CreateLabel(self.selected, "Removed: " .. TableToString(removedTbl, ", "), "dank_ui.small")
					removed:SetPos(self.selected:GetWide() / 2 - removed:GetWide() / 2, added.y - added:GetTall() - 5)
				end
				addedTbl[k] = v
				btn.textColor = Color(50, 150, 50)
				added:Remove()
				added = DankUI.CreateLabel(self.selected, "Added: " .. TableToString(addedTbl, ", "), "dank_ui.small")
				added:SetPos(self.selected:GetWide() / 2 - added:GetWide() / 2, startY - 5)
			end
		end
	end
end

local function GetWeight(weightString)
	local string = string.Trim(weightString)
	if string == "" then return end
	local num = tonumber(string)
	if !num then Gangs.Notify("Rank weight must be a number.") return 1 end
	local rounded = math.Round(num)
	if rounded and rounded > 0 and rounded < 8 then
		return rounded
	end
	Gangs.Notify("Rank weight must be inbetween 1 and 7.")
	return -1
end

local function CanCreateRank(name)
	local gang = LocalPlayer():GetGang()
	if Gangs.Cache.RankCount(gang) >= (Gangs.Cache.GetMaxRanks(gang) + table.Count(Gangs.DefaultRanks)) then
		Gangs.Notify("Your gang has hit its rank limit.")
		return false
	elseif Gangs.Cache.RankExists(gang, name) then
		Gangs.Notify("That rank already exists.")
		return false
   	elseif string.len(name) < 2 and string.len(name) > 10 then
        Gangs.Notify("Rank name length must be between 2 and 10.", ply)
		return false
	end
	return true
end

local function UpdateUIWithNewRank(selection, newRank) -- use this for instant feedback to ui
	selection:AddOptions(newRank, function(option, key, value)
		option:SetText(key)
		option.Style = function(self, w, h, col)
			local weight = value["weight"]
			local color = HSVToColor(weight * 90, weight * 0.25, weight * 0.25)
			draw.Gradient(self, selection, w - 2, h, color, 0.25, "right",Color(50, 50, 50, col.a) , 1, 1)
		end
	end)
end

local function CreateSelection(panel)
	local selection = vgui.Create("dank_ui.selection", panel)
	selection:SetSize(panel:GetSize())
	selection:SetOptionHeight(50)
	local ranks = table.Merge(Gangs.Cache.GetRanks(LocalPlayer():GetGang()), Gangs.DefaultRanks)
	ranks["owner"] = {["weight"] = 10}
	selection:AddOptions(ranks, function(option, key, value)
		option:SetText(key)
		option.Style = function(self, w, h, col)
			local weight = istable(value) and value["weight"]
			local color = key == "owner" and HSVToColor(360, 1, 1) or HSVToColor(weight * 90, weight * 0.18, weight * 0.18)
			draw.Gradient(self, panel, w - 2, h, color, 0.25, "right",Color(50, 50, 50, col.a) , 1, 1)
		end
	end, SortedPairsByMemberValue, "weight", true)
	return selection
end

local function CreateNewRank(flags, weight, selection, name)
	local weightValue = GetWeight(weight:GetValue())
	local args = table.GetKeys(flags)
	table.insert(args, 1, name)
	table.insert(args, 2, weightValue)
	RunConsoleCommand("gw_create_rank", unpack(args))
	flags["weight"] = weightValue
	local newRank = {[name] = flags}
	UpdateUIWithNewRank(selection, newRank)
end

local function CreateRankMenu(name, selection, entry)
	if name == "" then Gangs.Notify("Please enter a valid gang name.") return end
	if Gangs.Cache.GetRanks(LocalPlayer():GetGang())[name] then Gangs.Notify("That rank already exists!") return end

	local frame = vgui.Create("dank_ui.frame")
	frame:SetSize(200, 300)
	frame:Center()
	frame:SetTitle(name)

	local flags = {}
	local next_y = 30
	for k, v in pairs(Gangs.Permissions.Flags) do
		local btn = vgui.Create("DButton", frame)
		btn:SetSize(frame:GetWide(), 30)
		btn:SetPos(0, next_y)
		btn:SetText(v)
		btn.textColor = DankUI.Red
		btn.DoClick = function()
			if flags[k] then
				flags[k] = nil
				btn.textColor = DankUI.Red
			else
				flags[k] = true
				btn.textColor = Color(50, 150, 50)
			end
		end
		next_y = next_y + btn:GetTall()
	end

	local weight = vgui.Create("DTextEntry", frame) 
	weight:SetValue("rank weight (1-7)")
	weight:SetNumeric(true)
	weight:SetSize(frame:GetWide(), 30)
	weight:SetPos(0, next_y)
	next_y = next_y + weight:GetTall()

	local finish = vgui.Create("DButton", frame)
	finish:SetSize(weight:GetSize())
	finish:SetPos(0, next_y)
	finish:SetText("Finish")
	finish.DoClick = function()
		if !CanCreateRank(name) then return end
		CreateNewRank(flags, weight, selection, name)
		entry:Remove()
		frame:Close()
	end

	frame:SetTall(finish.y + finish:GetTall())
	frame:Center()
end

local weight_value = nil

function Gangs.CreateRanksPage(panel)
	local selection = CreateSelection(panel)
	local create = Gangs.CreateCommandButton("Create", "r", selection, function(self)
		local entry = vgui.Create("dank_ui.entry")
		entry:SetQuestion("Enter the name of the rank.")
		entry.OnYes = function(s, v)
			CreateRankMenu(string.Trim(v), selection, entry)
		end
	end)
	selection:AddEndButton(create, selection)

	selection.OnSelect = function(self, option)
		addedTbl = {}
		removedTbl = {}
		local weight
		local update = Gangs.CreateCommandButton("Update", "r", self.selected, function(self)
			local args = table.Add(table.GetKeys(addedTbl), table.GetKeys(removedTbl))		
			table.insert(args, 1, option:GetText())
			if Gangs.DefaultRanks[option:GetText()] then
				Gangs.Notify("You cannot edit default ranks.")
				return
			end
			if !weight_value then return end
			table.insert(args, 2, weight_value)
			if #args > 0 then
				RunConsoleCommand("gw_update_rank", unpack(args))
				addedTbl = {}
				removedTbl = {}

				selection.Weight:SetText("Weight: " .. weight_value)
			end
		end)
		update:SetSize(self.selected:GetWide() + 2, 30)
		update:SetPos(-1, self.selected:GetTall() - update:GetTall())

		local delete = Gangs.CreateCommandButton("Delete", "d", self.selected, function(self)
			if Gangs.DefaultRanks[option:GetText()] then
				Gangs.Notify("You cannot delete default ranks.")
			else
				RunConsoleCommand("gw_delete_rank", option:GetText())
				selection.selected:Remove()
				option:Remove()
			end
		end)
		delete:SetSize(self.selected:GetWide() + 2, 30)
		delete:SetPos(-1, update.y - update:GetTall() + 1)

		local weight = vgui.Create("DButton", self.selected)
		weight:SetSize(delete:GetSize())
		weight:SetPos(-1, delete.y - delete:GetTall() + 1)
		local current_weight = (option.data == "*" and "*" or math.Round(option.data["weight"]))
		weight:SetText("Weight: " .. current_weight)
		weight_value = current_weight
		weight.DoClick = function()
			local entry = vgui.Create("dank_ui.entry")
			entry:SetQuestion("What weight would you now like? (1-7)")
			entry.OnYes = function(s, v)
				weight_value = GetWeight(v)
			end
		end
		selection.Weight = weight

		local startY = weight.y - weight:GetTall()

		local added = DankUI.CreateLabel(self.selected, "Added: none", "dank_ui.medium")
		added:SetPos(self.selected:GetWide() / 2 - added:GetWide() / 2,  startY - 10)

		local removed = DankUI.CreateLabel(self.selected, "Removed: none", "dank_ui.medium")
		removed:SetPos(self.selected:GetWide() / 2 - removed:GetWide() / 2, added.y - added:GetTall())

		CreateFlagButtons(self, option, added, removed, startY)
	end
end