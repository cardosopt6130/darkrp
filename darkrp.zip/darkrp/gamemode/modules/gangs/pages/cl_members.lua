--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_members.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local function UpdateRank(rank, option)
	if Gangs.Permissions.CanTarget(gang, option.data.rank) and LocalPlayer():SteamID64() != option.data.steamid then
		RunConsoleCommand("gw_set_rank", option.data.steamid, rank) 
		option:SetText(rank .. " | " .. option.data.name)
	else
		Gangs.Notify("You cannot target " .. option.data.name .. "!")
	end
end

local spacing = 20

local function CreateCommandButton(name, flag, parent, doClick)
	local buttonW = (parent:GetWide() - spacing) * 0.5
	local btn = vgui.Create("DButton", parent)
	btn:SetSize(buttonW - spacing, 30)
	btn:SetEnabled(Gangs.Permissions.HasPermission(flag))
	btn:SetText(name)
	btn.DoClick = doClick
	return btn
end

local function SortMembersByRankWeight(members)
	local sorted = {}
	local gang = LocalPlayer():GetGang()
	for k, v in pairs(members) do
	    v.weight = Gangs.Cache.GetRankWeight(gang, v.rank)
		table.insert(sorted, v)
	end
	table.SortByMember(sorted, "weight", false)
	return sorted
end

local function GetGangMembers(gang)
	local members = {}
	for k, v in pairs(Gangs.Cache.GetMembers(gang)) do
		v.steamid = k
		table.insert(members, v)
	end
	return SortMembersByRankWeight(members)
end

function Gangs.CreateMembersPage(panel)
	local gang = LocalPlayer():GetGang()
	Gangs.Cache.RemoveDeadRanks(gang)
	local selection = vgui.Create("dank_ui.selection", panel)
	selection:SetSize(panel:GetSize())
	selection:AddOptions(GetGangMembers(gang), function(option, key, value)
		option:SetText(value.rank .. " | " .. value.name)
		local ranks = table.Merge(Gangs.Cache.GetRanks(LocalPlayer():GetGang()), Gangs.DefaultRanks)
		option.Style = function(self, w, h, col)
			local rank = ranks[value.rank]
			local weight = istable(rank) and rank["weight"]
			local color = value.rank == "owner" and HSVToColor(360, 1, 1) or HSVToColor(weight * 90, weight * 0.18, weight * 0.18)
			draw.Gradient(self, panel, w - 2, h, color, 0.25, "right",Color(50, 50, 50, col.a) , 1, 1)
		end
	end)

	selection.OnSelect = function(self, option)
		local wealth = DankUI.CreateLabel(self.selected, "Wealth: " .. DarkRP.formatMoney(option.data.wealth), "dank_ui.medium")
		wealth:SetContentAlignment(5)
		self.selected:AddItem(wealth)
		local kick = Gangs.CreateCommandButton("Kick", "k", self.selected, function()
			if Gangs.Permissions.CanTarget(gang, option.data.rank) and LocalPlayer():SteamID64() != option.data.steamid then
				RunConsoleCommand("gw_kick", option.data.steamid)
				option:Remove()
				self.selected:Remove()
			else
				Gangs.Notify("You cannot target " .. option.data.name .. "!")
			end
		end)
		kick:SetPos(20, wealth.y + wealth:GetTall() + 10)
		self.selected:AddItem(kick)

		local setRank = Gangs.CreateCommandButton("Set rank", "s", self.selected, function()
			local ranks = DermaMenu()
			for k, v in pairs(Gangs.Cache.GetRanks(gang)) do
				ranks:AddOption(k, function() 
					local confirm = vgui.Create("dank_ui.confirm")
					if k == "owner" then
						confirm:SetQuestion("Are you sure you want to transfer your ownership?\nYou will be set to a member.")
					else
						confirm:SetQuestion("Are you sure you want to set this persons rank to\n" .. k .. "?")
					end
					confirm.OnYes = function()
						UpdateRank(k, option) 
						confirm:Remove()
					end
				end)
			end
			ranks:Open()
		end)
		setRank:SetPos(kick.x + kick:GetWide() + spacing, kick.y)
		self.selected:AddItem(setRank)
	end
end