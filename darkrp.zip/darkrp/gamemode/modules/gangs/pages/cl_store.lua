--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/pages/cl_store.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local red = table.Copy(DankUI.Red)
red.a = 100

local function RequestArgs(gang, item_id, item, cback)
	local frame = vgui.Create("dank_ui.frame")
	frame:SetSize(300, 400)
	frame:Center()
	frame:SetTitle("Item Options")
	if item.args[1] == "color" then
		local gang_col = Gangs.GetColor(gang)
		local ex = vgui.Create("DPanel", frame)
		ex:SetSize(frame:GetWide(), 30)
		ex:SetPos(1, 31)
		ex.Paint = function()
			draw.SimpleTextOutlined(gang, "lol", ex:GetWide() / 2, ex:GetTall() / 2, gang_col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, color_black)
		end

		local picker = vgui.Create("DColorMixer", frame)
		picker:SetAlphaBar( false )
		picker:SetPalette( false )
		picker:SetSize(frame:GetWide() - 20, 200)
		picker:SetPos(10, ex.y + ex:GetTall() + 5)
		picker.ValueChanged = function(s, col)
			gang_col = col
		end

		local btn = vgui.Create("DButton", frame)
		btn:SetSize(frame:GetWide() - 20, frame:GetTall() * 0.25)
		btn:SetPos(10, picker.y + picker:GetTall() + 10)
		btn:SetText("Buy")
		btn.DoClick = function()
			local arg = Gangs.ColorToString(gang_col)
			cback(arg)
			frame:Close()	
		end
	elseif item.args[1] == "string" then
		local scroll = vgui.Create("dank_ui.scroll", frame)
		scroll:SetSize(frame:GetWide(), frame:GetTall() - 30)
		scroll:SetPadding(-1)
		scroll:SetPos(0, 30)
		for k, v in pairs(Cloud.Zone.MapAreas) do
			local btn = vgui.Create("DButton", scroll)
			scroll:AddItem(btn)
			btn:SetHeight(60)
			btn:SetText(k)
			btn.DoClick = function()
				cback(k)
				frame:Close()
			end
		end
	end
end

local function DrawUI(gang, items, frame, panel)
	local current_credits = Gangs.Cache.GetCredits(gang)
	local credits = DankUI.CreateLabel(panel, "Credits: " .. current_credits, "dank_ui.medium")
	credits:SetPos(10, 0)

    local scroll = vgui.Create("dank_ui.scroll", panel)
    scroll:SetSize(panel:GetWide() - 20, panel:GetTall() - (10 + credits:GetTall()))
	scroll:SetPadding(-1)
    scroll:SetPos(10, credits.y + credits:GetTall())

	local layout = vgui.Create("DIconLayout", scroll)
	layout:SetSize(scroll:GetSize())
	layout:SetSpaceX(10)
	layout:SetSpaceY(10)
	scroll:AddItem(layout)

	for k, v in pairs(Gangs.Store.Items) do
		local item = layout:Add("DPanel")
		item:SetSize((layout:GetWide() - 10) / 2, scroll:GetTall() * 0.2)

		local highlight = vgui.Create("DPanel", item)
		highlight:SetSize(item:GetWide(), 30)
		local color = Gangs.GetColor(LocalPlayer():GetGang())
		highlight.Paint = function(s, w, h)
			draw.RoundedBox(0, 0, 0, w, h, color != color_white and color or red)
		end

		local name = DankUI.CreateLabel(item, v.name, "dank_ui.20")
		name:SetPos(10, 5)	

		highlight:SetHeight(name:GetTall() + 10)

		local desc = DankUI.CreateLabel(item, v.desc, "dank_ui.small")
		desc:SetPos(10, highlight.y + highlight:GetTall() + 10)	

		local has_item = table.HasValue(items, k)
		local buy = Gangs.CreateCommandButton(!has_item and "Buy" or "Owned", "c", item, function(self)
			if Gangs.Store.CanAfford(k, gang) then
				if v.args then
					RequestArgs(gang, k, v, function(arg)
						RunConsoleCommand("gw_store_buy", k, arg)
						credits:SetText("Credits: " .. current_credits - v.price)
						self:SetText("Owned")
						self:SetEnabled(false)
					end)
				else
					RunConsoleCommand("gw_store_buy", k)
					credits:SetText("Credits: " .. current_credits - v.price)
					self:SetText("Owned")
					self:SetEnabled(false)
				end
			else
				Gangs.Notify("You cannot afford this.")
			end
		end)
		buy:SetSize(item:GetWide() * 0.25, 50)
		buy:SetPos(item:GetWide() - buy:GetWide() - 10, item:GetTall() - buy:GetTall() - 10)
		buy:SetEnabled(!has_item)

		local price = DankUI.CreateLabel(item, v.price .. " credits", "dank_ui.medium")
		price:SetPos(10, item:GetTall() - price:GetTall() - 10)
	end
end

function Gangs.CreateStorePage(frame, panel)
	local gang = LocalPlayer():GetGang()
	DrawUI(gang, Gangs.Cache.GetItems(gang), frame, panel)
end