--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_terms.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local termIDs = {
    ["name_taken"] = {id = 0, msg = "That name is taken!"},
    ["cannot_afford"] = {id = 1, msg = "You cannot afford this."},
    ["leave_current_gang"] = {id = 2, msg = "You must leave your current gang first."},
    ["command_cooldown"] = {id = 3, msg = "You're using commands too fast!"}
}

local termMsgs = {}
for k, v in pairs(termIDs) do
    termMsgs[v.id] = v.msg
end

local function GetTermID(term)
    return termIDs[term].id
end

if SERVER then
    util.AddNetworkString("Gangs.Term")
    function Gangs.Term(ply, term)
        net.Start("Gangs.Term")
            net.WriteUInt(GetTermID(term), 4)
        net.Send(ply)
    end

    util.AddNetworkString("Gangs.Notify")
    function Gangs.Notify(receivers, msg)
        net.Start("Gangs.Notify")
            net.WriteString(msg)
        net.Send(receivers)
    end

    function Gangs.NotifyAll(msg)
        net.Start("Gangs.Notify")
            net.WriteString(msg)
        net.Broadcast()
    end
elseif CLIENT then
    function Gangs.Notify(term)
        chat.AddText(Color(200, 50, 50), "Gangs | ", Color(250, 250, 250), term)
    end

    function Gangs.Term(term)
        local term_id = GetTermID(term)
        Gangs.Notify(termMsgs[term_id])
    end

    net.Receive("Gangs.Term", function()
        local termID = net.ReadUInt(4)
        Gangs.Notify(termMsgs[termID])
    end)

    net.Receive("Gangs.Notify", function()
        Gangs.Notify(net.ReadString())
    end)
end