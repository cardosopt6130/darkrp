--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_store.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Gangs.Store = Gangs.Store or {}

if SERVER then
    function Gangs.Store.Colour(gang, args)
        local color = Gangs.StringToColor(args[1])
        if color then
            Gangs.UpdateColor(gang, color)
        end
    end

    function Gangs.Store.BuffZone(gang, args)
        local zone = args[1]
        if zone then
            Cloud.Zone.AdjustPrinters(3600, 0.3, zone) 
        end
    end

    function Gangs.Store.ChargeArea(gang, args)
        local zone = args[1]
        if zone then
            Cloud.Zone.ChargeArea(3600, zone) 
        end
    end
end

Gangs.Store.Items = {
    ["change_colour"] = {price=35, on_buy=Gangs.Store.Colour, save=false, name="Gang Colour", desc="Change your gangs colour.", args={[1] = "color"}},
    ["gold_sign"] = {price=30, on_buy=false, save=true, name="Gold Sign", desc="Makes your gangs sign gold and flashy."},
    ["gold_moonshine"] = {price=30, on_buy=false, save=true, name="Gold Moonshine", desc="Makes your moonshine stove gold and flashy."},
    ["gold_metal_detector"] = {price=30, on_buy=false, save=true, name="Gold Metal Detector", desc="Makes your metal detector gold and flashy."},
    ["color_doors"] = {price=150, on_buy=false, save=true, name="Gang Colored Doors", desc="Makes your gangs doors your gang color."},
    ["gold_weed_box"] = {price=20, on_buy=false, save=true, name="Gold Weed Box", desc="Makes your weed box gold, the ultimate flex."},
    ["gang_dealer"] = {price=50, on_buy=false, save=true, name="Gang Dealer", desc="Get access to exclusive weapons with a new job."},
    ["anti_ithaca"] = {price=100, on_buy=false, save=true, name="Anti Ithaca", desc="Makes your gang doors ithaca resistent."},
    ["lockpick_slow"] = {price=65, on_buy=false, save=true, name="Lockpick Slow", desc="Doubles the time it takes to lockpick your gangs doors."},
    ["extra_pots"] = {price=160, on_buy=false, save=true, name="Extra Weed Grow", desc="Allows you to use more grow formula."},
    ["extra_moonshine"] = {price=160, on_buy=false, save=true, name="Extra Brewer", desc="Get an extra moonshine brewer."},
    ["25_weed_limit"] = {price=65, on_buy=false, save=true, name="+10% Weed Price", desc="Earn an extra 10% when selling weed."},
    ["printer_50_zone"] = {price=10, on_buy=Gangs.Store.BuffZone, save=false, name="30% Printer Zone Boost", desc="Pick a zone to boost all printers in by 30% for 1 hour.", args={[1] = "string"}},
    ["printer_charge_1hour"] = {price=5, on_buy=Gangs.Store.ChargeArea, save=false, name="Permanent Printer Charge Zone", desc="Pick a zone to permanently charge printers for 1 hour.", args={[1] = "string"}}
}

function Gangs.Store.CanAfford(item_id, gang)
    local credits = Gangs.Cache.GetCredits(gang)
    local item = Gangs.Store.Items[item_id]
    return credits >= item.price
end

function Gangs.Store.ItemExists(item_id)
    return Gangs.Store.Items[item_id] != nil
end

local function HasItem(pl, item_id)
	return CLIENT or SERVER and (pl:GetGang() and Gangs.Cache.HasItem(pl:GetGang(), item_id))
end

local function BadPermissions(raid, mug, kidnap)
	return {
		["Can raid"] = raid,
		["Can mug"] = mug,
		["Can kidnap"] = kidnap
	}
end

local player_GetAll = player.GetAll
local function GangBossIsFree(gang, max)
    local count = 0
    for k, v in pairs(player_GetAll()) do
        if v:Team() == TEAM_GANGBOSS and v:GetGang() == gang then
            count = count + 1
            if count == max then
                return false
            end
        end
    end
    return true
end

local function GangBossCheck(ply)
    local gang = ply:GetGang()
	if !gang then return false end
    local level = Gangs.Cache.GetLevel(gang)
	local permanent_levels = Gangs.Cache.GetPermanentLevels(gang)
    if level and (level >= 16 || permanent_levels[16]) then
		local max = 1
		if level >= 22 || permanent_levels[22] then
			max = max + 1
		end
		if level >= 23 || permanent_levels[23] then
			max = max + 1
		end
        return GangBossIsFree(gang, max)
    end
    return false
end

hook.Add("DarkRPFinishedLoading", "Gangs.Job", function()
    TEAM_GANGWEP = AddExtraTeam("Gang Dealer", {
        color = Color(255, 102, 178),
        model = "models/player/eli.mdl",
        description = [[Your gang is getting somewhere. You need your own supplies.]],
        weapons = {},
        command = "gangdealer",
        permissions = BadPermissions(false, false, false),
        max = 5,
        salary = 0,
        admin = 0,
        vote = false,
        chief = false,
        canDemote = false,
        hasLicense = true,
        customCheck = function(ply) return HasItem(ply, "gang_dealer") end,
        CustomCheckFailMsg = "Your gang has not unlocked this job.",
        PlayerLoadout = function( ply ) return ply:SetArmor( 100 ) end,
        category = "The Bad"
    })

    TEAM_GANGBOSS = AddExtraTeam("Gang Boss", {
        color = Color(255, 102, 102),
        model = "models/player/gman_high.mdl",
        description = [[The gang boss.]],
        weapons = {},
        command = "gangboss",
        permissions = BadPermissions(true, true, true),
        max = 20,
        salary = 0,
        admin = 0,
        vote = false,
        chief = false,
        canDemote = false,
        hasLicense = true,
        customCheck = GangBossCheck,
        CustomCheckFailMsg = "Your gang has not unlocked this job or someone in your gang is already using it.",
        PlayerLoadout = function( ply ) return ply:SetArmor( 100 ) end,
        category = "The Bad"
    })

	if SERVER then
        local jobs 
        hook.Add("PostPlayerLoadout", "Gangs.LoadOut", function(ply)
            if !istable(jobs) then
                jobs = {
                    [TEAM_GANG] = true,
                    [TEAM_MOB] = true,
                    [TEAM_THIEF] = true,
                    [TEAM_MTHEIF] = true,
                    [TEAM_GANGBOSS] = true,
                    [TEAM_GANGWEP] = true
                }
            end
            local gang = ply:GetGang()
            if gang and !ply:isCP() and jobs[ply:Team()] then
                local level = Gangs.Cache.GetLevel(gang)
                if level >= 1 then
                    for i=1, level do
						if !Gangs.Config.Levels[i] then break end
                        local loadout = Gangs.Config.Levels[i].loadout
                        if loadout then
                            loadout(ply)
                        end
                    end
                end
				for k, v in pairs(Gangs.Cache.GetPermanentLevels(gang)) do
					if k > level then
                        local loadout = Gangs.Config.Levels[k].loadout
                        if loadout then
                            loadout(ply)
                        end
					end
				end
            end
			if ply:GetNetVar("gang") == 178 && (ply:GetNetVar("gangRank") == "Capo" || ply:GetNetVar("gangRank") == "Underboss" || ply:GetNetVar("gangRank") == "owner") then
				ply:GivePermWeapon("mac_bo2_exec")
			end
			if ply:GetNetVar("gang") == 2472 then
				ply:GivePermWeapon("weapon_m4a1_beast")
				ply:GivePermWeapon("mac_bo2_xpr50")
			end
        end)
	end

	local allowed = {TEAM_GANGWEP}

    DarkRP.createShipment("M4A1 CSS", {
        model = "models/weapons/w_rif_m4a1.mdl",
        entity = "bb_m4a1",
        price = 212500,
        amount = 10,
        separate = true,
        pricesep = 25000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("TMP", {
        model = "models/weapons/w_smg_tmp.mdl",
        entity = "bb_tmp",
        price = 153000,
        amount = 10,
        separate = true,
        pricesep = 18000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("USP", {
        model = "models/weapons/w_pist_usp.mdl",
        entity = "bb_usp",
        price = 85000,
        amount = 10,
        separate = true,
        pricesep = 10000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Bizon", {
        model = "models/weapons/w_pp19_bizon.mdl",
        entity = "m9k_bizonp19",
        price = 127500,
        amount = 10,
        separate = true,
        pricesep = 15000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Double Barrel", {
        model = "models/weapons/w_double_barrel_shotgun.mdl",
        entity = "m9k_dbarrel",
        price = 425000,
        amount = 10,
        separate = true,
        pricesep = 50000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Dragunov", {
        model = "models/weapons/w_svd_dragunov.mdl",
        entity = "m9k_dragunov",
        price = 340000,
        amount = 10,
        separate = true,
        pricesep = 40000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Scoped Taurus", {
        model = "models/weapons/w_raging_bull_scoped.mdl",
        entity = "m9k_scoped_taurus",
        price = 59500,
        amount = 10,
        separate = true,
        pricesep = 7000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Browning Auto", {
        model = "models/weapons/w_browning_auto.mdl",
        entity = "m9k_browningauto5",
        price = 170000,
        amount = 10,
        separate = true,
        pricesep = 20000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("USAS", {
        model = "models/weapons/w_usas_12.mdl",
        entity = "m9k_usas",
        price = 212500,
        amount = 10,
        separate = true,
        pricesep = 25000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("VAL", {
        model = "models/weapons/w_dmg_vally.mdl",
        entity = "m9k_val",
        price = 170000,
        amount = 10,
        separate = true,
        pricesep = 20000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
    DarkRP.createShipment("Winchester 73", {
        model = "models/weapons/w_winchester_1873.mdl",
        entity = "m9k_winchester73",
        price = 212500,
        amount = 10,
        separate = true,
        pricesep = 25000,
        noship = false,
        allowed = allowed,
	    category = "Weapons"
    })
end)