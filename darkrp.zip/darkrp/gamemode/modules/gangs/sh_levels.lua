--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_levels.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

if CLIENT then
	local player_GetAll = player.GetAll
	local pairs = pairs
    local gang_esp = CreateClientConVar("cg_gang_esp", 0)
	local hook_added = false
    function Gangs.AddESPHook()
		if hook_added then return end
        hook.Add("HUDPaint", "Gangs.ESP", function()
            if !gang_esp:GetBool() then return end
            if LocalPlayer():InEvent() then return end
			if LocalPlayer():IsCloaked() then return end
            local gang = LocalPlayer():GetGang()
            local level = gang and Gangs.Cache.GetLevel(gang)
            if level and (Gangs.HasLevel(gang, 13) || Gangs.Cache.GetPermanentLevels(gang)[13]) then
                for k, e in pairs(player_GetAll()) do
                    if e != LocalPlayer() and e:GetGang() == gang then
                        if (LocalPlayer():isCP() or e:isCP()) then
                            if (!LocalPlayer():isCP() and e:isCP()) then continue end
                            if (!e:isCP() and LocalPlayer():isCP()) then continue end
                        end
                        if e:Team() == TEAM_ADMIN or e:Team() == TEAM_MOD then continue end
                        Cloud.DrawESP(e, false, true)
                    end
                end
            end
        end)
		hook_added = true
    end
end

local function AddMemberSlots(amount)
    return SERVER and function(gang) Gangs.UpdateMaxSlots(gang, amount) end
end

local function AddToMaxRanks(amount)
    return SERVER and function(gang) Gangs.UpdateMaxRanks(gang, amount) end
end

function Gangs.HasLevel(gang, level)
	return Gangs.Cache.GetLevel(gang) >= level || Gangs.Cache.GetPermanentLevels(gang)[level]
end

function PLAYER:GivePermWeapon(wep)
    local wep = self:Give(wep)
    if IsValid(wep) then
        wep.Permawep = true
    end
end

Gangs.Config.Levels = {
    [1] = {
        name = "Spawn with an unarrest baton",
        price = 750000,
        power = 5,
        loadout = function( ply )
            ply:GivePermWeapon( "unarrest_stick" )
        end
    },
    [2] = {
        name = "Spawn in with 50 armour",
        price = 2000000,
        power = 10,
        loadout = function( ply )
            ply:SetArmor( 50 )
        end
    },
    [3] = {
        name = "Unlock another printer",
        power = 10,
        price = 7500000
    },
    [4] = {
        name = "Gang spawns with a Tommy Gun",
        price = 10000000,
        power = 10,
        loadout = function( ply )
            ply:GivePermWeapon( "m9k_thompson" )
        end
    },
    [5] = {
        name = "Unlocks 5 more member slots",
        buyFunc = AddMemberSlots(5),
        price = 10000000,
        power = 10,
    },
    [6] = {
        name = "+10 power",
        price = 10000000,
        power = 10
    },
    [7] = {
        name = "Unlocks 5 more member slots",
        buyFunc = AddMemberSlots(5),
        price = 15000000,
        power = 10,
    },
    [8] = {
        name = "Gang spawns with 100 armor",
        power = 10,
        loadout = function( ply )
            ply:SetArmor( 100 )
        end,
        price = 25000000
    },
    [9] = {
        name = "Gang spawns with a hammer",
        power = 10,
        price = 30000000,
        loadout = function(ply)
            ply:GivePermWeapon("wp_hammer")
        end
    },
    [10] = {
        name = "Unlocks 5 more member slots.",
        buyFunc = AddMemberSlots(5),
        power = 20,
        price = 40000000,
    },
    [11] = {
        name = "Gang spawns with a pickaxe",
        price = 50000000,
        power = 20,
        loadout = function(ply)
            ply:GivePermWeapon("pickaxe")
        end
    },
    [12] = {
        name = "Unlocks another 2 custom ranks",
        price = 50000000,
        buyFunc = AddToMaxRanks(2),
        power = 20
    },
    [13] = {
        name = "Gang ESP",
        price = 50000000,
        power = 30
    },
    [14] = {
        name = "Unlocks another 2 custom ranks",
        price = 50000000,
        buyFunc = AddToMaxRanks(2),
        power = 30
    },
    [15] = {
        name = "Gang spawns with a css source knife",
        price = 50000000,
        power = 10,
        loadout = function(ply)
            ply:GivePermWeapon("csgo_cssource")
        end
    },
    [16] = {
        name = "Unlock gang boss job",
        price = 50000000,
        power = 10,
    },
    [17] = {
        name = "Unlock bhop swep for gang boss job",
        price = 75000000,
        power = 10,
        loadout = function(ply)
            if ply:Team() == TEAM_GANGBOSS then
                ply:GivePermWeapon("bhop_swep")
            end
        end
    },
    [18] = {
        name = "Unlocks another custom rank",
        price = 75000000,
        buyFunc = AddToMaxRanks(1),
        power = 10
    },
    [19] = {
        name = "Unlock disguise kit for gang boss",
        price = 75000000,
        power = 10,
        loadout = function(ply)
            if ply:Team() == TEAM_GANGBOSS then
                ply:GivePermWeapon("diguisekit")
            end
        end
    },
    [20] = {
        name = "Unlocks another custom rank",
        price = 100000000,
        buyFunc = AddToMaxRanks(1),
        power = 10
    },
    [21] = {
        name = "Unlock PKM for gang boss",
        price = 100000000,
        power = 10,
        loadout = function(ply)
            if ply:Team() == TEAM_GANGBOSS then
                ply:GivePermWeapon("m9k_pkm")
            end
        end
    },
    [22] = {
        name = "+1 gang boss slot",
        price = 100000000,
        power = 20,
    },
    [23] = {
        name = "+1 gang boss slot",
        price = 100000000,
        power = 20,
    },
    [24] = {
        name = "Unlock dragon lore for gang boss",
        price = 200000000,
        power = 10,
        loadout = function(ply)
            if ply:Team() == TEAM_GANGBOSS then
                ply:GivePermWeapon("awpdragon")
            end
        end
    },
    [25] = {
        name = "Prestige",
        price = Gangs.Config.PrestigeCost,
        power = 10,
		prestige = true,
    },
}

Dev.Command("gang_level_total", function(ply)
	local total = 0
	for k, v in pairs(Gangs.Config.Levels) do
		total = total + v.price
	end
	print(DarkRP.formatMoney(total))
end)

local base_url = "http://cloud-gaming.co.uk/darkrp/calling_cards/"

local card_options = {
	["african"] = base_url .. "ui_playercard_376.png",
	["golem"] = base_url .. "ui_playercard_324.png",
	["discovery"] = base_url .. "ui_playercard_t9287.png",
	["heartade"] = base_url .. "ui_playercard_003.png",
	["skull"] = base_url .. "ui_playercard_035.png",
	["airbourne"] = base_url .. "ui_playercard_071.png",
	["spider"] = base_url .. "ui_playercard_125.png",
	["godzilla"] = base_url .. "ui_playercard_606.png",
	["space"] = base_url .. "ui_playercard_653.png",
	["action"] = base_url .. "ui_playercard_670.png",
	["bear"] = base_url .. "ui_playercard_1050.png",
	["street"] = base_url .. "ui_playercard_t9474_v6.png",
	["jungle"] = base_url .. "ui_playercard_t9625.png",
	["gold_sniper"] = base_url .. "ui_playercard_mc_gold_sn_alpha50.png",
	["cartoon_shooter"] = base_url .. "ui_playercard_t91012.png",
	["skull_blue"] = base_url .. "ui_playercard_t9768.png",
	["anime"] = base_url .. "ui_playercard_1413.png",
	["airdrop"] = base_url .. "ui_playercard_t91406.png",
	["skydive"] = base_url .. "ui_playercard_t91060.png",
	["cinema_shootout"] = base_url .. "ui_playercard_t9332.png",
	["miami_bond"] = base_url .. "ui_playercard_t91019.png",
	["mist_fight"] = base_url .. "ui_playercard_t91099_sy.png",
	["skull_samurai"] = base_url .. "ui_playercard_t9599_v1.png",
	["skull_destroyer"] = base_url .. "ui_playercard_t9770.png",
	["future_dreads"] = base_url .. "ui_playercard_t9600_v4.png",
}

Gangs.Materials = {}
for id, str in pairs( list.Get( "OverrideMaterials" ) ) do
	if ( !table.HasValue( Gangs.Materials, str ) ) then
		table.insert( Gangs.Materials, str )
	end
end

function Gangs.PlayersGangHasItem(ply, item_id) 
	return ply:GetGang() && Gangs.Cache.HasItem(ply:GetGang(), item_id)
end

Gangs.CardInts = {}
for k, v in pairs(card_options) do
	local int = CallingCards.Register(k, v, Gangs.PlayersGangHasItem)
	if int then
		Gangs.CardInts[int] = true
	end
end

local player_models = {
	"models/player/Suits/male_01_closed_tie.mdl",
	"models/player/Suits/male_01_open.mdl",
	"models/player/Suits/male_01_open_waistcoat.mdl",
	"models/player/Suits/male_01_shirt_tie.mdl",
	"models/player/Suits/male_02_closed_tie.mdl",
	"models/player/Suits/male_02_open.mdl",
	"models/player/Suits/male_02_open_waistcoat.mdl",
	"models/player/Suits/male_02_shirt_tie.mdl",
	"models/player/Suits/male_03_closed_tie.mdl",
	"models/player/Suits/male_03_open.mdl",
	"models/player/Suits/male_03_open_waistcoat.mdl",
	"models/player/Suits/male_03_shirt_tie.mdl",
	"models/player/Suits/male_04_closed_tie.mdl",
	"models/player/Suits/male_04_open.mdl",
	"models/player/Suits/male_04_open_waistcoat.mdl",
	"models/player/Suits/male_04_shirt_tie.mdl",
	"models/player/Suits/male_05_closed_tie.mdl",
	"models/player/Suits/male_05_open.mdl",
	"models/player/Suits/male_05_open_waistcoat.mdl",
	"models/player/Suits/male_05_shirt_tie.mdl",
	"models/player/Suits/male_06_closed_tie.mdl",
	"models/player/Suits/male_06_open.mdl",
	"models/player/Suits/male_06_open_waistcoat.mdl",
	"models/player/Suits/male_06_shirt_tie.mdl",
	"models/player/Suits/male_07_closed_tie.mdl",
	"models/player/Suits/male_07_open.mdl",
	"models/player/Suits/male_07_open_waistcoat.mdl",
	"models/player/Suits/male_07_shirt_tie.mdl",
}


local function func(ply)
	return !ply:isCP() && !ply:isTerrorist() && !DarkRP.IsStaffJob(ply:Team()) && ply:Team() != TEAM_MUTANT
end

Gangs.PlayerModels = {}
for k, v in pairs(player_models) do
	Gangs.PlayerModels[v] = true
	PlayerModel.Register(v, func)
end

local accessories = {}
for i=0, 14 do
	local index = "gang_helmet_"..i
	accessories[index] = {
		name = "Helmet " .. i,
		scale = 1,
		offpos = Vector(0, 0, 4),
		offang = Angle(0, 0, 0),
		model = "/models/dean/gtaiv/helmet.mdl",
		price = 50,
		skin = i,
		category = "Gang",
		save = false,
		hidden = true,
		canSell = false,
		has_item_check = Gangs.PlayersGangHasItem,
		slot = "mask"
	}
end

Gangs.AccessoryInts = {}
Gangs.Accessories = Gangs.Accessories || {}
for id, accessory in pairs(accessories) do
	accessory.id = id
	local item = Tokens.Accessories.Create(id, accessory)
	Gangs.Accessories[id] = item
	if accessory.slot == "hat" then
		Tokens.Accessories.Hats[id] = accessory
	else
		Tokens.Accessories.Masks[id] = accessory
	end
	local int = Tokens.Accessories.CreateMapping(accessory, accessory.slot == "hat")
	Gangs.AccessoryInts[int] = true
	table.insert(Tokens.Accessories.Items, item)
end

Gangs.PrestigeColors = {
	[0] = table.Copy(DankUI.Red),
	[1] = Color(140, 0, 255),
	[2] = Color(0, 13, 255),
	[3] = Color(0, 153, 255),
	[4] = Color(0, 255, 183),
	[5] = Color(102, 255, 0),
	[6] = Color(200, 255, 0),
	[7] = Color(255, 204, 0),
	[8] = Color(255, 115, 0),
	[9] = Color(255, 60, 0),
	[10] = Color(255, 0, 0),
}

local function AddPropLimit(gang, members)
	for k, v in pairs(members) do
		v.propLimit = (v.propLimit || 0) + 5
	end
end

Gangs.PermaWeapons = {
	["mac_bo2_ksg"] = true,
	["mac_bo2_mp7"] = true,
	["mac_bo2_hk416"] = true,
	["mac_bo2_pdw"] = true,
	["mac_bo2_ballista"] = true,
	["mac_bo2_vector"] = true,
}

Gangs.Config.PrestigeShop = {
	["cosmetic"] = {options=accessories, name="Exclusive Cosmetic"},
	["weapon"] = {options=Gangs.PermaWeapons, name="Exclusive Weapon", limit=2},
	["calling_card"] = {options=card_options, name="Exclusive Calling Card", is_web_image=true},
	["gang_sign_material"] = {options=Gangs.Materials, name="Gang Sign Material",  is_material=true},
	["prop_limit"] = {name="+5 Gang Prop Limit", activate=AddPropLimit, limit=1},
	["credits"] = {activate=function(gang) Gangs.UpdateCredits(gang, 20) end, name="+20 Gang Credits", no_save=true},
	["player_model"] = {options=player_models, name="Exclusive Player Model"}
}

Gangs.Config.CreditToCash = 2750000