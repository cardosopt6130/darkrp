--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_cache.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

if Gangs.Cache then return end

Gangs.Cache = Gangs.Cache or {}

local cache = {}
local ids = {}

local cached_names = {}
local cached_ids = {}

function Gangs.Cache.GetNames()
	return cached_names
end

function Gangs.Cache.GetName(id)
	return cached_names[id] || ids[id]
end

function Gangs.Cache.GetAll()
	return cache
end

function Gangs.Cache.IDFromName(name)
	return cached_ids[name]
end

function Gangs.Cache.GetItems(gang)
    return cache[gang].items
end

function Gangs.Cache.HasItem(gang, item_id)
    return table.HasValue(cache[gang].items, item_id)
end

function Gangs.Cache.NewGang(data)
    cache[data.name] = data
    ids[data.gang_id] = data.name

	//global
	cached_names[data.gang_id] = data.name
	cached_ids[data.name] = data.gang_id
end

function Gangs.Cache.GetPrestige(gang)
	return cache[gang].prestige || 0
end

function Gangs.Cache.UpdatePrestige(gang, prestige)
	cache[gang].prestige = prestige
end

function Gangs.Cache.GetPrestigeTokens(gang)
	return cache[gang].prestige_tokens || 0
end

function Gangs.Cache.UpdatePrestigeTokens(gang, tokens)
	cache[gang].prestige_tokens = tokens
end

function Gangs.Cache.GetData(gang)
    return cache[gang]
end

function Gangs.Cache.GetMemberData(gang, steamid)
    return cache[gang].members[steamid]
end

function Gangs.Cache.IsCached(gang_id)
    return ids[gang_id] != nil
end

function Gangs.Cache.IDToName(gang_id)
    return ids[gang_id]
end

function Gangs.Cache.GetPower(gang)
    return cache[gang].power or 0
end

function Gangs.Cache.GetCredits(gang)
    return cache[gang].credits or 0
end

function Gangs.Cache.GetID(gang)
    return cache[gang].gang_id
end

function Gangs.Cache.ChangeGangName(oldName, newName)
    local data = cache[oldName]

    cache[newName] = data
    ids[data.gang_id] = newName
    cached_names[data.gang_id] = newName
    cached_ids[newName] = data.gang_id

    cached_ids[oldName] = nil
    cache[oldName] = nil
end

function Gangs.Cache.GetMOTD(gang)
    return cache[gang].motd or "Welcome!"
end

function Gangs.Cache.UpdateMOTD(gang, motd)
    cache[gang].motd = motd
end

function Gangs.Cache.GetLevel(gang)
    return cache[gang].level or 0
end

function Gangs.Cache.GetPermanentLevels(gang)
	return cache[gang].permanent_levels
end

function Gangs.Cache.GetSignMaterial(gang)
	return cache[gang].sign_material
end

function Gangs.Cache.UpdateSignMaterial(gang, mat)
	cache[gang].sign_material = mat
end

function Gangs.Cache.SpawnedPrinter(gang)
	cache[gang].spawned_printer = true
end

function Gangs.Cache.HasSpawnedPrinter(gang)
	return cache[gang].spawned_printer
end

function Gangs.Cache.GetWealth(gang)
    return cache[gang].wealth
end

function Gangs.Cache.UpdateLevel(gang, newLevel)
    cache[gang].level = newLevel
end

function Gangs.Cache.GetMembers(gang)
    return cache[gang].members
end

function Gangs.Cache.GetMaxSlots(gang)
    return cache[gang].slots
end

function Gangs.Cache.UpdateItems(gang, items)
    cache[gang].items = items
end

function Gangs.Cache.AddItem(gang, item)
    table.insert(cache[gang].items, item)
end

function Gangs.Cache.AddPlayerModel(gang, mdl)
    table.insert(cache[gang].player_models, mdl)
end

function Gangs.Cache.GetPlayerModels(gang, mdl)
    return cache[gang].player_models || {}
end

function Gangs.Cache.UpdateMaxSlots(gang, amount)
    cache[gang].slots = amount
end

function Gangs.Cache.UpdatePower(gang, power)
    cache[gang].power = power 
end

function Gangs.Cache.UpdateCredits(gang, credits)
    cache[gang].credits = credits 
end

function Gangs.Cache.GetWealth(gang)
    return cache[gang].wealth
end

function Gangs.Cache.UpdateWealth(gang, wealth)
    cache[gang].wealth = wealth
end

function Gangs.Cache.GetMaxRanks(gang)
    return cache[gang].max_ranks
end

function Gangs.Cache.GetElo(gang)
	return cache[gang].elo
end

function Gangs.Cache.SetElo(gang, elo)
	cache[gang].elo = elo
end

function Gangs.Cache.SetNumberOne(gang, status)
	cache[gang].number_one = status
end

function Gangs.Cache.IsNumberOne(gang)
	return cache[gang].number_one
end

function Gangs.Cache.UpdateMaxRanks(gang, amount)
    cache[gang].max_ranks = amount
end

function Gangs.Cache.CountOwners(gang)
    local count = 0
    for k, v in pairs(Gangs.Cache.GetMembers(gang)) do
        if v.rank == "owner" then
            count = count + 1
        end
    end
    return count
end

function Gangs.Cache.RankCount(gang)
    return table.Count(cache[gang].ranks)
end

function Gangs.Cache.GetRankWeight(gang, rank)
    if rank == "owner" then return 10 end
    if Gangs.DefaultRanks[rank] then
        return Gangs.DefaultRanks[rank]["weight"]
    end
    return cache[gang].ranks[rank]["weight"]
end

function Gangs.Cache.GetRankFlags(gang, rank)
    if Gangs.DefaultRanks[rank] then
        return Gangs.DefaultRanks[rank]
    end
    return cache[gang].ranks[rank]
end

function Gangs.Cache.GetRanks(gang)
    return cache[gang].ranks
end

function Gangs.Cache.UpdateMembersRank(gang, steamid, rank)
    cache[gang].members[steamid].rank = rank
end

function Gangs.Cache.NewRank(gang, rank, permissions)
    cache[gang].ranks[rank] = permissions
end

function Gangs.Cache.RemoveSteamID(gang, steamid)
    cache[gang].members[steamid] = nil
end

function Gangs.Cache.AddMember(gang, member, rank)
    local data = {steamid = member:SteamID64(), name = member:Name(), rank = rank, wealth = member:GetNetVar("money")}
    cache[gang].members[member:SteamID64()] = data
    return data
end

function Gangs.Cache.RankExists(gang, rank)
    return cache[gang].ranks[rank] != nil
end

function Gangs.Cache.RemoveDeadRanks(gang)
    for k, v in pairs(cache[gang].members) do
        if !Gangs.DefaultRanks[v.rank] and !Gangs.Cache.RankExists(gang, v.rank) then
            cache[gang].members[k].rank = Gangs.StartingRank
        end
    end
end

function Gangs.Cache.RemoveRank(gang, rank)
    cache[gang].ranks[rank] = nil
end

function Gangs.Cache.RemoveGang(gang)
    cache[gang] = nil
end

Gangs.Cache.NetFields = {
    ["motd"] = {id = 0, send = net.WriteString, read = net.ReadString},
    ["ranks"] = {id = 1, send = net.WriteTable, read = net.ReadTable, key = {send = net.WriteString, read = net.ReadString}},
    ["members"] = {id = 2, send = net.WriteTable, read = net.ReadTable, key = {send = net.WriteString, read = net.ReadString}},
    ["level"] = {id = 3, send = function(value) net.WriteUInt(value, 6) end, read = function() return net.ReadUInt(6) end},
    ["slots"] = {id = 4, send = function(value) net.WriteUInt(value, 6) end, read = function() return net.ReadUInt(6) end},
    ["max_ranks"] = {id = 4, send = function(value) net.WriteUInt(value, 6) end, read = function() return net.ReadUInt(6) end},
    ["power"] = {id = 5, send = function(value) net.WriteUInt(value, 8) end, read = function() return net.ReadUInt(8) end},
    ["wealth"] = {id = 6, send = function(value) net.WriteUInt(value, 32) end, read = function() return net.ReadUInt(32) end},
    ["credits"] = {id = 7, send = function(value) net.WriteUInt(value, 10) end, read = function() return net.ReadUInt(10) end},
    ["items"] = {id = 8, send = net.WriteTable, read = net.ReadTable},
    ["prestige_tokens"] = {id = 9, send = function(value) net.WriteUInt(value, 5) end, read = function() return net.ReadUInt(5) end},
    ["permanent_levels"] = {id = 10, send = net.WriteTable, read = net.ReadTable},
    ["elo"] = {id = 11, send = function(value) net.WriteUInt(value, 16) end, read = function() return net.ReadUInt(16) end},
    ["number_one"] = {id = 12, send = net.WriteBool, read = net.ReadBool},
    ["player_models"] = {id = 13, send = net.WriteTable, read = net.ReadTable},
}

Gangs.Cache.NetIDs = {}
for k, v in pairs(Gangs.Cache.NetFields) do
    Gangs.Cache.NetIDs[v.id] = k
end

if CLIENT then
    local ALL_DATA = 0
    local FIELD_UPDATE = 1
	local equip_count = 1
    net.Receive("Gang.Cache.Sync", function()
        local sync = net.ReadBit()
        if sync == ALL_DATA then
            cache[LocalPlayer():GetGang()] = net.ReadTable()
			if Gangs.Cache.GetLevel(LocalPlayer():GetGang()) >= 13 then
				Gangs.AddESPHook()
			else
				for k, v in pairs(Gangs.Cache.GetPermanentLevels(LocalPlayer():GetGang())) do
					if k == 13 then
						Gangs.AddESPHook()
						break
					end
				end
			end
			for k, item_id in pairs(Gangs.Cache.GetItems(LocalPlayer():GetGang())) do
				if GetConVar("gang_auto_equip"):GetBool() && Gangs.Config.PrestigeShop["weapon"].options[item_id] then
					timer.Simple(3 + (2*equip_count), function()
						RunConsoleCommand("gw_equip_item", "weapon", item_id)
					end)
					equip_count = equip_count + 1
				end
			end
        else
            local fieldName = Gangs.Cache.NetIDs[net.ReadUInt(4)]
			local old_var = cache[LocalPlayer():GetGang()][fieldName]
            local var = Gangs.Cache.NetFields[fieldName].read()
            cache[LocalPlayer():GetGang()][fieldName] = var 
            if fieldName == "level" then
				if var >= 13 then
                	Gangs.AddESPHook()
				end
				if var == 0 && Gangs.Config.Levels[old_var + 1] && Gangs.Config.Levels[old_var + 1].prestige then
            		cache[LocalPlayer():GetGang()]["prestige"] = cache[LocalPlayer():GetGang()]["prestige"] + 1
            		cache[LocalPlayer():GetGang()]["prestige_tokens"] = cache[LocalPlayer():GetGang()]["prestige_tokens"] + 1
				end
            end
			if fieldName == "permanent_levels" then
				for k, v in pairs(var) do
					if k == 13 then
                		Gangs.AddESPHook()
						break
					end
				end
			end
        end
    end)

    local REMOVAL = 0
    local UPDATE = 1
    net.Receive("Gangs.Cache.SyncEmbededField", function()
        local fieldName = Gangs.Cache.NetIDs[net.ReadUInt(4)]
        local sync = net.ReadBit()
        local field = Gangs.Cache.NetFields[fieldName]
        local key = field.key.read()
        if sync == UPDATE then
            local value = field.read()
            cache[LocalPlayer():GetGang()][fieldName][key] = value
        else
            cache[LocalPlayer():GetGang()][fieldName][key] = nil
        end
    end)

    net.Receive("Gangs.Cache.AllNames", function()
		cached_names = net.ReadTable()
		for id, name in pairs(cached_names) do
			cached_ids[name] = id
		end
    end)

	net.Receive("Gangs.Cache.Name", function(l, ply)
		local id = net.ReadUInt(13)
		local name = net.ReadString()

		if LocalPlayer():GetNetVar("gang") == id && Gangs.Cache.GetName(id) then // gang changed name
			local old_name = Gangs.Cache.GetName(id) 
        	cache[name] = cache[old_name]
			cache[old_name] = nil
			cached_ids[old_name] = nil
		end

		cached_names[id] = name
		cached_ids[name] = id 
	end)
end