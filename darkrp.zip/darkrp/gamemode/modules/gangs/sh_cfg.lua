--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_cfg.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Gangs = Gangs or {}

Gangs.Config = Gangs.Config or {
    CreationCost = 500000,
    NameChangeCost = 10000000,
    DefaultMaxRanks = 1,
	PrestigeCost = 500000000,
    PowerPerMember = 5
}
local player_GetAll = player.GetAll
local string_len = string.len
local get_name 
local ipairs = ipairs
local table_insert = table.insert
hook.Add("DarkRPFinishedLoading", "Gangs.Localise", function()
	get_name = Gangs.Cache.GetName
end)

DarkRP.DontLoadDirectory("modules/gangs/events")
hook.Add("Events.LoadCustom", "Gangs.Events", function()
    Cloud.Events.ReadFiles(GAMEMODE.FolderName.."/gamemode/modules/gangs/events/", true)
end)

if CLIENT then
    local spacing = 20
    function Gangs.CreateCommandButton(name, flag, parent, doClick)
        local buttonW = (parent:GetWide() - spacing) * 0.5
        local btn = vgui.Create("DButton", parent)
        btn:SetSize(buttonW - spacing, 30)
        btn:SetEnabled(Gangs.Permissions.HasPermission(flag))
        btn:SetText(name)
        btn.DoClick = doClick
        return btn
    end
end

if Cloud.DevMode then
	function PLAYER:GetGang()
		if self:IsBot() then
			return "poo"
		end
		local id = self:GetNetVar("gang")
		return id && get_name(id)
	end
else
	function PLAYER:GetGang()
		local id = self:GetNetVar("gang")
		return id && get_name(id)
	end
end

function PLAYER:getGang()
    return self:GetGang() or "" -- backwards compatbility
end

function Gangs.OnlineMembers(gang)
    local online = {}
    for k, v in ipairs(player_GetAll()) do
        if v:GetGang() == gang then
            table_insert(online, v)
        end
    end
    return online
end

function Gangs.IsValidName(str)
	if str:match("[^%w%s]") then
		return false
	end
	local len = string_len(str)
	return len <= 25 && len >=2
end

nw.Register "gang"
	:Write(net.WriteUInt, 13)
	:Read(net.ReadUInt, 13)
    :SetPlayer()

nw.Register "gangRank"
	:Write(net.WriteString)
	:Read(net.ReadString)
    :SetLocalPlayer()