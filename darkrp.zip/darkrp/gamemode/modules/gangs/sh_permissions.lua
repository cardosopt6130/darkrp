--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/sh_permissions.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

Gangs.Permissions = Gangs.Permissions or {}

Gangs.Permissions.Flags = {
    ["k"] = "kick",
    ["r"] = "create rank",
    ["m"] = "set motd",
    ["s"] = "set rank",
    ["i"] = "invite",
    ["d"] = "delete rank",
    ["p"] = "spend prestige token",
    ["n"] = "change gang name",
    ["c"] = "spend credits",
    ["e"] = "equip prestige items",
    ["g"] = "change sign material",
    ["w"] = "wager gang credits",
    ["a"] = "start arena elo matches"
}

Gangs.StartingRank = "member"

Gangs.DefaultRanks = {
    ["owner"] = "*",
    [Gangs.StartingRank] = {["weight"] = 0}
}

function PLAYER:GetGangRank()
    return self:GetNetVar("gangRank") or Gangs.StartingRank
end

if Cloud.DevMode then
	function Gangs.Permissions.HasPermission(ply, gang, flag)
		if CLIENT then 
			flag = ply
			ply = LocalPlayer() 
			gang = ply:GetGang()
		end
		if ply:IsBot() then return true end
		local rank = ply:GetGangRank()
		local rankFlags = Gangs.Cache.GetRankFlags(gang, rank)
		return rankFlags and (rankFlags == "*" or rankFlags[flag])
	end
else
	function Gangs.Permissions.HasPermission(ply, gang, flag)
		if CLIENT then 
			flag = ply
			ply = LocalPlayer() 
			gang = ply:GetGang()
		end
		local rank = ply:GetGangRank()
		local rankFlags = Gangs.Cache.GetRankFlags(gang, rank)
		return rankFlags and (rankFlags == "*" or rankFlags[flag])
	end
end

function Gangs.Permissions.CanTarget(gang, ply, targetRank)
    if CLIENT then 
        targetRank = ply
        ply = LocalPlayer() 
        gang = ply:GetGang()
    end
    local rank = ply:GetGangRank()
    if targetRank == "owner" then return false end
    if rank == "owner" then return true end
    if targetRank == Gangs.StartingRank then return true end
    local weight = Gangs.Cache.GetRankWeight(gang, rank)
    local targetWeight = Gangs.Cache.GetRankWeight(gang, targetRank)
    return weight > targetWeight
end