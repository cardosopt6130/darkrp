--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/gangs/cl_gangs.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local LAST_PAGE = "Home"

Gangs.Menu = Gangs.Menu or {}

local OpenMenu = nil

local function CreateNewGangPage(frame)
	local label = vgui.Create("DLabel", frame)
	label:SetText("Enter the desired name of your new gang.")
	label:SetFont("dank_ui.small")
	label:SizeToContents()
	label:SetPos(frame:GetWide() / 2 - label:GetWide() / 2, 40)
	
	local name = vgui.Create( "DTextEntry", frame )
	name:SetSize(frame:GetWide() * 0.8, 25)
	name:SetPos(frame:GetWide() / 2 - name:GetWide() / 2, label.y + label:GetTall() + 5)
	
	local buy = vgui.Create( "DButton", frame )
	buy:SetText("Create gang ("..DarkRP.formatMoney(Gangs.Config.CreationCost)..")")
	buy:SetSize(frame:GetWide() * 0.8, 35)
	buy:SetPos(frame:GetWide() / 2 - buy:GetWide() / 2, name.y + name:GetTall() + 5)
	buy.DoClick = function()
		if LocalPlayer():canAfford(Gangs.Config.CreationCost) then
			if Gangs.IsValidName(string.Trim(name:GetValue())) then
				RunConsoleCommand("gw_create_gang", name:GetValue())
			else
				Gangs.Notify("Your gang name must be numbers and letters only.")
			end
			frame:Close()
			timer.Simple(1.1, function()
				OpenMenu()
			end)
		else
			Gangs.Term("cannot_afford")
		end
	end
end

local function GangMenu()
	local w, h = math.Clamp(ScrW() * 0.7, 720, 1920), ScrH() * 0.85

	if !LocalPlayer():GetGang() then
		local frame = vgui.Create("dank_ui.frame")
		frame:SetSize(400, 150)
		frame:SetTitle("Gang Creation")
		frame:Center()
		frame.Title = "Gang Creation"
		CreateNewGangPage(frame)
	else
		local menu = vgui.Create("dank_ui.top_menu")
		menu:SetSize(w, h)
		menu:Center()
		menu:MakePopup()
		menu:SetTitle("Gang Menu")
		local color = Gangs.GetColor(LocalPlayer():GetGang())
		menu:SetGradientColor(color != color_white and color or DankUI.Red)
		menu:SetLastPage(LAST_PAGE)
	menu.OnKeyCodePressed = function(self, key)
		if key == KEY_F4 then
			menu:Close()
		end
	end
		menu.OnNewPage = function(self, title)
			LAST_PAGE = title
		end
		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Home", panel)
		Gangs.CreateHomePage(menu, panel)

		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Members", panel)
		Gangs.CreateMembersPage(panel)

		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Ranks", panel)
		Gangs.CreateRanksPage(panel)

		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Levels", panel)
		Gangs.CreateLevelsPage(menu, panel)

		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Store", panel)
		Gangs.CreateStorePage(frame, panel)

		local panel = vgui.Create("DPanel", menu)
		menu:AddPage("Leaderboard", panel)
		Gangs.CreateLeaderboardPage(frame, panel)

		menu:AddExitButton()
	end
end
OpenMenu = GangMenu

net.Receive("Gangs.Menu", function()
	GangMenu()
end)

net.Receive("Gangs.Invite", function()
    local gang = net.ReadString()
    local frame = vgui.Create("dank_ui.frame")
    frame.NoPopUp = true
    frame:SetSize(350, 70)
    frame:SetTitle("Gang Invite ["..gang.."]")
    local join = vgui.Create("DButton", frame)
    join:SetSize(frame:GetWide() / 2, frame:GetTall() - 29)
    join:SetPos(0, 29)
    join:SetText("Accept")
    join.DoClick = function()
        RunConsoleCommand("gw_join_gang", gang)
        frame:Close()
    end
    local decline = vgui.Create("DButton", frame)
    decline:SetSize(frame:GetWide() / 2 + 1, frame:GetTall() - 29)
    decline:SetPos(join:GetWide() - 1, 29)
    decline:SetText("Decline")
    decline.DoClick = function()
        frame:Close()
    end
    timer.Simple(59, function()
        if IsValid(frame) then
            frame:Remove()
        end
    end)
end)