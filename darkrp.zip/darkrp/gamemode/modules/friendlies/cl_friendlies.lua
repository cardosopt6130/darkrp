--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/base/friendlies/cl_friendlies.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

function DarkRP.SortByNick()
	local nicks = {}
	for k, v in pairs(player.GetAll()) do
		if v == LocalPlayer() then continue end
		nicks[v] = v:Nick()
	end
	local plys = {}
	for k, v in SortedPairsByValue(nicks) do
		table.insert(plys, k)
	end
	return plys
end

local function GetAllGangs()
	local gangs = {}
	for k, v in ipairs(player.GetAll()) do
		if v:GetGang() and !gangs[v:GetGang()] then
			gangs[v:GetGang()] = true
		end
	end
	return table.GetKeys(gangs)
end

local function AddData(field, command, data, list, color_func, validate)
	local gangs = istable(LocalPlayer():GetNetVar(field)) and LocalPlayer():GetNetVar(field) or {}
	for k, v in pairs(gangs) do
		if !validate(k) then continue end
		local btn = vgui.Create("DButton", list)
		btn:SetSize(list:GetWide(), 50)
		local id = isstring(k) and k or k:Nick()
		btn:SetText("Remove " .. id)
		btn.ID = id
		btn.DoClick = function()
			RunConsoleCommand(command, (isstring(k) and k or k:SteamID()))
			timer.Simple(0.15, function()
				list.scroll:Reset()
				AddData(field, command, data, list, color_func, validate)			
			end)
		end
		list:AddItem(btn)
		if color_func then
			btn.Style = function(self, w, h, col)
				local color = color_func(k)
				draw.Gradient(self, list, w - 2, h, color, 0.25, "right",Color(50, 50, 50, col.a) , 1, 1)
			end
		end
	end

	for k, v in SortedPairs(data) do
		if gangs[v] then continue end
		if !validate(v) then continue end
		local btn = vgui.Create("DButton", list)
		btn:SetSize(list:GetWide(), 35)
		local id = isstring(v) and v or v:Nick()
		btn:SetText("Add " .. id)
		btn.ID = id
		btn.DoClick = function()
			RunConsoleCommand(command, (isstring(v) and v or v:SteamID()))
			timer.Simple(0.15, function()
				list.scroll:Reset()
				AddData(field, command, data, list, color_func, validate)			
			end)
		end
		list:AddItem(btn)
		if color_func then
			btn.Style = function(self, w, h, col)
				local color = color_func(v)
				draw.Gradient(self, list, w - 2, h, color, 0.25, "right",Color(50, 50, 50, col.a) , 1, 1)
			end
		end
	end
end

local function Current(field, name, command, data, color_func, validate)
	local frame = vgui.Create("dank_ui.frame")
	frame:SetSize(550, 500)
	frame:SetTitle("Friendly " .. name)
	frame:Center()
	frame:MakePopup()

	local list = vgui.Create("dank_ui.searchable_list", frame)
	list:SetSize(frame:GetWide(), frame:GetTall() - 30)
	list:SetPos(0, 30)

	AddData(field, command, data, list, color_func, validate)
	return frame
end
DarkRP.FriendliesMenu = Current

concommand.Add("friendly_gangs", function()
	Current("KeypadGangs", "Gangs", "keypad_gang", GetAllGangs(), function(v) return Gangs.GetColor(v) end, function(gang)
		return gang != nil && isstring(gang)
	end)
end)

function DarkRP.IsValidPlayer(ply)
	return ply && isentity(ply) && ply:IsValid()
end

concommand.Add("friendly_players", function()
	Current("KeypadPlayers", "Players", "keypad_player", DarkRP.SortByNick(), false, DarkRP.IsValidPlayer)
end)