--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/scoreboard/cl_scoreboard.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

if CGRPScoreboard then CGRPScoreboard:Remove() CGRPScoreboard = nil end  


local color_white = Color(250,250,250)

surface.CreateFont("scoreboard.header", {
	font = "roboto", 
	size = 15,
	weight = 500
})

local PANEL = {}

function PANEL:Init()
	SCOREBOARD = self

	self.Players = vgui.Create("DPanel", self)
	self.Players.Paint = function(s, w, h)
	end

    self.Hostname = vgui.Create("DImage", self.Players)
	self.Hostname:SetSize(380, 105)
	self.Hostname.Paint = function(s, w, h)
		draw.WebImage("http://www.cloud-gaming.co.uk/darkrp/4821.png", 0, 0, w, h)
	end

	self.Selected = vgui.Create("cgrp.scoreboard.selected", self)
	self.Selected:SetVisible(false)

	self.OnlinePlayers = vgui.Create( "DLabel", self.Players)
	self.OnlinePlayers:SetFont("scoreboard.header")
	self.OnlinePlayers:SetText("")
	self.OnlinePlayers:SetTextColor(color_white)
	
	self.Uptime = vgui.Create("DLabel", self.Players)
	self.Uptime:SetFont("scoreboard.header")
	self.Uptime:SetText("")
	self.Uptime:SetTextColor(color_white)

	self.event = vgui.Create("DLabel", self.Players)
	self.event:SetFont("scoreboard.header")
	self.event:SetText("")
	self.event:SetTextColor(color_white)
	
	self.PingHeader = vgui.Create( "DLabel", self.Players)
	self.PingHeader:SetFont("scoreboard.header")
	self.PingHeader:SetText("Ping")
	self.PingHeader:SizeToContents()
	self.PingHeader:SetTextColor(color_white)

	self.JobHeader = vgui.Create( "DLabel", self.Players)
	self.JobHeader:SetFont("scoreboard.header")
	self.JobHeader:SetText("Job")
	self.JobHeader:SizeToContents()
	self.JobHeader:SetTextColor(color_white)
	
	self.PlayerFrame = vgui.Create("dank_ui.scroll", self.Players)
	self.PlayerFrame:SetScrollSize(7)
	self.PlayerFrame.PerformLayout = function(self) 
		local canvas = self:GetCanvas()

		if (canvas:GetWide() != self:GetWide()) then
			canvas:SetWide(self:GetWide())
		end

		local y = 0
		local PlayerSorted = {}
	
		for k, v in pairs( SCOREBOARD.PlayerRows ) do
			if IsValid( k ) then table.insert( PlayerSorted, v ) end
		end
		table.sort( PlayerSorted, function ( a , b ) return a:HigherOrLower( b ) end )

		for k, v in ipairs(PlayerSorted) do
			local childY = y + self.SpaceTop
			if (v.x != self.Padding or v.y != childY) then
				v:SetPos(self.Padding, y + self.SpaceTop)
			end
			v.y = childY
			if (v:GetWide() != self:GetWide() - self.Padding * 2) then
				v:SetWide(self:GetWide() - self.Padding * 2)
			end

			y = y + v:GetTall() - 1
		end
		y = math.Clamp(y - self.SpaceTop, 0, math.huge)
		canvas:SetTall(y)

		if (canvas:GetTall() <= self:GetTall()) then
			canvas:SetTall(self:GetTall())

			self.scrollBar:SetVisible(false)
		else
			self.scrollBar:SetVisible(true)
		end

		local maxOffset = (self:GetCanvas():GetTall() - self:GetTall())

		if (self.yOffset > maxOffset) then
			self.yOffset = maxOffset
		end

		if (self.yOffset < 0) then
			self.yOffset = 0
		end

		canvas:SetPos(0, -self.yOffset)

		self.scrollBar:InvalidateLayout()
	end

	self.PlayerFrame.Paint = function(self, w, h)
		DankUI.DrawOutlinedBox(0, 0, w, h, Color(32, 32, 32, 200), DankUI.Outline)
	end
	
	self.PlayerRows = {}
end

function PANEL:AddPlayerRow(ply)
	local button = vgui.Create("cgrp.scoreboard.row")
	button:SetPlayer(ply)
	button:SetCursor("hand")
	button.OnMousePressed = function()
		if self.Selected:GetPlayer() and self.Selected:GetPlayer() == ply then
			self.Selected:SetVisible(!self.Selected:IsVisible())
			self:PerformLayout()
			return
		end
		self.Selected:SetVisible(true)
		self.Selected:SetPlayer(ply)
	end

	self.PlayerFrame:AddItem(button)
	self.PlayerRows[ply] = button
end

function PANEL:GetPlayerRow( ply )
	return self.PlayerRows[ ply ]
end

function PANEL:Paint( w, h )
	DankUI.Blur(self, 8)
    DankUI.DrawOutlinedBox(0, 0, w, h, Color(38, 38, 38, 249), DankUI.Outline)
end

function PANEL:Think()
	self:UpdateScoreboard()
end

function PANEL:PerformLayout()
	self:SetSize(math.Clamp(ScrW() * (self.Selected:IsVisible() and 0.75 or 0.5), 640, 1200), ScrH() * 0.85)
	self:SetPos((ScrW() - self:GetWide()) / 2, (ScrH() - self:GetTall()) / 2)

	self.Players:SetSize(self:GetWide() * (self.Selected:IsVisible() and 0.75 or 1), self:GetTall())
	self.Players:SetPos(self.Selected:IsVisible() and self:GetWide() * 0.25 or 0, 0)

	self.Selected:SetSize(self:GetWide() - self.Players:GetWide() - 20, self:GetTall() - 40)
	self.Selected:SetPos(20, 20)
	
	self.Hostname:SetSize(380, 105)
	self.Hostname:SetPos((self.Players:GetWide() / 2) - (self.Hostname:GetWide() / 2), 5)
	
	self.PlayerFrame:SetPos(20, self.Hostname.y + self.Hostname:GetTall() + 20)
	self.PlayerFrame:SetSize(self.Players:GetWide() - 40, self.Players:GetTall() - self.PlayerFrame.y - 21)

	self.PingHeader:SizeToContents()
	self.PingHeader:SetPos(self.Players:GetWide() * 0.8, self.PlayerFrame.y - self.PingHeader:GetTall() - 3)

	self.JobHeader:SizeToContents()
	self.JobHeader:SetWide(self.JobHeader:GetWide() + 1)
	self.JobHeader:SetPos(self.Players:GetWide() * 0.5, self.PlayerFrame.y - self.PingHeader:GetTall() - 3)
end

function PANEL:UpdateScoreboard( force )
	if not self or ( not force and not self:IsVisible() ) then return end
	if not self.Selected:GetPlayer() then
		self.Selected:SetPlayer(LocalPlayer())
	end
	for k, v in pairs( self.PlayerRows ) do
		if not IsValid( k ) then
			v:Remove()
			self.PlayerRows[ k ] = nil
		end
	end
	
	for id, pl in ipairs(player.GetAll()) do
		if not self.Selected:GetPlayer() and pl == LocalPlayer() then
			self.Selected:SetPlayer(pl)
		end
		if not self:GetPlayerRow( pl ) then
			self:AddPlayerRow( pl )
		end
	end
	
	self.PlayerFrame:InvalidateLayout()

	self.OnlinePlayers:SetText(player.GetCount() .. " | Players Online")
	self.OnlinePlayers:SizeToContents()
	self.OnlinePlayers:SetPos(self.PlayerFrame.x + self.PlayerFrame:GetWide() - self.OnlinePlayers:GetWide(), self:GetTall() - self.OnlinePlayers:GetTall() - 5)
	
	local hours = math.floor(CurTime() / 3600)
	local minutes = math.floor((CurTime() % 3600) / 60)
	local seconds = math.floor(CurTime() - (hours * 3600) - (minutes * 60))
	
	if (minutes < 10) then minutes = "0" .. minutes end
	if (seconds < 10) then seconds = "0" .. seconds end
	self.Uptime:SetText("Uptime: " .. hours .. ":" .. minutes .. ":" .. seconds)
	self.Uptime:SizeToContents()
	self.Uptime:SetPos(self.PlayerFrame.x, self:GetTall() - self.Uptime:GetTall() - 5)

	self.event:SetText("Next Event: " .. (Cloud.Events.NextTime and math.floor((Cloud.Events.NextTime - CurTime()) / 60) or 0) .. " mins")
	self.event:SizeToContents()
	self.event:SetPos(self.PlayerFrame.x, self.PlayerFrame.y -  self.event:GetTall())
end
vgui.Register("cgrp.scoreboard", PANEL, "EditablePanel")