--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/scoreboard/cl_selected_player.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local surface = surface
local color_white = Color(250,250,250)
local red = table.Copy(DankUI.Red)
local PANEL = {}

local cooldown
local function InviteToGang(ply)
	if cooldown and cooldown > CurTime() then return end
	cooldown = CurTime() + 5
	if LocalPlayer():GetGang() and Gangs.Permissions.HasPermission("i") then
		net.Start("Gangs.Invite")
			net.WritePlayer(ply)
		net.SendToServer()
	else
		Gangs.Notify("You do not have permission to do this.")
	end
end

local options = {
	["Copy Steamid"] = function(ply) SetClipboardText(ply:SteamID()) end,
	["Invite To Gang"] = InviteToGang,
	["Steam Profile"] = function(ply) gui.OpenURL( 'http://steamcommunity.com/profiles/' .. ply:SteamID64() .. '/' ) end
}

local infos = {
	["Gang"] = function(ply) return ply:GetGang() and ply:GetGang() or "none" end,
	["Steam Name"] = function(ply) return ply:SteamName() end
}

local admin_options = {
	["Bring"] = function(ply) RunConsoleCommand("cga", "bring", ply:SteamID()) end,
	["Freeze"] = function(ply) RunConsoleCommand("cga", "freeze", ply:SteamID()) end,
	["Goto"] = function(ply) RunConsoleCommand("cga", "goto", ply:SteamID()) end,
	["Kick"] = function(ply) RunConsoleCommand("cga", "kick", ply:SteamID()) end,
	["Cloak Goto"] = function(ply) RunConsoleCommand("cga", "cloak", ply:SteamID()) RunConsoleCommand("cga", "goto", ply:SteamID()) end,
	["View Info"] = function(ply) RunConsoleCommand("cga", "info", ply:SteamID()) end,
	["Spectate"] = function(ply) RunConsoleCommand("cga", "spectate", ply:SteamID()) end,
	["Set Job"] = function(ply)	
		local men = DermaMenu()
		for k,v in pairs(RPExtraTeams) do
			men:AddOption(v.name, function()
				RunConsoleCommand("cga", "setjob", ply:SteamID(), v.command)
			end)
		end
		men:Open()
	end,
}

function PANEL:Init()
	self.Avatar = vgui.Create("AvatarImage", self)

	self.NickName = DankUI.CreateLabel(self, "", "dank_ui.medium")
	self.NickName:SetColor(color_white)
	self.NickName.Paint = function(s)
		draw.SimpleTextOutlined(s:GetText(), s:GetFont(), 0, 0, color_white, nil, nil, 1, color_black)
	end

	self.Rank = DankUI.CreateLabel(self, "", "dank_ui.20")
	self.Rank:SetColor(color_white)
	self.Rank.Paint = function(s)
		draw.SimpleTextOutlined(s:GetText(), s:GetFont(), 0, 0, color_white, nil, nil, 1, color_black)
	end

	self:SetSkin("material_dark")

	self.Divider1 = vgui.Create("dank_ui.divider", self)
	self.Divider2 = vgui.Create("dank_ui.divider", self)
end

local col = Color(255, 255, 255, 100)
function PANEL:Paint(w, h)
	if self.Player:GetNetVar("card") then
		local url = CallingCards.ByInt[self.Player:GetNetVar("card")]
		draw.WebImage(url, 0, 0, w, 64, col)
	end
end

function PANEL:SetPlayer(ply)
	self.Player = ply
	self.Avatar:SetPlayer(ply, 64)
	self.NickName:SetText(ply:Nick())
	self.NickName:SizeToContents()
	self.Rank:SetText(ply:GetUserGroup())
	self.Rank:SizeToContents()

	if IsValid(self.Options) then
		self.Options:Remove()
	end

	if IsValid(self.AdminOptions) then
		self.AdminOptions:Remove()
	end

	self.Options = vgui.Create("dank_ui.scroll", self)
	self.Options:SetPadding(-1)

	for k, v in pairs(infos) do
		local info = vgui.Create("DPanel", self.Options)
		info:SetHeight(50)
		info.Paint = function(s, w, h)
			DankUI.DrawOutlinedBox(0, 0, w, h, Color(30, 30, 30, 100), DankUI.Outline)
			draw.SimpleText(k .. ": " .. v(ply), "dank_ui.small", w / 2, h / 2, k == "Gang" and red or color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
		self.Options:AddItem(info)
	end

	for k, v in pairs(options) do
		local option = vgui.Create("DButton", self.Options)
		option:SetText(k)
		option:SetHeight(50)
		option.DoClick = function() v(ply) end
		self.Options:AddItem(option)
	end

	self.AdminOptions = vgui.Create("dank_ui.scroll", self)
	self.AdminOptions:SetPadding(-1)
	if LocalPlayer():IsStaff() then
		for k, v in pairs(admin_options) do
			local option = vgui.Create("DButton", self.AdminOptions)
			option:SetText(k)
			option:SetHeight(45)
			option.DoClick = function() v(ply) end
			self.AdminOptions:AddItem(option)
		end
	end
end

function PANEL:Think()
	if IsValid(self.AdminOptions) and !LocalPlayer():IsStaff() then
		self.AdminOptions:Remove()
	end

	if !IsValid(self.Player) then
		self:SetVisible(false)
		self:GetParent():PerformLayout()
	end

	if !IsValid(self.AdminOptions) and LocalPlayer():IsStaff() then
		self.AdminOptions = vgui.Create("dank_ui.scroll", self)
		self.AdminOptions:SetPadding(-1)
		for k, v in pairs(admin_options) do
			local option = vgui.Create("DButton", self.AdminOptions)
			option:SetText(k)
			option:SetHeight(45)
			option.DoClick = function() v(self.Player) end
			self.AdminOptions:AddItem(option)
		end
	end
end

function PANEL:GetPlayer()
	return self.Player
end

function PANEL:PerformLayout()
	self:SetSize(self:GetWide(), self:GetTall())
	
	self.Avatar:SetPos(0, 0)
 	self.Avatar:SetSize(64, 64)

	self.NickName:SizeToContents()
	self.NickName:SetPos(self.Avatar.x + self.Avatar:GetWide() + 5, 5)

	self.Rank:SetPos(self.NickName.x, self.NickName.y + self.NickName:GetTall() - 5)
	self.Rank:SizeToContents()

	self.Divider1:SetPos(0, self.Avatar.y + self.Avatar:GetTall() + 10)


	self.Options:SetPos(0, self.Divider1.y + self.Divider1:GetTall() + 10)
	self.Options:SetSize(self:GetWide(), (table.Count(infos) + table.Count(options)) * 50)

	self.Divider2:SetPos(0, self.Options.y + self.Options:GetTall() + 10)

	local height_left = self:GetTall() - (self.Divider2.y + self.Divider2:GetTall())

	if IsValid(self.AdminOptions) then
		self.AdminOptions:SetSize(self:GetWide(), height_left - 10)
		self.AdminOptions:SetPos(0, self.Divider2.y + self.Divider2:GetTall() + 10)
	end
end
vgui.Register("cgrp.scoreboard.selected", PANEL, "Panel")