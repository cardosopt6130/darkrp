--[[
Server Name: ►[UK] Cloud Gaming | M9K | FastDL | Custom | Since 2013
Server IP:   208.103.169.209:27015
File Path:   gamemodes/darkrp/gamemode/modules/scoreboard/cl_player_row.lua
		 __        __              __             ____     _                ____                __             __         
   _____/ /_____  / /__  ____     / /_  __  __   / __/____(_)__  ____  ____/ / /_  __     _____/ /____  ____ _/ /__  _____
  / ___/ __/ __ \/ / _ \/ __ \   / __ \/ / / /  / /_/ ___/ / _ \/ __ \/ __  / / / / /    / ___/ __/ _ \/ __ `/ / _ \/ ___/
 (__  ) /_/ /_/ / /  __/ / / /  / /_/ / /_/ /  / __/ /  / /  __/ / / / /_/ / / /_/ /    (__  ) /_/  __/ /_/ / /  __/ /    
/____/\__/\____/_/\___/_/ /_/  /_.___/\__, /  /_/ /_/  /_/\___/_/ /_/\__,_/_/\__, /____/____/\__/\___/\__,_/_/\___/_/     
                                     /____/                                 /____/_____/                                  
--]]

local surface = surface
local color_white = Color(250,250,250)


surface.CreateFont("scoreboard.player", {
	font = "roboto", 
	size = 17,
	weight = 800
})

local CON_BAR_WIDTH = 7
local COLUMN_SIZE = 50

local function GetPingSize(ping)
	return (ping < 250 and 3) or (ping < 320 and 2) or 1
end

local function GetPingColor(ping)
	return (ping < 320 and Color(50, 200, 50, 255)) or Color(150, 80, 50, 255)
end

local PANEL = {}

function PANEL:Init()
	self.Size = 25
	self.imgAvatar = vgui.Create( "AvatarImage", self )

	self.Badge = vgui.Create('DImage', self)
	self.NickName = DankUI.CreateLabel(self, "", "scoreboard.player")
	self.NickName:SetColor(color_white)

	self.Job = DankUI.CreateLabel(self, "", "scoreboard.player")
	self.Job:SetColor(color_white)

	self.Ping = vgui.Create("DPanel", self)
	self.Ping.Paint = function(s, w, h)
		if !IsValid(self.Player) then return end
		local color = GetPingColor(self.Player:Ping())
		DankUI.DrawBox(0, h - 5, CON_BAR_WIDTH, h - 10, color)
		DankUI.DrawBox(CON_BAR_WIDTH, h - 10, CON_BAR_WIDTH, h - 5, color)
		DankUI.DrawBox(CON_BAR_WIDTH * 2, 1, CON_BAR_WIDTH, h, color)
		surface.SetDrawColor(DankUI.Outline)
		surface.DrawOutlinedRect(0, h - 5, CON_BAR_WIDTH, h - 10)
		surface.DrawOutlinedRect(CON_BAR_WIDTH, h - 10, CON_BAR_WIDTH, h - 5)
		surface.DrawOutlinedRect(CON_BAR_WIDTH * 2, 1, CON_BAR_WIDTH, h)
	end	

	self.btnMute = vgui.Create('DImageButton', self)
	self.btnMute:SetImage('icon32/unmuted.png')
	self.btnMute.DoClick = function()
		if self.Player:IsMuted() then
			self.Player:SetMuted(false)
			self.btnMute:SetImage('icon32/unmuted.png')
			self.btnMute.Muted = false
		else
			self.Player:SetMuted(true)
			self.btnMute:SetImage('icon32/muted.png')
			self.btnMute.Muted = true
		end
	end
	self.btnMute.Think = function(s)
		if !IsValid(self.Player) then return end
		if self.Player:IsMuted() && !self.Muted then
			self.btnMute:SetImage('icon32/muted.png')
			self.Muted = true
		elseif !self.Player:IsMuted() && self.Muted then
			self.btnMute:SetImage('icon32/unmuted.png')
			self.Muted = false
		end
	end
end

function PANEL:Paint(w, h)
	if not IsValid( self.Player ) then
		self:Remove()
		SCOREBOARD:InvalidateLayout()
		return 
	end 
	
	local color = color_black
	
	if self.Player:Team() == TEAM_CONNECTING then
		color = color_black
	elseif IsValid( self.Player ) then
		if self.Player:Team() != TEAM_UNASSIGNED then
			color = self.Player:GetJobColor()
		end
	end
	
	DankUI.DrawBox(1, 0, self:GetWide() - 2, self:GetTall(), color)
	surface.SetDrawColor(DankUI.Outline)
	surface.DrawOutlinedRect(1, 0, self:GetWide() - 2, self:GetTall())
	return true
end

function PANEL:SetPlayer(ply)
	self.Player = ply
	self:UpdatePlayerData()
	self.imgAvatar:SetPlayer(ply, 21)
	self.NickName:SetText(ply:Nick())
	self.NickName:SizeToContents()
	self.Job:SetText(ply:GetJobName())
	self.Job:SizeToContents()
end

function PANEL:Think()
	if not self.PlayerUpdate or self.PlayerUpdate < CurTime() then
		self.PlayerUpdate = CurTime() + 1
		self:UpdatePlayerData()
	end
end

local icons = {}
icons['other'] = "icon16/user.png"
icons['community manager'] = "icon16/group.png"
icons['owner'] = "icon16/asterisk_orange.png"
icons['vip'] = "icon16/award_star_silver_1.png"
icons['goldvip'] = "icon16/award_star_gold_1.png"
icons['ultimatevip'] = "icon16/medal_gold_3.png"
icons['superadmin'] = "icon16/lightning.png"
icons['manager'] = "icon16/asterisk_yellow.png"
icons['headadmin'] = "icon16/star.png"
icons['mod'] = "icon16/tux.png"
icons['admin'] = "icon16/shield.png"
icons['nino'] = "icon16/shield_go.png"
icons['admin+'] = "icon16/shield_add.png"
icons['developer'] = "icon16/application_xp_terminal.png"

function PANEL:UpdatePlayerData()
	local ply = self.Player
	if not IsValid( ply ) then return end
	
	local badgeimg = icons[self.Player:GetUserGroup()] or icons["other"]
	if (!self.BadgeImg or self.BadgeImg != badgeimg) then
		self.Badge:SetImage(badgeimg)
		self.BadgeImg = badgeimg
	end
	
	local name = (self.Player:IsValid() and self.Player:Nick()) or ""
	self.NameText = name

	self.NickName:SetText(ply:Nick())
	self.NickName:SizeToContents()
	self.Job:SetText(self.Player:GetJobName())
	self.Job:SizeToContents()
	local job_header = SCOREBOARD.JobHeader
	local middle = job_header.x - job_header:GetWide() / 2
	self.Job:SetPos(middle - self.Job:GetWide() / 2, self:GetTall() / 2 - self.Job:GetTall() / 2)
	
	local width = CON_BAR_WIDTH * GetPingSize(self.Player:Ping())
	if self.Ping:GetWide() != width then
		self.Ping:SetWide(width)
	end
end

function PANEL:PerformLayout()
	self:SetSize( self:GetWide(), self.Size )
	
 	self.imgAvatar:SetSize(21, 21)
	self.imgAvatar:SetPos(3, 2)

 	self.Badge:SetSize(16, 16)
 	self.Badge:SetPos(self.imgAvatar.x + self.imgAvatar:GetWide() + 5, 5)

	self.NickName:SetPos(self.Badge.x + self.Badge:GetWide() + 5, self:GetTall() / 2 - self.NickName:GetTall() / 2)

	local job_header = SCOREBOARD.JobHeader
	local middle = job_header.x - job_header:GetWide() / 2
	self.Job:SetPos(middle - self.Job:GetWide() / 2, self:GetTall() / 2 - self.Job:GetTall() / 2)

	local ping_header = SCOREBOARD.PingHeader
	middle = ping_header.x - ping_header:GetWide() / 2
	self.Ping:SetTall(self:GetTall() - 7.5)
	self.Ping:SetPos(middle - self.Ping:GetWide() / 2, self:GetTall() / 2 - self.Job:GetTall() / 2)
	
	self.btnMute:SetPos(self:GetWide() - 24, 2)
	self.btnMute:SetSize( 21, 21 )
end

function PANEL:HigherOrLower(row)
	if not IsValid(row.Player) or not IsValid(self.Player) then return false end

	if self.Player:Team() == TEAM_CONNECTING then return false end
	if row.Player:Team() == TEAM_CONNECTING then return true end

	local myTeam = team.GetName(self.Player:GetNetVar("job"))
	local theirTeam = team.GetName(row.Player:GetNetVar("job"))

	if myTeam == theirTeam then
		return myTeam < theirTeam 
	end

	return myTeam < theirTeam 
end
vgui.Register("cgrp.scoreboard.row", PANEL, "Panel")